<?php
// Salin menjadi database.local.php dan isi kredensial server.
return [
  'host' => 'localhost',
  'user' => 'YOUR_DB_USER',
  'password' => 'YOUR_DB_PASSWORD',
  'database' => 'YOUR_DB_NAME',
];
