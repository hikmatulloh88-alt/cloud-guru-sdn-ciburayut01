# Security notes

- Do not commit real database credentials, API tokens, passwords, student/teacher photos, signatures, or production exports.
- WhatsApp/Fonnte token must be stored in the application's protected database/settings, not source control.
- Production uploads and generated backups are intentionally excluded from this repository.
- Rotate any credential that has previously been committed to a public repository.
