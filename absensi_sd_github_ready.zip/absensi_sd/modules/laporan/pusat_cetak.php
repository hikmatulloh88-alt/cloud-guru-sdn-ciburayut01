<?php
session_start();

require_once __DIR__ . '/../../config/database.php';

if (empty($_SESSION['login_user']) && empty($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Laporan & Cetak - SDN Ciburayut 01</title>

<style>
*{
    box-sizing:border-box;
}

body{
    margin:0;
    background:#f4f7fb;
    color:#14243d;
    font-family:Arial,Helvetica,sans-serif;
}

.container{
    max-width:1100px;
    margin:40px auto;
    padding:20px;
}

.header{
    margin-bottom:25px;
}

.header h1{
    margin:0 0 8px;
    font-size:30px;
}

.header p{
    margin:0;
    color:#64748b;
}

.grid{
    display:grid;
    grid-template-columns:repeat(2,1fr);
    gap:20px;
}

.card{
    background:#fff;
    border:1px solid #dbe4ef;
    border-radius:16px;
    padding:25px;
    box-shadow:0 8px 25px rgba(15,40,70,.07);
}

.icon{
    font-size:35px;
    margin-bottom:12px;
}

.card h2{
    margin:0 0 10px;
    font-size:20px;
}

.card p{
    color:#64748b;
    line-height:1.6;
    min-height:48px;
}

.btn{
    display:inline-block;
    padding:12px 18px;
    border-radius:9px;
    background:#176fe5;
    color:#fff;
    text-decoration:none;
    font-weight:bold;
}

.btn:hover{
    background:#0d5dcc;
}

.back{
    margin-top:25px;