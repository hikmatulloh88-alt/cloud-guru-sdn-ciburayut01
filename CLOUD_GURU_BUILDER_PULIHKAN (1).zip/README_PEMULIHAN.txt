PEMULIHAN WEBSITE BUILDER — CLOUD GURU

Paket ini memulihkan file inti Builder dari cadangan public_html(1).zip yang tersedia.

CARA PASANG:
1. Di cPanel File Manager, buka public_html/builder/.
2. Cadangkan dulu file yang ada saat ini.
3. Ekstrak ZIP ini di folder sementara.
4. Upload/timpa tiga file dengan path yang sama:
   - public_html/builder/index.php
   - public_html/builder/assets/builder.css
   - public_html/builder/assets/menu_fix.js
5. Jika file berikut ada akibat revisi sebelumnya, hapus hanya file tambahan itu:
   public_html/builder/assets/builder-improved.css
6. Buka Builder dan tekan Ctrl+F5.

Catatan: file inti diambil apa adanya dari cadangan proyek yang tersedia; tidak mengubah database, endpoint, atau logika simpan/publish. Uji di hosting tetap diperlukan.
