<?php
require_once __DIR__ . '/../auth/auth.php';
wajib_login();
wajib_role('Admin');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/security.php';
$pageSlug = strtolower(trim((string)($_GET['page'] ?? 'home')));
if (!preg_match('/^[a-z0-9-]{1,120}$/', $pageSlug)) $pageSlug='home';
$pageTitle = $pageSlug==='home' ? 'Beranda' : ucfirst(str_replace('-', ' ', $pageSlug));
try { $q=$pdo->prepare("SELECT title FROM website_builder_pages WHERE slug=? LIMIT 1"); $q->execute([$pageSlug]); if($r=$q->fetch()) $pageTitle=$r['title']; } catch(Throwable $e) {}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Website Builder — Cloud Guru</title>
<link rel="stylesheet" href="/builder/assets/builder.css">
<style id="builder-insert-fix">
/* Builder Final: blok baru selalu berada di area konten sebelum footer */
#sitePreview > .added-block { position: relative; }
#sitePreview > footer.builder-footer { margin-top: 0; }
</style>
</head>
<body>
<div class="builder">
<header class="builder-top">
  <div class="builder-brand">
    <button class="mobile-menu" id="openPanel">☰</button>
    <span class="cloud">☁️</span><strong>Cloud Guru</strong>
    <span class="separator">|</span><span class="site-name">SDN Ciburayut 01 · <?=htmlspecialchars($pageTitle,ENT_QUOTES,'UTF-8')?></span>
  </div>
  <div class="toolbar">
    <button id="undoBtn" title="Undo">↶</button>
    <button id="redoBtn" title="Redo">↷</button>
    <button id="previewBtn">👁 Preview</button><button id="versionsBtn" title="Riwayat versi">🕘 Versi</button><button id="unpublishBtn" title="Kembalikan ke Draft">↩ Unpublish</button>
    <button class="save-draft" id="saveBtn">💾 Simpan Draft</button>
    <span class="draft-status" id="draftStatus">Memuat...</span>
    <button title="Bagikan">🔗</button><button title="Pengaturan">⚙️</button>
    <button class="publish" id="publishBtn">🚀 PUBLISH</button>
  </div>
</header>

<div class="builder-body">
<main class="canvas-wrap">
  <div class="canvas-label">PREVIEW WEBSITE · <b><?=htmlspecialchars($pageTitle,ENT_QUOTES,'UTF-8')?></b> · DRAG & DROP UNTUK MEMINDAHKAN BLOK</div>
  <div class="device-toolbar" id="deviceToolbar" aria-label="Responsive device preview">
    <div class="device-group">
      <span class="device-label">TAMPILAN</span>
      <button class="device-btn active" data-device="desktop" title="Desktop">🖥️ Desktop</button>
      <button class="device-btn" data-device="tablet" title="Tablet">📱 Tablet</button>
      <button class="device-btn" data-device="mobile" title="Ponsel">📱 HP</button>
    </div>
    <div class="device-group device-zoom-group">
      <button class="zoom-btn" data-zoom="75">−</button>
      <span id="zoomValue">100%</span>
      <button class="zoom-btn" data-zoom="125">+</button>
      <button class="zoom-btn" id="zoomReset" title="Reset zoom">↺</button>
    </div>
    <div class="device-meta" id="deviceMeta">Desktop · 100%</div>
  </div>
  <div class="responsive-stage" id="responsiveStage">
    <section class="site-preview theme-blue" id="sitePreview">
    <div class="preview-nav">
      <div class="preview-logo">01</div>
      <div class="preview-school">SDN CIBURAYUT 01</div>
      <div class="preview-links"><a href="/?page=home">Beranda</a><a href="/?page=profil">Profil</a><a href="/?page=informasi">Informasi</a><a href="/?page=guru">Guru</a></div>
      <a class="preview-cta" href="/auth/login.php">🔐 Masuk Sistem</a>
    </div>

    <section class="editable hero-block builder-hero" data-id="hero" data-type="hero">
      <div class="hero-content"><div class="eyebrow">PORTAL INFORMASI SEKOLAH</div><h1>Selamat Datang di SDN Ciburayut 01</h1><p>Portal resmi sekolah untuk informasi, kegiatan, profil guru, dan layanan digital.</p><div class="hero-actions"><a class="preview-button hero-btn-primary" href="/?page=informasi">Jelajahi Portal →</a><a class="hero-btn-secondary" href="/?page=profil">Profil Sekolah</a></div></div><div class="hero-image-badge">🏫<span>Portal Sekolah Digital</span></div>
    </section>
      <div><b>6</b><small>Kelas</small></div>
      <div><b>10+</b><small>Layanan</small></div>
    </div>

    <div class="preview-section editable" data-id="profile" data-type="text">
      <div class="eyebrow">PROFIL SEKOLAH</div>
      <h2>Mengenal SDN Ciburayut 01</h2>
      <p>Sekolah dasar yang terus berkembang melalui pembelajaran, kolaborasi, dan layanan digital.</p>
    </div>

    <div class="preview-cards">
      <div class="preview-card editable" data-id="announcement" data-type="card"><span>📢</span><h3>Pengumuman</h3><p>Informasi terbaru sekolah.</p></div>
      <div class="preview-card editable" data-id="agenda" data-type="card"><span>📅</span><h3>Agenda</h3><p>Kegiatan sekolah.</p></div>
      <div class="preview-card editable" data-id="teachers" data-type="card"><span>👨‍🏫</span><h3>Profil Guru</h3><p>Tenaga pendidik sekolah.</p></div>
    </div>
    <footer class="builder-footer" data-builder-footer="1"><div class="builder-footer-grid cols-3"><div class="builder-footer-brand"><div class="builder-footer-logo">01</div><div><b>SDN CIBURAYUT 01</b><small>Portal Informasi Sekolah</small></div></div><div class="builder-footer-links"><b>Menu Cepat</b><a href="/?page=home">Beranda</a><a href="/?page=profil">Profil Sekolah</a><a href="/?page=informasi">Informasi</a><a href="/?page=guru">Profil Guru</a></div><div class="builder-footer-contact"><b>Hubungi Kami</b><span>📍 Cigombong, Kabupaten Bogor</span><span>✉️ info@sdnciburayut01.com</span><div class="builder-footer-social"><span>Media sosial sekolah akan ditambahkan.</span></div></div></div><div class="builder-footer-copy">© 2026 SDN Ciburayut 01. Semua hak dilindungi.</div></footer>
  </section>
  </div>
</main>

<aside class="side-panel" id="sidePanel">
  <div class="panel-tabs">
    <button class="tab active" data-panel="insert">INSERT</button>
    <button class="tab" data-panel="pages">PAGES</button>
    <button class="tab" data-panel="themes">THEMES</button>
    <button class="tab" data-panel="media">MEDIA</button>
    <button class="tab" data-panel="navbar">NAVBAR</button>
    <button class="tab" data-panel="header">HEADER</button>
    <button class="tab" data-panel="hero">HERO</button>
    <button class="tab" data-panel="news">NEWS</button>
    <button class="tab" data-panel="agenda">AGENDA</button>
    <button class="tab" data-panel="teachers">GURU</button>
    <button class="tab" data-panel="contact">KONTAK</button>
    <button class="tab" data-panel="footer">FOOTER</button>
  </div>
  <div class="panel-content">
    <div class="builder-panel" id="panel-insert">
      <h4>Tambahkan ke halaman</h4>
      <button class="insert-item" data-add="text"><span>📝</span><div><b>Text</b><small>Tambahkan teks</small></div></button>
      <button class="insert-item" data-add="image"><span>🖼️</span><div><b>Image</b><small>Tambahkan gambar</small></div></button>
      <button class="insert-item" data-add="button"><span>🔘</span><div><b>Button</b><small>Buat tombol</small></div></button>
      <button class="insert-item" data-add="gallery"><span>🎞️</span><div><b>Gallery</b><small>Galeri foto</small></div></button>
      <button class="insert-item" data-add="divider"><span>➖</span><div><b>Divider</b><small>Pemisah konten</small></div></button>
      <button class="insert-item" data-add="spacer"><span>↕️</span><div><b>Spacer</b><small>Jarak konten</small></div></button>
      <div class="panel-section"><h4>Layout / Kolom</h4><div class="blocks layout-blocks">
<button class="layout-block-btn" data-layout="1">▯ 1 Kolom</button>
<button class="layout-block-btn" data-layout="2">▯▯ 2 Kolom</button>
<button class="layout-block-btn" data-layout="3">▯▯▯ 3 Kolom</button>
<button class="layout-block-btn" data-layout="4">▯▯▯▯ 4 Kolom</button>
</div><p class="panel-help">Buat layout lalu klik isi kolom untuk menambahkan atau mengedit konten.</p></div>
      <div class="panel-section"><h4>Content Blocks</h4><div class="blocks">
<button class="content-block-btn" data-block="hero">🚀 Hero</button>
<button class="content-block-btn" data-block="columns">▦ 3 Kolom</button>
<button class="content-block-btn" data-block="profile">🏫 Profil</button>
<button class="content-block-btn" data-block="contact">📍 Kontak</button>
<button class="content-block-btn" data-block="announcement">📢 Pengumuman</button>
<button class="content-block-btn" data-block="news">📰 Berita Dinamis</button>
<button class="content-block-btn" data-block="agenda">📅 Agenda Dinamis</button>
<button class="content-block-btn" data-block="teachers">👨‍🏫 Guru</button>
<button class="content-block-btn" data-block="gallery">🖼️ Galeri</button>
<button class="content-block-btn" data-block="cta">⭐ CTA</button>
</div></div>
    </div>
    <div class="builder-panel" id="panel-news" hidden>
      <div class="panel-title-row"><h4>Berita & Pengumuman</h4><a class="small-add" href="/builder/news.php">⚙️ Kelola</a></div>
      <p class="panel-help">Kelola berita di halaman khusus Admin. Gunakan <b>Berita Dinamis</b> agar daftar berita terbaru tampil otomatis di website publik.</p>
      <button class="insert-item" data-add="news"><span>📰</span><div><b>Berita Dinamis</b><small>Menampilkan berita published terbaru</small></div></button>
    </div>
    <div class="builder-panel" id="panel-agenda" hidden>
      <div class="panel-title-row"><h4>Agenda Sekolah</h4><a class="small-add" href="/builder/agenda.php">⚙️ Kelola</a></div>
      <p class="panel-help">Kelola kegiatan sekolah di halaman khusus Admin. Gunakan <b>Agenda Dinamis</b> agar agenda mendatang tampil otomatis di website publik.</p>
      <button class="insert-item" data-add="agenda"><span>📅</span><div><b>Agenda Dinamis</b><small>Menampilkan kegiatan sekolah mendatang</small></div></button>
    </div>
    <div class="builder-panel" id="panel-teachers" hidden>
      <div class="panel-title-row"><h4>Profil Guru & Staff</h4><a class="small-add" href="/admin/guru/">⚙️ Kelola</a></div>
      <p class="panel-help">Data diambil otomatis dari <b>Kelola Profil Guru</b>. Gunakan blok <b>Profil Guru Dinamis</b> agar perubahan data guru langsung tercermin di website publik.</p>
      <button class="insert-item" data-add="teachers"><span>👨‍🏫</span><div><b>Profil Guru Dinamis</b><small>Menampilkan guru aktif terbaru</small></div></button>
    </div>
    <div class="builder-panel" id="panel-footer" hidden>
      <h4>🦶 Footer Builder Pro</h4>
      <p class="panel-help">Atur tampilan footer website tanpa mengubah kode.</p>
      <label class="setting-label">Layout
        <select id="footerLayout"><option value="1">1 Kolom</option><option value="2">2 Kolom</option><option value="3">3 Kolom</option><option value="4">4 Kolom</option></select>
      </label>
      <label class="setting-label">Warna background<input id="footerBg" type="text" maxlength="7" placeholder="#102a43"></label>
      <label class="setting-label">Warna teks<input id="footerTextColor" type="text" maxlength="7" placeholder="#ffffff"></label>
      <label class="check-setting"><input id="footerShowLogo" type="checkbox"> Tampilkan logo & nama sekolah</label>
      <label class="check-setting"><input id="footerShowQuicklinks" type="checkbox"> Tampilkan menu cepat</label>
      <label class="check-setting"><input id="footerShowContact" type="checkbox"> Tampilkan kontak</label>
      <label class="check-setting"><input id="footerShowSocial" type="checkbox"> Tampilkan sosial media</label>
      <label class="setting-label">Menu cepat<textarea id="footerQuicklinks" rows="7" placeholder="Beranda|/?page=home&#10;Profil Sekolah|/?page=profil"></textarea><small>Format: Nama|Link, satu per baris.</small></label>
      <button class="primary-action" id="saveFooterSettings">💾 Simpan Footer</button>
    </div>
    <div class="builder-panel" id="panel-contact" hidden>
      <div class="panel-title-row"><h4>Kontak & Sosial Media</h4><button class="small-add" id="saveContact">💾 Simpan</button></div>
      <p class="panel-help">Atur informasi kontak yang akan dipakai oleh blok <b>Kontak Dinamis</b> dan footer website.</p>
      <label class="setting-label">Alamat<textarea id="contactAddress" rows="3" maxlength="300"></textarea></label>
      <label class="setting-label">Telepon<input id="contactPhone" maxlength="50" placeholder="0251-xxxxxxx"></label>
      <label class="setting-label">WhatsApp<input id="contactWhatsapp" maxlength="30" placeholder="62812xxxxxxxx"></label>
      <label class="setting-label">Email<input id="contactEmail" maxlength="120" placeholder="info@sdnciburayut01.com"></label>
      <label class="setting-label">Link Google Maps<input id="contactMapsLink" maxlength="500" placeholder="https://maps.google.com/?q=..."></label>
      <label class="setting-label">Google Maps Embed URL<input id="contactMapsEmbed" maxlength="700" placeholder="https://www.google.com/maps/embed?... "></label>
      <div class="panel-section"><h4>Sosial Media</h4>
        <label class="setting-label">Facebook<input id="contactFacebook" maxlength="300" placeholder="https://facebook.com/... "></label>
        <label class="setting-label">Instagram<input id="contactInstagram" maxlength="300" placeholder="https://instagram.com/... "></label>
        <label class="setting-label">YouTube<input id="contactYoutube" maxlength="300" placeholder="https://youtube.com/@... "></label>
      </div>
      <button class="insert-item" data-add="contact"><span>📍</span><div><b>Kontak Dinamis</b><small>Kontak, WhatsApp, Maps & sosial media</small></div></button>
    </div>
    <div class="builder-panel" id="panel-pages" hidden>
      <div class="panel-title-row"><h4>Halaman</h4><button class="small-add" id="addPage">＋ Tambah</button></div>
      <div id="pageList" class="page-list"><div class="panel-loading">Memuat halaman...</div></div>
      <p class="panel-help">Beranda tidak dapat dihapus. Halaman baru tersimpan sebagai Draft.</p>
    </div>
    <div class="builder-panel" id="panel-media" hidden>
      <div class="panel-title-row"><h4>Media Library</h4><button class="small-add" id="mediaUploadBtn">＋ Upload</button></div>
      <input id="mediaInput" type="file" accept="image/jpeg,image/png,image/webp,image/gif" hidden>
      <p class="panel-help">Upload gambar sampai 8 MB. Klik gambar untuk memakai URL-nya di elemen gambar.</p>
      <div id="mediaGrid" class="media-grid"><div class="panel-loading">Memuat media...</div></div>
    </div>
    <div class="builder-panel" id="panel-navbar" hidden>
      <div class="panel-title-row"><h4>Header & Navbar</h4><button class="small-add" id="saveNavbar">💾 Simpan</button></div>
      <label class="setting-label navbar-toggle"><span>Tampilkan Navbar</span><input id="navEnabled" type="checkbox" checked></label>
      <label class="setting-label">Gaya Navbar<select id="navStyle"><option value="glass">Glass / Modern</option><option value="solid">Solid</option><option value="minimal">Minimal</option></select></label>
      <div class="panel-section"><h4>Menu Navigasi</h4><div id="navItems" class="nav-items"></div><button class="small-add full" id="addNavItem">＋ Tambah Menu</button></div>
      <div class="panel-section"><h4>Tombol Aksi</h4>
        <label class="setting-label">Teks Tombol<input id="navCtaText" maxlength="60"></label>
        <label class="setting-label">Link Tombol<input id="navCtaUrl" maxlength="300" placeholder="/auth/login.php"></label>
      </div>
      <p class="panel-help">Urutan menu dapat digeser dengan tombol ↑ ↓. Link dapat menuju halaman sekolah atau alamat lain.</p>
    </div>
    <div class="builder-panel" id="panel-header" hidden>
      <div class="panel-title-row"><h4>Visual Header</h4><button class="small-add" id="saveHeader">💾 Simpan</button></div>
      <label class="setting-label header-check"><span>Header Sticky saat Scroll</span><input id="headerSticky" type="checkbox"></label>
      <label class="setting-label header-check"><span>Transparan di atas Hero</span><input id="headerTransparent" type="checkbox"></label>
      <label class="setting-label">Tinggi Header <output id="headerHeightOut">78 px</output><input id="headerHeight" type="range" min="56" max="120" step="1"></label>
      <label class="setting-label">Lebar Logo <output id="headerLogoWidthOut">46 px</output><input id="headerLogoWidth" type="range" min="32" max="72" step="1"></label>
      <label class="setting-label">Posisi Isi Header<select id="headerAlign"><option value="between">Logo kiri · Menu kanan</option><option value="center">Semua terpusat</option><option value="left">Menu dekat logo</option></select></label>
      <label class="setting-label">Warna Header<input id="headerBg" type="color"></label>
      <label class="setting-label header-check"><span>Overlay Hero</span><input id="headerOverlay" type="checkbox"></label>
      <p class="panel-help">Atur header secara visual. Perubahan langsung terlihat di preview dan akan ikut website publik setelah disimpan.</p>
    </div>
    <div class="builder-panel" id="panel-hero" hidden>
      <div class="panel-title-row"><h4>Hero Section</h4><button class="small-add" id="saveHero">💾 Simpan</button></div>
      <p class="panel-help">Atur Hero utama. Perubahan langsung terlihat di preview dan ikut saat Publish.</p>
      <button class="small-add full" id="pickHeroMedia">🖼️ Pilih dari Media Library</button>
      <label class="setting-label">Eyebrow<input id="heroEyebrow" maxlength="80"></label>
      <label class="setting-label">Judul Hero<input id="heroTitle" maxlength="180"></label>
      <label class="setting-label">Deskripsi<textarea id="heroSubtitle" rows="4" maxlength="500"></textarea></label>
      <div class="hero-two-col"><label class="setting-label">Tinggi <output id="heroHeightOut">520 px</output><input id="heroHeight" type="range" min="320" max="760" step="10"></label>
      <label class="setting-label">Posisi Teks<select id="heroAlign"><option value="left">Kiri</option><option value="center">Tengah</option><option value="right">Kanan</option></select></label></div>
      <label class="setting-label">Posisi Gambar<select id="heroPosition"><option value="left">Kiri</option><option value="center">Tengah</option><option value="right">Kanan</option><option value="top">Atas</option><option value="bottom">Bawah</option></select></label>
      <label class="setting-label">Warna Teks<input id="heroTextColor" type="color"></label>
      <label class="setting-label hero-check"><span>Overlay Gelap</span><input id="heroOverlay" type="checkbox"></label>
      <label class="setting-label">Animasi<select id="heroAnimation"><option value="fade">Fade</option><option value="slide">Slide Up</option><option value="zoom">Zoom</option><option value="none">Tanpa Animasi</option></select></label>
      <div class="panel-section"><h4>Tombol Utama</h4><label class="setting-label">Teks<input id="heroButtonText" maxlength="60"></label><label class="setting-label">Link<input id="heroButtonUrl" maxlength="300"></label></div>
      <div class="panel-section"><h4>Tombol Kedua</h4><label class="setting-label">Teks<input id="heroButton2Text" maxlength="60"></label><label class="setting-label">Link<input id="heroButton2Url" maxlength="300"></label></div>
      <label class="setting-label">URL Gambar Hero<input id="heroImage" maxlength="500" placeholder="/uploads/builder/nama-gambar.webp"></label>
    </div>
    <div class="builder-panel" id="panel-section" hidden>
      <div class="panel-title-row"><h4>Section Terpilih</h4><span id="sectionTypeBadge" class="section-badge">—</span></div>
      <label class="setting-label">Jarak Atas <output id="sectionPadTopOut">40 px</output><input id="sectionPadTop" type="range" min="0" max="160" step="4" value="40"></label>
      <label class="setting-label">Jarak Bawah <output id="sectionPadBottomOut">40 px</output><input id="sectionPadBottom" type="range" min="0" max="160" step="4" value="40"></label>
      <label class="setting-label">Warna Latar<input id="sectionBgColor" type="color" value="#ffffff"></label>
      <label class="setting-label section-check"><span>Tampilkan Section</span><input id="sectionVisible" type="checkbox" checked></label>
      <div class="section-actions">
        <button class="small-add full" id="sectionDuplicate">⧉ Duplikat Section</button>
        <button class="small-add full danger-outline" id="sectionDelete">🗑️ Hapus Section</button>
      </div>
      <p class="panel-help">Pilih blok di preview untuk mengatur tampilan. Perubahan masuk ke Draft.</p>
    </div>
    <div class="builder-panel" id="panel-themes" hidden>
      <h4>Tema Website</h4>
      <div class="theme-grid">
        <button class="theme-card" data-theme="blue"><span class="theme-preview theme-blue"></span><b>Blue School</b><small>Profesional</small></button>
        <button class="theme-card" data-theme="emerald"><span class="theme-preview theme-emerald"></span><b>Emerald</b><small>Segar</small></button>
        <button class="theme-card" data-theme="gold"><span class="theme-preview theme-gold"></span><b>Gold</b><small>Elegan</small></button>
        <button class="theme-card" data-theme="dark"><span class="theme-preview theme-dark"></span><b>Dark</b><small>Modern</small></button>
      </div>
      <div class="theme-status" id="themeStatus">Tema aktif: Blue School</div>
      <hr class="panel-divider">
      <div class="panel-title-row"><h4>Identitas Website</h4><button class="small-add" id="saveSettings">💾 Simpan</button></div>
      <label class="setting-label">Nama Sekolah<input id="setSiteName" maxlength="120"></label>
      <label class="setting-label">Tagline<input id="setTagline" maxlength="180"></label>
      <label class="setting-label">Logo URL<input id="setLogo" placeholder="/uploads/logo.png"></label>
      <label class="setting-label">Favicon URL<input id="setFavicon" placeholder="/uploads/favicon.png"></label>
      <label class="setting-label">Gambar Hero URL<input id="setHero" placeholder="/uploads/hero.jpg"></label>
      <label class="setting-label">Alamat<input id="setAddress" maxlength="250"></label>
      <label class="setting-label">Telepon<input id="setPhone" maxlength="50"></label>
      <label class="setting-label">Email<input id="setEmail" maxlength="120"></label>
      <label class="setting-label">Footer<input id="setFooter" maxlength="250"></label>
      <label class="setting-label">Warna Utama<input id="setColor" type="color"></label>
      <hr class="panel-divider">
      <div class="panel-title-row"><h4>🔎 SEO & Metadata</h4><button class="small-add" id="saveSeo">💾 Simpan SEO</button></div>
      <label class="setting-label">SEO Title<input id="seoTitle" maxlength="160" placeholder="Judul yang tampil di Google"></label>
      <label class="setting-label">Meta Description<textarea id="seoDescription" rows="3" maxlength="320" placeholder="Deskripsi singkat website"></textarea></label>
      <label class="setting-label">Keywords<input id="seoKeywords" maxlength="500" placeholder="kata kunci, sekolah, bogor"></label>
      <label class="setting-label">Author<input id="seoAuthor" maxlength="120"></label>
      <label class="setting-label">OG Image URL<input id="seoOgImage" maxlength="500" placeholder="/uploads/builder/og-image.jpg"></label>
      <label class="setting-label">Canonical URL<input id="seoCanonical" maxlength="500" placeholder="https://sdnciburayut01.com/"></label>
      <label class="setting-label">Robots<select id="seoRobots"><option value="index,follow">Index + Follow</option><option value="noindex,follow">Noindex + Follow</option><option value="index,nofollow">Index + Nofollow</option><option value="noindex,nofollow">Noindex + Nofollow</option></select></label>
      <p class="panel-help">SEO berlaku untuk website publik. Sitemap dan robots.txt juga disediakan otomatis.</p>
    </div>
  </div>
</aside>
<div class="overlay" id="overlay"></div>
</div></div>

<div class="block-toolbar" id="blockToolbar" hidden>
  <button data-action="edit" title="Edit">✏️</button>
  <button data-action="style" title="Gaya Elemen">🎨</button>
  <button data-action="duplicate" title="Duplikat">⧉</button>
  <button data-action="up" title="Naik">↑</button>
  <button data-action="down" title="Turun">↓</button>
  <button data-action="hide" title="Tampilkan/Sembunyikan">👁</button>
  <button data-action="delete" title="Hapus">🗑️</button>
</div>

<div class="modal" id="editModal">
  <div class="modal-box rich-text-modal">
    <button class="modal-close" id="closeModal">×</button>
    <h3>✍️ Text Editor Pro</h3>
    <div class="rich-toolbar" id="richToolbar" role="toolbar" aria-label="Format teks">
      <select id="richHeading" title="Gaya teks">
        <option value="p">Paragraf</option><option value="h1">Heading 1</option><option value="h2">Heading 2</option><option value="h3">Heading 3</option><option value="h4">Heading 4</option><option value="h5">Heading 5</option><option value="h6">Heading 6</option>
      </select>
      <button type="button" data-cmd="bold" title="Tebal"><b>B</b></button>
      <button type="button" data-cmd="italic" title="Miring"><i>I</i></button>
      <button type="button" data-cmd="underline" title="Garis bawah"><u>U</u></button>
      <button type="button" data-cmd="strikeThrough" title="Coret">S̶</button>
      <span class="rich-sep"></span>
      <button type="button" data-cmd="justifyLeft" title="Rata kiri">≡</button>
      <button type="button" data-cmd="justifyCenter" title="Rata tengah">≣</button>
      <button type="button" data-cmd="justifyRight" title="Rata kanan">≡</button>
      <button type="button" data-cmd="justifyFull" title="Rata kiri-kanan">☰</button>
      <span class="rich-sep"></span>
      <button type="button" data-cmd="insertUnorderedList" title="Bullet">• List</button>
      <button type="button" data-cmd="insertOrderedList" title="Nomor">1. List</button>
      <button type="button" id="richLink" title="Sisipkan link">🔗</button>
      <label class="rich-color" title="Warna teks">A<input id="richColor" type="color" value="#0f172a"></label>
      <button type="button" id="richClear" title="Hapus format">Tx</button>
      <span class="rich-sep"></span>
      <button type="button" data-cmd="undo" title="Undo">↶</button>
      <button type="button" data-cmd="redo" title="Redo">↷</button>
    </div>
    <div id="richEditor" class="rich-editor" contenteditable="true" spellcheck="true" data-placeholder="Tulis konten di sini..."></div>
    <p class="rich-help">Tip: blok sebagian kata lalu pilih <b>B</b>, warna, atau 🔗 untuk memformat hanya bagian tersebut.</p>
    <div class="modal-actions"><button class="cancel" id="cancelEdit">Batal</button><button class="save" id="saveEdit">✓ Terapkan ke Draft</button></div>
  </div>
</div>
<div class="modal" id="styleModal">
  <div class="modal-box element-editor-box">
    <button class="modal-close" id="closeStyleModal">×</button>
    <h3>🎨 Gaya Elemen</h3>
    <p class="modal-help">Atur tampilan elemen yang dipilih. Perubahan langsung terlihat di preview.</p>
    <div class="element-editor-grid">
      <label>Ukuran Font <input id="elFontSize" type="range" min="10" max="80" step="1"><output id="elFontSizeOut">16 px</output></label>
      <label>Warna Teks <input id="elColor" type="color"></label>
      <label>Perataan <select id="elAlign"><option value="left">Kiri</option><option value="center">Tengah</option><option value="right">Kanan</option><option value="justify">Rata</option></select></label>
      <label>Lebar Maksimal <input id="elMaxWidth" type="range" min="120" max="1100" step="10"><output id="elMaxWidthOut">100%</output></label>
      <label>Margin Atas <input id="elMarginTop" type="range" min="0" max="100" step="1"><output id="elMarginTopOut">0 px</output></label>
      <label>Margin Bawah <input id="elMarginBottom" type="range" min="0" max="100" step="1"><output id="elMarginBottomOut">0 px</output></label>
      <label>Padding <input id="elPadding" type="range" min="0" max="60" step="1"><output id="elPaddingOut">0 px</output></label>
      <label>Background <input id="elBg" type="color"></label>
      <label>Border Radius <input id="elRadius" type="range" min="0" max="40" step="1"><output id="elRadiusOut">0 px</output></label>
      <label>Shadow<select id="elShadow"><option value="none">Tidak ada</option><option value="soft">Lembut</option><option value="medium">Sedang</option><option value="strong">Kuat</option></select></label>
      <label>Border<select id="elBorder"><option value="none">Tidak ada</option><option value="thin">Tipis</option><option value="medium">Sedang</option></select></label>
      <label class="element-check"><span>Tampilkan</span><input id="elVisible" type="checkbox" checked></label>
    </div>
    <div class="modal-actions"><button class="cancel" id="cancelStyle">Tutup</button><button class="save" id="saveStyle">✓ Terapkan</button></div>
  </div>
</div>
<div class="modal" id="buttonModal">
  <div class="modal-box button-editor-box">
    <button class="modal-close" id="closeButtonModal">×</button>
    <h3>🔘 Button Editor Pro</h3>
    <p class="modal-help">Atur teks, link, warna, ukuran, bentuk, dan efek tombol secara live.</p>
    <div class="button-editor-grid">
      <label class="button-full">Teks Tombol<input id="btnText" maxlength="80"></label>
      <label class="button-full">Link / URL<input id="btnUrl" maxlength="500" placeholder="/auth/login.php"></label>
      <label>Ukuran Font <input id="btnFontSize" type="range" min="10" max="32" step="1"><output id="btnFontSizeOut">16 px</output></label>
      <label>Radius <input id="btnRadius" type="range" min="0" max="40" step="1"><output id="btnRadiusOut">10 px</output></label>
      <label>Padding Vertikal <input id="btnPadY" type="range" min="4" max="28" step="1"><output id="btnPadYOut">12 px</output></label>
      <label>Padding Horizontal <input id="btnPadX" type="range" min="8" max="60" step="1"><output id="btnPadXOut">22 px</output></label>
      <label>Warna Tombol<input id="btnBg" type="color" value="#1565c0"></label>
      <label>Warna Teks<input id="btnColor" type="color" value="#ffffff"></label>
      <label>Perataan<select id="btnAlign"><option value="left">Kiri</option><option value="center">Tengah</option><option value="right">Kanan</option></select></label>
      <label>Lebar<select id="btnWidth"><option value="auto">Otomatis</option><option value="full">Lebar Penuh</option></select></label>
      <label>Target<select id="btnTarget"><option value="_self">Tab yang sama</option><option value="_blank">Tab baru</option></select></label>
      <label>Shadow<select id="btnShadow"><option value="none">Tidak ada</option><option value="soft">Lembut</option><option value="medium">Sedang</option><option value="strong">Kuat</option></select></label>
      <label class="button-check"><span>Tampilkan tombol</span><input id="btnVisible" type="checkbox" checked></label>
      <label class="button-check"><span>Underline saat hover</span><input id="btnUnderline" type="checkbox"></label>
    </div>
    <div class="modal-actions"><button class="cancel" id="cancelButton">Batal</button><button class="save" id="saveButton">✓ Terapkan ke Draft</button></div>
  </div>
</div>
<div class="modal" id="galleryModal">
  <div class="modal-box gallery-editor-box">
    <button class="modal-close" id="closeGalleryModal">×</button>
    <h3>🖼️ Gallery Builder Pro</h3>
    <p class="modal-help">Atur foto, jumlah kolom, jarak, radius, caption, dan lightbox.</p>
    <div class="gallery-preview-live" id="galleryLivePreview"></div>
    <div class="gallery-editor-grid">
      <label class="gallery-full">URL Gambar <textarea id="galleryUrls" rows="5" placeholder="Satu URL per baris"></textarea></label>
      <label>Kolom Desktop<select id="galleryCols"><option value="1">1</option><option value="2">2</option><option value="3" selected>3</option><option value="4">4</option></select></label>
      <label>Jarak <input id="galleryGap" type="range" min="0" max="40" value="14"><output id="galleryGapOut">14 px</output></label>
      <label>Radius <input id="galleryRadius" type="range" min="0" max="40" value="14"><output id="galleryRadiusOut">14 px</output></label>
      <label>Rasio<select id="galleryFit"><option value="cover" selected>Cover</option><option value="contain">Contain</option></select></label>
      <label class="gallery-check"><span>Caption foto</span><input id="galleryCaption" type="checkbox"></label>
      <label class="gallery-check"><span>Lightbox saat diklik</span><input id="galleryLightbox" type="checkbox" checked></label>
    </div>
    <div class="modal-actions"><button class="cancel" id="cancelGallery">Batal</button><button class="save" id="saveGallery">✓ Terapkan ke Draft</button></div>
  </div>
</div>
<div class="toast" id="toast"></div>

<script>
const builderCsrfToken = <?=json_encode(csrf_token())?>;
const nativeBuilderFetch = window.fetch.bind(window);
window.fetch = (input, init = {}) => {
  const method = String(init.method || 'GET').toUpperCase();
  if (method === 'POST') {
    const headers = new Headers(init.headers || {});
    headers.set('X-CSRF-Token', builderCsrfToken);
    init.headers = headers;
  }
  return nativeBuilderFetch(input, init);
};
const responsiveStage=document.getElementById('responsiveStage');
const deviceMeta=document.getElementById('deviceMeta');
const zoomValue=document.getElementById('zoomValue');
let previewDevice='desktop';
let previewZoom=100;
const deviceWidths={desktop:null,tablet:768,mobile:390};
function applyDevicePreview(device){
  previewDevice=device;
  document.querySelectorAll('.device-btn').forEach(b=>b.classList.toggle('active',b.dataset.device===device));
  responsiveStage.dataset.device=device;
  const width=deviceWidths[device];
  if(width){ responsiveStage.style.setProperty('--device-width',width+'px'); responsiveStage.classList.add('is-device'); }
  else { responsiveStage.style.removeProperty('--device-width'); responsiveStage.classList.remove('is-device'); }
  deviceMeta.textContent=(device==='desktop'?'Desktop':device==='tablet'?'Tablet · 768px':'HP · 390px')+' · '+previewZoom+'%';
  applyPreviewZoom();
}
function applyPreviewZoom(){
  zoomValue.textContent=previewZoom+'%';
  responsiveStage.style.setProperty('--preview-scale',(previewZoom/100).toFixed(2));
  deviceMeta.textContent=(previewDevice==='desktop'?'Desktop':previewDevice==='tablet'?'Tablet · 768px':'HP · 390px')+' · '+previewZoom+'%';
}
document.querySelectorAll('.device-btn').forEach(b=>b.addEventListener('click',()=>applyDevicePreview(b.dataset.device)));
document.querySelectorAll('.zoom-btn[data-zoom]').forEach(b=>b.addEventListener('click',()=>{previewZoom=Math.max(60,Math.min(140,previewZoom+(parseInt(b.dataset.zoom)-100)));applyPreviewZoom();}));
document.getElementById('zoomReset')?.addEventListener('click',()=>{previewZoom=100;applyPreviewZoom();});
applyDevicePreview('desktop');

const currentPageSlug=<?=json_encode($pageSlug)?>;
const currentPageTitle=<?=json_encode($pageTitle)?>;
const preview=document.getElementById('sitePreview');
const modal=document.getElementById('editModal');
const editText=document.getElementById('richEditor');
const statusEl=document.getElementById('draftStatus');
const saveBtn=document.getElementById('saveBtn');
const toast=document.getElementById('toast');
let selected=null, dirty=false, history=[], future=[];
const homeTemplate=preview.innerHTML;

function showToast(t){toast.textContent=t;toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),2200)}
function markDirty(){dirty=true;statusEl.textContent='● Belum disimpan';statusEl.className='draft-status dirty';saveBtn.classList.remove('saved')}
function snapshot(){return preview.innerHTML}
function pushHistory(){history.push(snapshot());if(history.length>20)history.shift();future=[]}
function bindEditable(){
 document.querySelectorAll('#sitePreview > .editable, #sitePreview > .added-block').forEach(el=>{
   el.onclick=(e)=>{
     if(e.target.closest('.preview-button,.hero-btn-primary,.hero-btn-secondary,a,button')) return;
     selectSection(el);
     const target=el.querySelector('h1,h2,h3,p')||el;
     selected=target; editText.innerHTML=target.innerHTML; syncRichHeading(target); modal.classList.add('show');
     e.stopPropagation();
   };
   el.onmouseenter=()=>showBlockToolbar(el);
   el.onmouseleave=()=>setTimeout(()=>{if(!toolbar.matches(':hover')) hideBlockToolbar()},120);
 });
}
const toolbar=document.getElementById('blockToolbar');
let selectedSection=null;
function showBlockToolbar(el){
 selectedSection=el; selectSection(el);
 toolbar.hidden=false;
 const r=el.getBoundingClientRect(); const pr=preview.getBoundingClientRect();
 toolbar.style.left=Math.max(8,r.right-pr.left-220)+'px';
 toolbar.style.top=Math.max(8,r.top-pr.top+8)+'px';
}
function hideBlockToolbar(){if(!selectedSection) return; toolbar.hidden=true;}
function selectSection(el){
 if(!el)return;
 document.querySelectorAll('#sitePreview > .editable, #sitePreview > .added-block').forEach(x=>x.classList.remove('section-selected'));
 selectedSection=el; el.classList.add('section-selected');
 const type=el.dataset.type||el.querySelector('.content-block')?.className?.split(' ').pop()||'section';
 const badge=document.getElementById('sectionTypeBadge'); if(badge)badge.textContent=type;
 const cs=getComputedStyle(el);
 const pt=parseInt(cs.paddingTop)||40,pb=parseInt(cs.paddingBottom)||40;
 const a=document.getElementById('sectionPadTop'),b=document.getElementById('sectionPadBottom'),bg=document.getElementById('sectionBgColor'),vis=document.getElementById('sectionVisible');
 if(a){a.value=Math.min(160,pt);document.getElementById('sectionPadTopOut').textContent=a.value+' px';}
 if(b){b.value=Math.min(160,pb);document.getElementById('sectionPadBottomOut').textContent=b.value+' px';}
 if(bg){const c=rgbToHex(cs.backgroundColor); if(c)bg.value=c;}
 if(vis)vis.checked=el.style.display!=='none';
}
function rgbToHex(v){const m=v.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);return m?'#'+[m[1],m[2],m[3]].map(x=>parseInt(x).toString(16).padStart(2,'0')).join(''):null}
function sectionChanged(){
 if(!selectedSection)return; pushHistory();
 selectedSection.style.paddingTop=document.getElementById('sectionPadTop').value+'px';
 selectedSection.style.paddingBottom=document.getElementById('sectionPadBottom').value+'px';
 selectedSection.style.backgroundColor=document.getElementById('sectionBgColor').value;
 selectedSection.style.display=document.getElementById('sectionVisible').checked?'':'none';
 document.getElementById('sectionPadTopOut').textContent=document.getElementById('sectionPadTop').value+' px';
 document.getElementById('sectionPadBottomOut').textContent=document.getElementById('sectionPadBottom').value+' px';
 markDirty();
}
['sectionPadTop','sectionPadBottom','sectionBgColor','sectionVisible'].forEach(id=>document.getElementById(id)?.addEventListener('input',sectionChanged));
document.getElementById('sectionDuplicate').onclick=()=>{if(!selectedSection)return;pushHistory();const c=selectedSection.cloneNode(true);c.dataset.id='block-'+Date.now();selectedSection.parentNode.insertBefore(c,selectedSection.nextSibling);bindLayoutColumns();bindEditable();bindMedia();bindGallery();makeDraggable();selectSection(c);markDirty();showToast('Section diduplikat ✓')};
document.getElementById('sectionDelete').onclick=()=>{if(!selectedSection)return; if(!confirm('Hapus section ini dari Draft?'))return;pushHistory();selectedSection.remove();selectedSection=null;toolbar.hidden=true;markDirty();showToast('Section dihapus')};
toolbar.addEventListener('mouseenter',()=>{});
toolbar.addEventListener('mouseleave',()=>hideBlockToolbar());
toolbar.querySelectorAll('button').forEach(btn=>btn.onclick=(e)=>{e.stopPropagation();if(!selectedSection)return;const a=btn.dataset.action;
 if(a==='edit'){const t=selectedSection.querySelector('h1,h2,h3,p')||selectedSection;selected=t;editText.innerHTML=cleanRichHtml(t.innerHTML);syncRichHeading(t);modal.classList.add('show');}
 if(a==='style'){openStyleEditor(selectedElementForStyle());}
 if(a==='duplicate')document.getElementById('sectionDuplicate').click();
 if(a==='up'||a==='down'){pushHistory();const n=a==='up'?selectedSection.previousElementSibling:selectedSection.nextElementSibling;if(n){a==='up'?selectedSection.parentNode.insertBefore(selectedSection,n):selectedSection.parentNode.insertBefore(n,selectedSection);markDirty();showToast('Urutan section diubah')}}
 if(a==='hide'){pushHistory();selectedSection.style.display=selectedSection.style.display==='none'?'':'none';markDirty();showToast(selectedSection.style.display==='none'?'Section disembunyikan':'Section ditampilkan')}
 if(a==='delete')document.getElementById('sectionDelete').click();
});

const styleModal=document.getElementById('styleModal');
const styleControls=['elFontSize','elColor','elAlign','elMaxWidth','elMarginTop','elMarginBottom','elPadding','elBg','elRadius','elShadow','elBorder','elVisible'];
function hexFromComputed(v){return rgbToHex(v)||'#ffffff'}
function shadowValue(v){return v==='soft'?'0 6px 18px rgba(15,23,42,.10)':v==='medium'?'0 10px 28px rgba(15,23,42,.16)':v==='strong'?'0 16px 42px rgba(15,23,42,.22)':'none'}
function shadowName(v){if(v==='none')return 'none';if(v.includes('16px'))return 'strong';if(v.includes('10px'))return 'medium';return 'soft'}
function borderValue(v){return v==='thin'?'1px solid rgba(100,116,139,.25)':v==='medium'?'2px solid rgba(100,116,139,.32)':'none'}
function borderName(v){if(v==='2px')return 'medium';if(v==='1px')return 'thin';return 'none'}
function selectedElementForStyle(){
  if(selected && selected !== selectedSection && selected.nodeType===1) return selected;
  if(selectedSection) return selectedSection.querySelector('h1,h2,h3,h4,h5,p,span,a,button')||selectedSection;
  return null;
}
function openStyleEditor(el){
  if(!el)return; selected=el;
  const cs=getComputedStyle(el);
  const fs=Math.max(10,Math.min(80,parseInt(cs.fontSize)||16));
  const mw=parseInt(cs.maxWidth)||Math.min(1100,el.parentElement?.clientWidth||1000);
  const mt=parseInt(cs.marginTop)||0, mb=parseInt(cs.marginBottom)||0, pad=parseInt(cs.paddingTop)||0, rad=parseInt(cs.borderRadius)||0;
  elFontSize.value=fs;elFontSizeOut.textContent=fs+' px';
  elColor.value=hexFromComputed(cs.color);elAlign.value=cs.textAlign==='start'?'left':cs.textAlign;
  elMaxWidth.value=Math.max(120,Math.min(1100,mw));elMaxWidthOut.textContent=(cs.maxWidth==='none'?'100%':Math.round((mw/(el.parentElement?.clientWidth||mw))*100)+'%');
  elMarginTop.value=Math.min(100,mt);elMarginTopOut.textContent=mt+' px';elMarginBottom.value=Math.min(100,mb);elMarginBottomOut.textContent=mb+' px';
  elPadding.value=Math.min(60,pad);elPaddingOut.textContent=pad+' px';elBg.value=hexFromComputed(cs.backgroundColor);elRadius.value=Math.min(40,rad);elRadiusOut.textContent=rad+' px';
  elShadow.value=shadowName(cs.boxShadow);elBorder.value=borderName(cs.borderTopWidth);elVisible.checked=cs.display!=='none';styleModal.classList.add('show');
}
function applyElementStyle(){
  const el=selectedElementForStyle();if(!el)return;pushHistory();
  el.style.fontSize=document.getElementById('elFontSize').value+'px';
  el.style.color=document.getElementById('elColor').value;el.style.textAlign=document.getElementById('elAlign').value;
  el.style.maxWidth=document.getElementById('elMaxWidth').value+'px';el.style.marginTop=document.getElementById('elMarginTop').value+'px';el.style.marginBottom=document.getElementById('elMarginBottom').value+'px';
  el.style.padding=document.getElementById('elPadding').value+'px';el.style.backgroundColor=document.getElementById('elBg').value;el.style.borderRadius=document.getElementById('elRadius').value+'px';
  el.style.boxShadow=shadowValue(document.getElementById('elShadow').value);el.style.border=borderValue(document.getElementById('elBorder').value);el.style.display=document.getElementById('elVisible').checked?'':'none';
  styleModal.classList.remove('show');markDirty();showToast('Gaya elemen diterapkan ✓');
}
function liveStyle(){
 const el=selectedElementForStyle();if(!el)return;
 el.style.fontSize=elFontSize.value+'px';elFontSizeOut.textContent=elFontSize.value+' px';el.style.color=elColor.value;el.style.textAlign=elAlign.value;
 el.style.maxWidth=elMaxWidth.value+'px';elMaxWidthOut.textContent=elMaxWidth.value+' px';el.style.marginTop=elMarginTop.value+'px';elMarginTopOut.textContent=elMarginTop.value+' px';el.style.marginBottom=elMarginBottom.value+'px';elMarginBottomOut.textContent=elMarginBottom.value+' px';
 el.style.padding=elPadding.value+'px';elPaddingOut.textContent=elPadding.value+' px';el.style.backgroundColor=elBg.value;el.style.borderRadius=elRadius.value+'px';elRadiusOut.textContent=elRadius.value+' px';el.style.boxShadow=shadowValue(elShadow.value);el.style.border=borderValue(elBorder.value);el.style.display=elVisible.checked?'':'none';
}
const elFontSize=document.getElementById('elFontSize'),elFontSizeOut=document.getElementById('elFontSizeOut'),elColor=document.getElementById('elColor'),elAlign=document.getElementById('elAlign'),elMaxWidth=document.getElementById('elMaxWidth'),elMaxWidthOut=document.getElementById('elMaxWidthOut'),elMarginTop=document.getElementById('elMarginTop'),elMarginTopOut=document.getElementById('elMarginTopOut'),elMarginBottom=document.getElementById('elMarginBottom'),elMarginBottomOut=document.getElementById('elMarginBottomOut'),elPadding=document.getElementById('elPadding'),elPaddingOut=document.getElementById('elPaddingOut'),elBg=document.getElementById('elBg'),elRadius=document.getElementById('elRadius'),elRadiusOut=document.getElementById('elRadiusOut'),elShadow=document.getElementById('elShadow'),elBorder=document.getElementById('elBorder'),elVisible=document.getElementById('elVisible');
styleControls.forEach(id=>document.getElementById(id)?.addEventListener('input',liveStyle));styleControls.forEach(id=>document.getElementById(id)?.addEventListener('change',liveStyle));
document.getElementById('saveStyle').onclick=applyElementStyle;document.getElementById('cancelStyle').onclick=document.getElementById('closeStyleModal').onclick=()=>styleModal.classList.remove('show');

// STEP 19 — Button Editor Pro
let selectedButton=null;
const buttonModal=document.getElementById('buttonModal');
const btnText=document.getElementById('btnText'),btnUrl=document.getElementById('btnUrl'),btnFontSize=document.getElementById('btnFontSize'),btnFontSizeOut=document.getElementById('btnFontSizeOut'),btnRadius=document.getElementById('btnRadius'),btnRadiusOut=document.getElementById('btnRadiusOut'),btnPadY=document.getElementById('btnPadY'),btnPadYOut=document.getElementById('btnPadYOut'),btnPadX=document.getElementById('btnPadX'),btnPadXOut=document.getElementById('btnPadXOut'),btnBg=document.getElementById('btnBg'),btnColor=document.getElementById('btnColor'),btnAlign=document.getElementById('btnAlign'),btnWidth=document.getElementById('btnWidth'),btnTarget=document.getElementById('btnTarget'),btnShadow=document.getElementById('btnShadow'),btnVisible=document.getElementById('btnVisible'),btnUnderline=document.getElementById('btnUnderline');
function buttonShadow(v){return v==='soft'?'0 6px 18px rgba(15,23,42,.12)':v==='medium'?'0 10px 26px rgba(15,23,42,.18)':v==='strong'?'0 14px 36px rgba(15,23,42,.24)':'none';}
function buttonShadowName(v){if(!v||v==='none')return 'none';if(v.includes('14px'))return 'strong';if(v.includes('10px'))return 'medium';return 'soft';}
function buttonHex(v){return rgbToHex(v)||'#ffffff';}
function openButtonEditor(btn){
 if(!btn)return;selectedButton=btn;selected=btn;
 const cs=getComputedStyle(btn);
 btnText.value=btn.textContent.trim();btnUrl.value=btn.getAttribute('href')||'';
 const fs=Math.max(10,Math.min(32,parseInt(cs.fontSize)||16));btnFontSize.value=fs;btnFontSizeOut.textContent=fs+' px';
 const rad=Math.max(0,Math.min(40,parseInt(cs.borderRadius)||10));btnRadius.value=rad;btnRadiusOut.textContent=rad+' px';
 const py=Math.max(4,Math.min(28,parseInt(cs.paddingTop)||12)),px=Math.max(8,Math.min(60,parseInt(cs.paddingLeft)||22));btnPadY.value=py;btnPadYOut.textContent=py+' px';btnPadX.value=px;btnPadXOut.textContent=px+' px';
 btnBg.value=buttonHex(cs.backgroundColor);btnColor.value=buttonHex(cs.color);btnAlign.value=['left','center','right'].includes(cs.textAlign)?cs.textAlign:'center';btnWidth.value=btn.style.width==='100%'?'full':'auto';btnTarget.value=btn.getAttribute('target')||'_self';btnShadow.value=buttonShadowName(cs.boxShadow);btnVisible.checked=cs.display!=='none';btnUnderline.checked=btn.dataset.underline==='1';
 buttonModal.classList.add('show');
}
function liveButtonStyle(){
 const b=selectedButton;if(!b)return;
 b.textContent=btnText.value; b.href=btnUrl.value||'#'; b.target=btnTarget.value;
 b.style.fontSize=btnFontSize.value+'px';btnFontSizeOut.textContent=btnFontSize.value+' px';b.style.borderRadius=btnRadius.value+'px';btnRadiusOut.textContent=btnRadius.value+' px';b.style.padding=btnPadY.value+'px '+btnPadX.value+'px';btnPadYOut.textContent=btnPadY.value+' px';btnPadXOut.textContent=btnPadX.value+' px';b.style.background=btnBg.value;b.style.color=btnColor.value;b.style.textAlign=btnAlign.value;b.style.width=btnWidth.value==='full'?'100%':'';b.style.display=btnVisible.checked?'inline-flex':'none';b.style.boxShadow=buttonShadow(btnShadow.value);b.dataset.underline=btnUnderline.checked?'1':'0';b.style.textDecoration=btnUnderline.checked?'underline':'none';
}
['btnText','btnUrl','btnFontSize','btnRadius','btnPadY','btnPadX','btnBg','btnColor','btnAlign','btnWidth','btnTarget','btnShadow','btnVisible','btnUnderline'].forEach(id=>{const el=document.getElementById(id);el?.addEventListener('input',()=>{liveButtonStyle();markDirty()});el?.addEventListener('change',()=>{liveButtonStyle();markDirty()});});
document.getElementById('saveButton').onclick=()=>{if(!selectedButton)return;pushHistory();liveButtonStyle();buttonModal.classList.remove('show');markDirty();showToast('Tombol diterapkan ke Draft ✓');};
document.getElementById('cancelButton').onclick=document.getElementById('closeButtonModal').onclick=()=>buttonModal.classList.remove('show');
preview.addEventListener('click',e=>{const b=e.target.closest('a.preview-button,button.preview-button,a.hero-btn-primary,a.hero-btn-secondary');if(!b)return;e.preventDefault();e.stopPropagation();openButtonEditor(b)},true);

function collect(){
 const elements={};
 document.querySelectorAll('.editable').forEach(el=>{
   const id=el.dataset.id;
   elements[id]={html:el.innerHTML};
 });
 return {html:preview.innerHTML,elements:elements,hero_settings:heroSettings,updated_at:new Date().toISOString()};
}
function starterPageHtml(title){
  const safe=escapeHtml(title||'Halaman Baru');
  return `<div class="preview-nav"><div class="preview-logo">01</div><div class="preview-school">SDN CIBURAYUT 01</div><div class="preview-links"><span>Beranda</span><span>Profil</span><span>Informasi</span><span>Guru</span></div></div><div class="editable hero-block" data-id="hero-${Date.now()}" data-type="text"><div class="eyebrow">HALAMAN SEKOLAH</div><h1>${safe}</h1><p>Tambahkan informasi terbaik untuk halaman ini.</p></div><div class="preview-section editable" data-id="content-${Date.now()}" data-type="text"><div class="eyebrow">KONTEN</div><h2>Konten Halaman</h2><p>Klik teks untuk mulai mengedit halaman ${safe}.</p></div>`;
}

async function loadDraft(){
 try{
   const r=await fetch('/builder/load_draft.php?page_slug='+encodeURIComponent(currentPageSlug),{credentials:'same-origin'});
   const d=await r.json();
   if(d.ok && d.draft && d.draft.html){
      preview.innerHTML=d.draft.html;
      cleanUndefinedBlocks();
      bindLayoutColumns();bindEditable();bindMedia();bindGallery();makeDraggable();applyHeroSettings();
      dirty=false;statusEl.textContent='Draft tersimpan';statusEl.className='draft-status ok';
   }else{
      if(currentPageSlug!=='home'){
        preview.innerHTML=starterPageHtml(currentPageTitle);
      } else {
        preview.innerHTML=homeTemplate;
      }
      statusEl.textContent='Draft baru';statusEl.className='draft-status';
      cleanUndefinedBlocks();
      bindLayoutColumns();bindEditable();bindMedia();bindGallery();makeDraggable();
   }
 }catch(e){statusEl.textContent='Siap';bindEditable();}
}
async function saveDraft(){
 saveBtn.classList.add('saving');saveBtn.textContent='⏳ Menyimpan...';
 try{
   const r=await fetch('/builder/save_draft.php',{
     method:'POST',credentials:'same-origin',
     headers:{'Content-Type':'application/json'},
     body:JSON.stringify({...collect(),page_slug:currentPageSlug})
   });
   const d=await r.json();
   if(!r.ok || !d.ok) throw new Error(d.message||'Gagal menyimpan');
   dirty=false;statusEl.textContent='✓ Draft tersimpan';statusEl.className='draft-status ok';
   saveBtn.classList.add('saved');saveBtn.textContent='✓ Tersimpan';showToast('Draft berhasil disimpan');
   setTimeout(()=>{saveBtn.textContent='💾 Simpan Draft';saveBtn.classList.remove('saving')},1600);
 }catch(e){
   saveBtn.classList.remove('saving');saveBtn.textContent='💾 Simpan Draft';
   showToast(e.message||'Gagal menyimpan draft');
 }
}
document.getElementById('saveBtn').onclick=saveDraft;

// STEP 17: Text Editor Pro
function cleanRichHtml(html){
  const box=document.createElement('div'); box.innerHTML=html;
  box.querySelectorAll('script,style,iframe,object,embed,form').forEach(n=>n.remove());
  box.querySelectorAll('*').forEach(n=>{
    [...n.attributes].forEach(a=>{
      const name=a.name.toLowerCase(), value=a.value||'';
      if(name.startsWith('on') || name==='srcdoc') n.removeAttribute(a.name);
      if((name==='href'||name==='src') && /^\s*javascript:/i.test(value)) n.removeAttribute(a.name);
    });
  });
  return box.innerHTML;
}
function syncRichHeading(el){
  const tag=(el?.tagName||'P').toLowerCase();
  const select=document.getElementById('richHeading');
  if(select) select.value=/^h[1-6]$/.test(tag)||tag==='p'?tag:'p';
}
function restoreRichSelection(){
  editText.focus();
}
document.querySelectorAll('#richToolbar [data-cmd]').forEach(btn=>{
  btn.addEventListener('mousedown',e=>e.preventDefault());
  btn.addEventListener('click',()=>{restoreRichSelection();document.execCommand(btn.dataset.cmd,false,null);editText.focus();});
});
document.getElementById('richHeading').addEventListener('change',e=>{
  restoreRichSelection(); document.execCommand('formatBlock',false,e.target.value); editText.focus();
});
document.getElementById('richColor').addEventListener('input',e=>{
  restoreRichSelection(); document.execCommand('foreColor',false,e.target.value); editText.focus();
});
document.getElementById('richLink').addEventListener('mousedown',e=>e.preventDefault());
document.getElementById('richLink').addEventListener('click',()=>{
  restoreRichSelection();
  const url=prompt('Masukkan URL link (contoh: /?page=profil atau https://contoh.com):','');
  if(url===null)return;
  const clean=url.trim(); if(!clean)return;
  if(/^javascript:/i.test(clean)){showToast('URL tidak diizinkan');return;}
  document.execCommand('createLink',false,clean); editText.focus();
});
document.getElementById('richClear').addEventListener('mousedown',e=>e.preventDefault());
document.getElementById('richClear').addEventListener('click',()=>{restoreRichSelection();document.execCommand('removeFormat',false,null);document.execCommand('unlink',false,null);editText.focus();});
editText.addEventListener('paste',e=>{
  e.preventDefault();
  const text=(e.clipboardData||window.clipboardData).getData('text/plain');
  document.execCommand('insertText',false,text);
});
editText.addEventListener('keydown',e=>{
  if(e.key==='Tab'){e.preventDefault();document.execCommand('insertText',false,'\t');}
});

document.getElementById('saveEdit').onclick=()=>{
 if(!selected)return;pushHistory();selected.innerHTML=cleanRichHtml(editText.innerHTML);modal.classList.remove('show');markDirty();showToast('Perubahan masuk ke draft');
};
document.getElementById('cancelEdit').onclick=document.getElementById('closeModal').onclick=()=>modal.classList.remove('show');
document.getElementById('previewBtn').onclick=()=>window.open('/builder/preview.php?page='+encodeURIComponent(currentPageSlug),'_blank','noopener');
document.getElementById('versionsBtn').onclick=()=>window.open('/builder/versions.php?page='+encodeURIComponent(currentPageSlug),'_blank','noopener');
document.getElementById('unpublishBtn').onclick=async()=>{if(!confirm('Kembalikan halaman ini dari Published ke Draft? Website publik akan berhenti menampilkan versi ini.'))return;const b=document.getElementById('unpublishBtn');b.disabled=true;try{const r=await fetch('/builder/unpublish.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({page_slug:currentPageSlug})});const d=await r.json();if(!r.ok||!d.ok)throw new Error(d.message||'Unpublish gagal');showToast('Halaman dikembalikan ke Draft ✓');}catch(e){showToast(e.message||'Unpublish gagal')}finally{b.disabled=false;}};
document.getElementById('undoBtn').onclick=()=>{if(history.length){future.push(snapshot());preview.innerHTML=history.pop();bindLayoutColumns();bindEditable();bindMedia();bindGallery();makeDraggable();applyHeroSettings();markDirty();showToast('Undo')}}; 
document.getElementById('redoBtn').onclick=()=>{if(future.length){history.push(snapshot());preview.innerHTML=future.pop();bindLayoutColumns();bindEditable();bindMedia();bindGallery();makeDraggable();applyHeroSettings();markDirty();showToast('Redo')}};
document.getElementById('publishBtn').onclick=async()=>{
  if(dirty){
    const ok=confirm('Masih ada perubahan yang belum disimpan. Simpan Draft dulu lalu Publish?');
    if(!ok)return;
    await saveDraft();
    if(dirty)return;
  }
  if(!confirm('Publikasikan versi Draft ke website publik sekarang?'))return;
  const btn=document.getElementById('publishBtn');
  btn.disabled=true; btn.textContent='⏳ PUBLISH...';
  try{
    const r=await fetch('/builder/publish.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({...collect(),page_slug:currentPageSlug})});
    const d=await r.json();
    if(!r.ok||!d.ok)throw new Error(d.message||'Publish gagal');
    btn.textContent='✓ PUBLISHED';
    showToast('Website berhasil dipublikasikan 🚀');
    setTimeout(()=>{btn.disabled=false;btn.textContent='🚀 PUBLISH'},1800);
  }catch(e){
    btn.disabled=false;btn.textContent='🚀 PUBLISH';
    showToast(e.message||'Publish gagal');
  }
};


function insertBuilderBlock(box){
  // Selalu masukkan blok ke area konten, tepat sebelum Footer Builder.
  // Jangan pernah menaruh blok baru setelah footer.
  const footer = preview.querySelector(':scope > footer.builder-footer[data-builder-footer="1"], :scope > .builder-footer[data-builder-footer="1"]');
  if (footer && footer.parentNode === preview) {
    preview.insertBefore(box, footer);
  } else {
    preview.appendChild(box);
  }
}
function cleanUndefinedBlocks(){
  preview.querySelectorAll('.added-block').forEach(function(el){
    if ((el.textContent || '').trim().toLowerCase() === 'undefined') el.remove();
  });
  preview.querySelectorAll('h1,h2,h3,h4,h5,h6,p,span,small,b,strong,button,a,div').forEach(function(el){
    const t=(el.textContent||'').trim().toLowerCase();
    if(t==='undefined'){
      if(el.matches('h1,h2,h3,h4,h5,h6,p,span,small,b,strong')) el.textContent='';
      else if(el.matches('button,a')) el.remove();
    }
    if(t==='tombol baru' && el.matches('button,a')) el.remove();
  });
}

function contentBlockHtml(type){
 const blocks={
  hero:`<section class="content-block hero-section"><div class="eyebrow">PORTAL SEKOLAH</div><h2>Selamat Datang di SDN Ciburayut 01</h2><p>Bangun tampilan website sekolah yang informatif, modern, dan mudah diakses.</p><button class="preview-button" type="button">Pelajari Selengkapnya →</button></section>`,
  columns:`<section class="content-block three-column-block"><div><span>📚</span><h3>Pembelajaran</h3><p>Informasi kegiatan belajar dan program sekolah.</p></div><div><span>🎯</span><h3>Program</h3><p>Program unggulan dan kegiatan peserta didik.</p></div><div><span>🤝</span><h3>Layanan</h3><p>Layanan informasi untuk warga sekolah.</p></div></section>`,
  profile:`<section class="content-block profile-block"><div class="eyebrow">TENTANG SEKOLAH</div><h2>Profil SDN Ciburayut 01</h2><p>SDN Ciburayut 01 berkomitmen menghadirkan pendidikan yang berkualitas, berkarakter, dan adaptif terhadap perkembangan teknologi.</p><div class="mini-points"><span>✓ Pembelajaran bermakna</span><span>✓ Lingkungan positif</span><span>✓ Kolaborasi sekolah</span></div></section>`,
  contact:`<section class="content-block contact-block" data-contact-block="1"><div><div class="eyebrow">HUBUNGI KAMI</div><h2>Kontak Sekolah</h2><p>Informasi kontak sekolah akan tampil otomatis dari pengaturan website.</p></div><div class="contact-items"><span>📍 Alamat sekolah</span><span>📞 Telepon</span><span>✉️ Email</span></div></section>`,
  announcement:`<section class="content-block announcement-block"><div class="eyebrow">INFORMASI TERBARU</div><h2>Pengumuman Sekolah</h2><div class="notice-list"><article><b>📢 Informasi Sekolah</b><small>Tambahkan pengumuman terbaru di sini.</small></article><article><b>📅 Agenda</b><small>Tambahkan jadwal kegiatan sekolah.</small></article></div></section>`,
  teachers:`<section class="content-block teachers-block" data-teachers-block="1"><div class="eyebrow">TENAGA PENDIDIK</div><h2>Profil Guru</h2><div class="teacher-mini"><div>👨‍🏫</div><div><b>Nama Guru</b><small>Guru / Wali Kelas</small></div></div><div class="teacher-mini"><div>👩‍🏫</div><div><b>Nama Guru</b><small>Guru / Wali Kelas</small></div></div></section>`,
  gallery:`<section class="content-block gallery-block"><div class="eyebrow">DOKUMENTASI</div><h2>Galeri Sekolah</h2><div class="gallery-grid"><div>🖼️</div><div>🖼️</div><div>🖼️</div><div>🖼️</div></div></section>`,
  cta:`<section class="content-block cta-block"><h2>Bersama Membangun Sekolah Hebat</h2><p>Ikuti informasi dan kegiatan terbaru SDN Ciburayut 01.</p><button class="preview-button" type="button">Lihat Informasi →</button></section>`,
  news:`<section class="content-block news-dynamic-block" data-news-block="1"><div class="eyebrow">INFORMASI TERBARU</div><h2>Berita & Pengumuman</h2><div class="news-placeholder">📰 Berita terbaru akan tampil otomatis setelah dipublish.</div></section>`,
  agenda:`<section class="content-block agenda-dynamic-block" data-agenda-block="1"><div class="eyebrow">AGENDA SEKOLAH</div><h2>Kegiatan Mendatang</h2><div class="agenda-placeholder">📅 Agenda sekolah akan tampil otomatis setelah ditambahkan.</div></section>`
 };
 return blocks[type]||blocks.profile;
}
document.querySelectorAll('.content-block-btn').forEach(btn=>btn.onclick=()=>{
 pushHistory();
 const box=document.createElement('div');
 box.className='added-block content-wrapper';
 box.dataset.id='block-'+Date.now();
 box.dataset.type='content-block';
 box.innerHTML=contentBlockHtml(btn.dataset.block);
 insertBuilderBlock(box);
 bindLayoutColumns();bindEditable();bindMedia();bindGallery();makeDraggable();markDirty();
 showToast('Content Block ditambahkan ke draft');
});

document.querySelectorAll('.layout-block-btn').forEach(btn=>btn.onclick=()=>{
  pushHistory();
  const n=parseInt(btn.dataset.layout,10)||2;
  const box=document.createElement('section'); box.className='added-block layout-section'; box.dataset.id='layout-'+Date.now(); box.dataset.type='layout';
  const grid=document.createElement('div'); grid.className='layout-grid cols-'+n;
  for(let i=1;i<=n;i++){ const col=document.createElement('div'); col.className='layout-column'; col.dataset.column=i; col.innerHTML='<div class="column-placeholder">＋<span>Tambah konten</span></div>'; grid.appendChild(col); }
  box.innerHTML='<div class="layout-section-head"><span>Layout '+n+' Kolom</span><button type="button" class="layout-add-col">＋</button></div>'; box.appendChild(grid);
  insertBuilderBlock(box); bindLayoutColumns(); bindEditable(); bindMedia(); bindGallery(); makeDraggable(); markDirty(); showToast('Layout '+n+' kolom ditambahkan');
});

function bindLayoutColumns(){
 document.querySelectorAll('.layout-column').forEach(col=>{
  if(col.dataset.bound==='1')return; col.dataset.bound='1';
  col.addEventListener('click',e=>{
   if(e.target.closest('.column-placeholder')){
    e.stopPropagation(); openColumnMenu(col);
   }
  });
 });
 document.querySelectorAll('.layout-add-col').forEach(btn=>{
  if(btn.dataset.bound==='1')return; btn.dataset.bound='1'; btn.onclick=e=>{e.stopPropagation(); showToast('Gunakan layout baru untuk jumlah kolom berbeda');};
 });
}
function openColumnMenu(col){
 const choice=prompt('Isi kolom dengan:\n1 = Teks\n2 = Tombol\n3 = Gambar\n4 = Spacer\n\nMasukkan angka:','1');
 if(!choice)return; pushHistory();
 const html={
  '1':'<h3>Judul Kolom</h3><p>Klik teks ini untuk mengedit konten kolom.</p>',
  '2':'<button class="preview-button" type="button">Tombol</button>',
  '3':'<div class="fake-media upload-image-block">🖼️<br><small>Klik untuk pilih gambar</small></div>',
  '4':'<div class="spacer-fake small"></div>'
 }[choice];
 if(!html){showToast('Pilihan tidak tersedia');return;}
 col.innerHTML=html; bindEditable(); bindMedia(); markDirty(); showToast('Konten kolom ditambahkan');
}

document.querySelectorAll('.insert-item').forEach(btn=>btn.onclick=()=>{
 pushHistory();const type=btn.dataset.add,box=document.createElement('div');box.className='added-block';box.dataset.id='new-'+Date.now();
 box.innerHTML=type==='text'?'<h3>Teks Baru</h3><p>Klik untuk mengedit teks ini.</p>':
 type==='image'?'<div class="fake-media upload-image-block">🖼️<br><small>Klik untuk pilih gambar</small></div>':
 type==='button'?'<button class="preview-button" type="button">Tombol Baru</button>':
 type==='gallery'?galleryHtml(['/uploads/builder/img_19468920d02bb42e87819eea.jpg','/uploads/builder/img_df9e02ff2848da94b9b5d0a5.jpg','/uploads/builder/img_e312cc78216603db61ef11e1.jpg','/uploads/builder/img_59c57f0e9dd6ac00cde09f4b.jpg','/uploads/builder/img_f45840b26f3550aa1c0c6654.jpg','/uploads/builder/Gambar-WhatsApp-2025-08-13-pukul-16-21-57_63657117-82483e4aa9.jpg']):
 type==='news'?contentBlockHtml('news'):
 type==='agenda'?contentBlockHtml('agenda'):
 type==='divider'?'<hr>':'<div class="spacer-fake"></div>';
 insertBuilderBlock(box);bindLayoutColumns();bindEditable();bindMedia();bindGallery();makeDraggable();markDirty();showToast('Elemen ditambahkan ke draft');
});


// STEP 20 — Gallery Builder Pro
let selectedGallery=null;
const galleryModal=document.getElementById('galleryModal');
const galleryUrls=document.getElementById('galleryUrls'),galleryCols=document.getElementById('galleryCols'),galleryGap=document.getElementById('galleryGap'),galleryGapOut=document.getElementById('galleryGapOut'),galleryRadius=document.getElementById('galleryRadius'),galleryRadiusOut=document.getElementById('galleryRadiusOut'),galleryFit=document.getElementById('galleryFit'),galleryCaption=document.getElementById('galleryCaption'),galleryLightbox=document.getElementById('galleryLightbox'),galleryLivePreview=document.getElementById('galleryLivePreview');
function escapeAttr(v){return escapeHtml(v).replace(/`/g,'&#96;')}
function galleryHtml(urls,settings={}){
 const clean=(urls||[]).map(x=>String(x).trim()).filter(x=>/^https?:\/\//i.test(x)||x.startsWith('/')).slice(0,30);
 const cols=Math.max(1,Math.min(4,parseInt(settings.cols)||3)),gap=Math.max(0,Math.min(40,parseInt(settings.gap)||14)),rad=Math.max(0,Math.min(40,parseInt(settings.radius)||14)),fit=settings.fit==='contain'?'contain':'cover',cap=settings.caption?'1':'0',light=settings.lightbox===false?'0':'1';
 if(!clean.length)return '<div class="builder-gallery" data-cols="'+cols+'" data-gap="'+gap+'" data-radius="'+rad+'" data-fit="'+fit+'" data-caption="'+cap+'" data-lightbox="'+light+'"><div class="gallery-empty-state">🖼️<br><small>Tambahkan foto melalui Gallery Builder</small></div></div>';
 return '<div class="builder-gallery" data-cols="'+cols+'" data-gap="'+gap+'" data-radius="'+rad+'" data-fit="'+fit+'" data-caption="'+cap+'" data-lightbox="'+light+'"><div class="builder-gallery-grid">'+clean.map((u,i)=>'<figure class="builder-gallery-item"><a href="'+escapeAttr(u)+'" class="gallery-link" '+(light==='1'?'data-lightbox="1"':'')+'><img src="'+escapeAttr(u)+'" alt="Foto galeri '+(i+1)+'"></a>'+(cap==='1'?'<figcaption>Foto kegiatan sekolah</figcaption>':'')+'</figure>').join('')+'</div></div>';
}
function gallerySettings(g){return {cols:g.dataset.cols||3,gap:g.dataset.gap||14,radius:g.dataset.radius||14,fit:g.dataset.fit||'cover',caption:g.dataset.caption==='1',lightbox:g.dataset.lightbox!=='0'}}
function renderGalleryLive(){
 const urls=galleryUrls.value.split(/\n|\r/).map(x=>x.trim()).filter(Boolean).slice(0,8);
 galleryLivePreview.innerHTML=galleryHtml(urls,{cols:galleryCols.value,gap:galleryGap.value,radius:galleryRadius.value,fit:galleryFit.value,caption:galleryCaption.checked,lightbox:galleryLightbox.checked});
 galleryGapOut.textContent=galleryGap.value+' px';galleryRadiusOut.textContent=galleryRadius.value+' px';
}
function openGalleryEditor(g){
 if(!g)return; selectedGallery=g;
 const imgs=[...g.querySelectorAll('img')].map(i=>i.getAttribute('src')).filter(Boolean);
 const st=gallerySettings(g); galleryUrls.value=imgs.join('\n');galleryCols.value=String(st.cols);galleryGap.value=st.gap;galleryRadius.value=st.radius;galleryFit.value=st.fit;galleryCaption.checked=st.caption;galleryLightbox.checked=st.lightbox;renderGalleryLive();galleryModal.classList.add('show');
}
[galleryUrls,galleryCols,galleryGap,galleryRadius,galleryFit,galleryCaption,galleryLightbox].forEach(el=>el?.addEventListener('input',renderGalleryLive));
document.getElementById('saveGallery').onclick=()=>{if(!selectedGallery)return;pushHistory();const urls=galleryUrls.value.split(/\n|\r/).map(x=>x.trim()).filter(Boolean);selectedGallery.innerHTML=galleryHtml(urls,{cols:galleryCols.value,gap:galleryGap.value,radius:galleryRadius.value,fit:galleryFit.value,caption:galleryCaption.checked,lightbox:galleryLightbox.checked});galleryModal.classList.remove('show');bindGallery();markDirty();showToast('Galeri diterapkan ke Draft ✓');};
document.getElementById('cancelGallery').onclick=document.getElementById('closeGalleryModal').onclick=()=>galleryModal.classList.remove('show');
function bindGallery(){
 document.querySelectorAll('.builder-gallery').forEach(g=>{if(g.dataset.galleryBound==='1')return;g.dataset.galleryBound='1';g.addEventListener('click',e=>{const a=e.target.closest('.gallery-link');if(a){e.preventDefault();e.stopPropagation();if(g.dataset.lightbox==='1')openGalleryLightbox(a.querySelector('img')?.src||a.href);return;}e.stopPropagation();openGalleryEditor(g);});applyGalleryStyle(g);});
}
function applyGalleryStyle(g){const grid=g.querySelector('.builder-gallery-grid');if(!grid)return;const cols=Math.max(1,Math.min(4,parseInt(g.dataset.cols)||3));grid.style.gridTemplateColumns='repeat('+cols+',minmax(0,1fr))';grid.style.gap=(parseInt(g.dataset.gap)||14)+'px';g.querySelectorAll('img').forEach(img=>{img.style.borderRadius=(parseInt(g.dataset.radius)||14)+'px';img.style.objectFit=g.dataset.fit==='contain'?'contain':'cover'});}
function openGalleryLightbox(src){let lb=document.getElementById('galleryLightboxOverlay');if(!lb){lb=document.createElement('div');lb.id='galleryLightboxOverlay';lb.className='gallery-lightbox';lb.innerHTML='<button class="gallery-lightbox-close">×</button><img alt="Preview galeri">';document.body.appendChild(lb);lb.addEventListener('click',e=>{if(e.target===lb||e.target.closest('.gallery-lightbox-close'))lb.classList.remove('show')});}lb.querySelector('img').src=src;lb.classList.add('show');}

// STEP 6 — Drag & Drop + Media
let dragSource=null;
function makeDraggable(){
  document.querySelectorAll('#sitePreview > .editable, #sitePreview > .added-block').forEach(el=>{
    if(el.dataset.dragBound==='1')return; el.dataset.dragBound='1'; el.draggable=true;
    el.addEventListener('dragstart',()=>{dragSource=el;el.classList.add('dragging');selectSection(el)});
    el.addEventListener('dragend',()=>{el.classList.remove('dragging');dragSource=null;markDirty()});
    el.addEventListener('dragover',e=>{e.preventDefault();el.classList.add('drag-over')});
    el.addEventListener('dragleave',()=>el.classList.remove('drag-over'));
    el.addEventListener('drop',e=>{e.preventDefault();el.classList.remove('drag-over'); if(dragSource&&dragSource!==el){pushHistory();const parent=el.parentNode;const rect=el.getBoundingClientRect();if(e.clientY<rect.top+rect.height/2)parent.insertBefore(dragSource,el);else parent.insertBefore(dragSource,el.nextSibling);markDirty();showToast('Blok dipindahkan')}});
  });
}

function openImagePicker(targetBlock){
  let input=document.getElementById('builderImageInput');
  if(!input){
    input=document.createElement('input');input.type='file';input.id='builderImageInput';input.accept='image/jpeg,image/png,image/webp';input.style.display='none';
    document.body.appendChild(input);
  }
  input.value='';
  input.onchange=async()=>{
    if(!input.files[0])return;
    const prepared = await prepareBuilderImage(input.files[0]);
    const fd=new FormData();
    fd.append('image', prepared, prepared.name);
    fd.append('_csrf', builderCsrfToken);
    targetBlock.innerHTML='<div class="fake-media">⏳<br><small>Mengunggah...</small></div>';
    try{
      const r=await fetch('/builder/upload_image.php',{
        method:'POST',
        credentials:'same-origin',
        headers:{'X-CSRF-Token':builderCsrfToken,'Accept':'application/json'},
        body:fd
      });
      let d={};
      try{d=await r.json();}catch(_){throw new Error('Server upload tidak mengembalikan JSON yang valid (HTTP '+r.status+').');}
      if(!r.ok||!d.ok)throw new Error(d.message||('Upload gagal (HTTP '+r.status+')'));
      targetBlock.innerHTML='<img class="builder-added-image" src="'+d.url+'" alt="Gambar">';
      targetBlock.classList.add('image-block');markDirty();makeDraggable();showToast('Gambar berhasil ditambahkan');
    }catch(e){targetBlock.innerHTML='<div class="fake-media">❌<br><small>'+escapeHtml(e.message)+'</small></div>';showToast(e.message||'Upload gagal')}
  };
  input.click();
}
function bindMedia(){
  document.querySelectorAll('.upload-image-block').forEach(el=>{
    el.onclick=()=>openImagePicker(el.closest('.added-block')||el);
  });
}


// STRONGFIX: kompres gambar di browser agar lolos batas upload PHP hosting.
async function prepareBuilderImage(file){
  if (!file || !file.type.startsWith('image/')) throw new Error('File bukan gambar.');
  const maxBytes = 1500 * 1024; // target aman untuk hosting dengan limit 2 MB
  if (file.size <= maxBytes) return file;

  const bitmap = await createImageBitmap(file);
  const maxSide = 2200;
  const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const ctx = canvas.getContext('2d', {alpha:false});
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();

  let quality = 0.82;
  let blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', quality));
  while (blob && blob.size > maxBytes && quality > 0.45) {
    quality -= 0.08;
    blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', quality));
  }
  if (!blob) throw new Error('Gambar tidak dapat diproses.');
  return new File([blob], (file.name.replace(/\.[^.]+$/, '') || 'gambar') + '.jpg', {type:'image/jpeg'});
}

// STEP 10 — Media Library
const mediaGrid=document.getElementById('mediaGrid');
const mediaInput=document.getElementById('mediaInput');
document.getElementById('mediaUploadBtn').onclick=()=>mediaInput.click();
mediaInput.onchange=async()=>{if(!mediaInput.files[0])return;try{const prepared=await prepareBuilderImage(mediaInput.files[0]);const fd=new FormData();fd.append('image',prepared,prepared.name);const r=await fetch('/builder/media.php?action=upload',{method:'POST',credentials:'same-origin',body:fd});const d=await r.json();if(!r.ok||!d.ok)throw new Error(d.message||'Upload gagal');showToast('Gambar berhasil diupload');loadMedia();}catch(e){showToast(e.message||'Upload gagal')}mediaInput.value='';};
async function loadMedia(){if(!mediaGrid)return;mediaGrid.innerHTML='<div class="panel-loading">Memuat media...</div>';try{const r=await fetch('/builder/media.php?action=list',{credentials:'same-origin'});const d=await r.json();if(!r.ok||!d.ok)throw new Error();if(!d.files.length){mediaGrid.innerHTML='<div class="media-empty">Belum ada gambar.<br>Klik ＋ Upload untuk menambahkan.</div>';return;}mediaGrid.innerHTML='';d.files.forEach(f=>{const card=document.createElement('div');card.className='media-card';card.innerHTML='<img class="media-thumb" src="'+escapeHtml(f.file_url)+'" alt=""><button class="media-delete" title="Hapus">🗑️</button><div class="media-meta"><span class="media-name">'+escapeHtml(f.file_name)+'</span></div>';card.querySelector('.media-thumb').onclick=()=>{if(heroPickMode){heroSettings.hero_image=f.file_url;const inp=document.getElementById('heroImage');if(inp)inp.value=f.file_url;heroPickMode=false;applyHeroSettings();markDirty();showToast('Gambar dipasang sebagai Hero ✓');return;}navigator.clipboard?.writeText(f.file_url);showToast('URL gambar disalin: '+f.file_url);};card.querySelector('.media-delete').onclick=async()=>{if(!confirm('Hapus gambar ini dari Media Library?'))return;const fd=new FormData();fd.append('id',f.id);const rr=await fetch('/builder/media.php?action=delete',{method:'POST',credentials:'same-origin',body:fd});const dd=await rr.json();if(!rr.ok||!dd.ok){showToast(dd.message||'Gagal menghapus');return;}loadMedia();showToast('Gambar dihapus');};mediaGrid.appendChild(card);});}catch(e){mediaGrid.innerHTML='<div class="media-empty">Gagal memuat Media Library.</div>';}}
// STEP 11 — Header & Navbar Builder
let navbarData={navbar_enabled:true,navbar_items:[],navbar_cta_text:'🔐 Masuk Sistem',navbar_cta_url:'/auth/login.php',navbar_style:'glass'};
function renderNavEditor(){
 const box=document.getElementById('navItems'); if(!box)return; box.innerHTML='';
 navbarData.navbar_items.forEach((item,i)=>{
  const row=document.createElement('div');row.className='nav-item-row';
  row.innerHTML='<span class="nav-drag">☷</span><input class="nav-label" maxlength="60" value="'+escapeHtml(item.label)+'"><input class="nav-url" maxlength="300" value="'+escapeHtml(item.url)+'"><button class="nav-up" title="Naik">↑</button><button class="nav-down" title="Turun">↓</button><button class="nav-del" title="Hapus">×</button>';
  row.querySelector('.nav-label').oninput=e=>{navbarData.navbar_items[i].label=e.target.value;applyNavbar(false)};
  row.querySelector('.nav-url').oninput=e=>{navbarData.navbar_items[i].url=e.target.value;applyNavbar(false)};
  row.querySelector('.nav-up').onclick=()=>{if(i>0){[navbarData.navbar_items[i-1],navbarData.navbar_items[i]]=[navbarData.navbar_items[i],navbarData.navbar_items[i-1]];renderNavEditor();applyNavbar(false);markDirty()}};
  row.querySelector('.nav-down').onclick=()=>{if(i<navbarData.navbar_items.length-1){[navbarData.navbar_items[i+1],navbarData.navbar_items[i]]=[navbarData.navbar_items[i],navbarData.navbar_items[i+1]];renderNavEditor();applyNavbar(false);markDirty()}};
  row.querySelector('.nav-del').onclick=()=>{if(navbarData.navbar_items.length<=1){showToast('Minimal 1 menu');return;}navbarData.navbar_items.splice(i,1);renderNavEditor();applyNavbar(false);markDirty()};
  box.appendChild(row);
 });
}
function applyNavbar(notify=true){
 const nav=preview.querySelector('.preview-nav'); if(!nav)return;
 nav.className='preview-nav nav-style-'+(navbarData.navbar_style||'glass');
 let logo=nav.querySelector('.preview-logo'),school=nav.querySelector('.preview-school'),links=nav.querySelector('.preview-links');
 if(!links){links=document.createElement('div');links.className='preview-links';nav.appendChild(links)}
 links.innerHTML='';
 if(!navbarData.navbar_enabled){nav.style.display='none';return;} nav.style.display='';
 (navbarData.navbar_items||[]).forEach(it=>{const a=document.createElement('a');a.href=it.url||'#';a.textContent=it.label||'Menu';a.onclick=e=>e.preventDefault();links.appendChild(a)});
 let cta=nav.querySelector('.preview-cta');if(!cta){cta=document.createElement('a');cta.className='preview-cta';nav.appendChild(cta)}cta.textContent=navbarData.navbar_cta_text||'🔐 Masuk Sistem';cta.href=navbarData.navbar_cta_url||'/auth/login.php';cta.onclick=e=>e.preventDefault();
 if(notify){markDirty();showToast('Navbar diperbarui')}
}
async function loadNavbar(){try{const r=await fetch('/builder/navbar.php',{credentials:'same-origin'});const d=await r.json();if(!d.ok)return;navbarData=d.navbar||navbarData;document.getElementById('navEnabled').checked=!!navbarData.navbar_enabled;document.getElementById('navStyle').value=navbarData.navbar_style||'glass';document.getElementById('navCtaText').value=navbarData.navbar_cta_text||'';document.getElementById('navCtaUrl').value=navbarData.navbar_cta_url||'';renderNavEditor();applyNavbar(false)}catch(e){}}
document.getElementById('addNavItem').onclick=()=>{navbarData.navbar_items.push({label:'Menu Baru',url:'/?page=home'});renderNavEditor();applyNavbar(false);markDirty()};
document.getElementById('navEnabled').onchange=e=>{navbarData.navbar_enabled=e.target.checked;applyNavbar(false);markDirty()};
document.getElementById('navStyle').onchange=e=>{navbarData.navbar_style=e.target.value;applyNavbar(false);markDirty()};
document.getElementById('navCtaText').oninput=e=>{navbarData.navbar_cta_text=e.target.value;applyNavbar(false);markDirty()};
document.getElementById('navCtaUrl').oninput=e=>{navbarData.navbar_cta_url=e.target.value;applyNavbar(false);markDirty()};
document.getElementById('saveNavbar').onclick=async()=>{try{const r=await fetch('/builder/navbar.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(navbarData)});const d=await r.json();if(!r.ok||!d.ok)throw 0;showToast('Navbar tersimpan ✓');}catch(e){showToast('Navbar gagal disimpan')}};

// STEP 5 — Pages + Themes
const tabs=document.querySelectorAll('.tab[data-panel]');
tabs.forEach(tab=>tab.onclick=()=>{
  tabs.forEach(t=>t.classList.remove('active'));
  tab.classList.add('active');
  document.querySelectorAll('.builder-panel').forEach(p=>p.hidden=true);
  document.getElementById('panel-'+tab.dataset.panel).hidden=false;
  if(tab.dataset.panel==='pages') loadPages();
  if(tab.dataset.panel==='themes') loadTheme();
  if(tab.dataset.panel==='media') loadMedia();
  if(tab.dataset.panel==='navbar') loadNavbar();
});

function escapeHtml(s){
  return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}
async function loadPages(){
  const list=document.getElementById('pageList');
  try{
    const r=await fetch('/builder/pages.php?action=list',{credentials:'same-origin'});
    const d=await r.json();
    if(!r.ok||!d.ok)throw new Error();
    list.innerHTML='';
    d.pages.forEach(p=>{
      const row=document.createElement('div');row.className='page-row';
      row.innerHTML='<button class="page-open"><span>'+(p.slug==='home'?'🏠':'📄')+'</span><b>'+escapeHtml(p.title)+'</b><small>'+(p.status==='published'?'Published':'Draft')+'</small></button><button class="page-more">⋮</button>';
      row.querySelector('.page-open').onclick=async()=>{
        if(p.slug===currentPageSlug){showToast('Halaman ini sedang dibuka');return;}
        if(dirty && !confirm('Ada perubahan yang belum disimpan. Pindah halaman tanpa menyimpan?')) return;
        window.location.href='/builder/?page='+encodeURIComponent(p.slug);
      };
      row.querySelector('.page-more').onclick=async()=>{
        if(p.slug==='home'){showToast('Beranda adalah halaman utama');return;}
        const choice=prompt('Nama halaman baru:',p.title);
        if(choice===null||!choice.trim())return;
        const rr=await fetch('/builder/pages.php?action=rename',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:p.id,title:choice.trim()})});
        const dd=await rr.json();
        if(!rr.ok||!dd.ok){showToast('Gagal mengganti nama');return;}
        loadPages();showToast('Nama halaman diperbarui');
      };
      list.appendChild(row);
    });
  }catch(e){list.innerHTML='<div class="panel-help">Gagal memuat halaman.</div>'}
}
document.getElementById('addPage').onclick=async()=>{
  const title=prompt('Nama halaman baru:','Halaman Baru');
  if(!title||!title.trim())return;
  try{
    const r=await fetch('/builder/pages.php?action=add',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:title.trim()})});
    const d=await r.json();
    if(!r.ok||!d.ok)throw new Error();
    loadPages();showToast('Halaman "'+title.trim()+'" dibuat sebagai Draft');
  }catch(e){showToast('Gagal membuat halaman')}
};

const themeNames={blue:'Blue School',emerald:'Emerald',gold:'Gold',dark:'Dark'};
async function loadTheme(){
  try{
    const r=await fetch('/builder/themes.php',{credentials:'same-origin'});const d=await r.json();
    if(d.ok)applyTheme(d.theme,false);
  }catch(e){}
}
function applyTheme(theme,notify=true){
  const allowed=['blue','emerald','gold','dark'];
  if(!allowed.includes(theme))theme='blue';
  preview.classList.remove(...allowed.map(x=>'theme-'+x));
  preview.classList.add('theme-'+theme);
  document.querySelectorAll('.theme-card').forEach(x=>x.classList.toggle('selected',x.dataset.theme===theme));
  document.getElementById('themeStatus').textContent='Tema aktif: '+themeNames[theme];
  if(notify)showToast('Tema '+themeNames[theme]+' dipilih');
}
document.querySelectorAll('.theme-card').forEach(card=>card.onclick=async()=>{
  const theme=card.dataset.theme;
  try{
    const r=await fetch('/builder/themes.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({theme})});
    const d=await r.json();
    if(!r.ok||!d.ok)throw new Error();
    applyTheme(theme);markDirty();
  }catch(e){showToast('Tema gagal disimpan')}
});


const heroIds={hero_image:'heroImage',hero_overlay:'heroOverlay',hero_height:'heroHeight',hero_align:'heroAlign',hero_eyebrow:'heroEyebrow',hero_title:'heroTitle',hero_subtitle:'heroSubtitle',hero_button_text:'heroButtonText',hero_button_url:'heroButtonUrl',hero_button2_text:'heroButton2Text',hero_button2_url:'heroButton2Url',hero_text_color:'heroTextColor',hero_position:'heroPosition',hero_animation:'heroAnimation'};
let heroSettings={}; let heroPickMode=false;
function heroBool(v){return v==='1'||v===1||v===true;}
function applyHeroSettings(){const hero=preview.querySelector('.builder-hero,.hero-section');if(!hero)return;const h=Math.max(320,Math.min(760,parseInt(heroSettings.hero_height||520,10)||520));const align=['left','center','right'].includes(heroSettings.hero_align)?heroSettings.hero_align:'left';hero.style.minHeight=h+'px';hero.style.textAlign=align;hero.style.color=heroSettings.hero_text_color||'#fff';hero.style.setProperty('--hero-bg',heroSettings.hero_image?'url("'+String(heroSettings.hero_image).replace(/"/g,'')+'")':'none');hero.style.setProperty('--hero-position',heroSettings.hero_position||'center');hero.classList.toggle('hero-overlay-on',heroBool(heroSettings.hero_overlay));hero.classList.remove('hero-anim-fade','hero-anim-slide','hero-anim-zoom','hero-anim-none');hero.classList.add('hero-anim-'+(heroSettings.hero_animation||'fade'));const ey=hero.querySelector('.eyebrow'),title=hero.querySelector('h1,h2'),sub=hero.querySelector('p'),b1=hero.querySelector('.hero-btn-primary'),b2=hero.querySelector('.hero-btn-secondary');if(ey)ey.textContent=heroSettings.hero_eyebrow||'';if(title)title.textContent=heroSettings.hero_title||'';if(sub)sub.textContent=heroSettings.hero_subtitle||'';if(b1){b1.textContent=heroSettings.hero_button_text||'';b1.href=heroSettings.hero_button_url||'#';b1.style.display=heroSettings.hero_button_text?'inline-flex':'none';}if(b2){b2.textContent=heroSettings.hero_button2_text||'';b2.href=heroSettings.hero_button2_url||'#';b2.style.display=heroSettings.hero_button2_text?'inline-flex':'none';}const out=document.getElementById('heroHeightOut');if(out)out.textContent=h+' px';}
async function loadHeroSettings(){try{const r=await fetch('/builder/settings.php',{credentials:'same-origin'});const d=await r.json();if(!d.ok)return;heroSettings=d.settings||{};syncHeroInputs();applyHeroSettings();}catch(e){}}
function syncHeroInputs(){Object.keys(heroIds).forEach(k=>{const el=document.getElementById(heroIds[k]);if(!el)return;const v=heroSettings[k]??'';if(el.type==='checkbox')el.checked=heroBool(v);else el.value=v;});const h=document.getElementById('heroHeight');if(h)document.getElementById('heroHeightOut').textContent=(h.value||520)+' px';}
function collectHeroInputs(){Object.keys(heroIds).forEach(k=>{const el=document.getElementById(heroIds[k]);if(!el)return;heroSettings[k]=el.type==='checkbox'?(el.checked?'1':'0'):el.value;});applyHeroSettings();markDirty();}
Object.keys(heroIds).forEach(k=>{const el=document.getElementById(heroIds[k]);if(!el)return;el.addEventListener('input',collectHeroInputs);el.addEventListener('change',collectHeroInputs);});
document.getElementById('saveHero').onclick=async()=>{collectHeroInputs();try{const r=await fetch('/builder/settings.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(heroSettings)});const d=await r.json();if(!r.ok||!d.ok)throw 0;showToast('Hero tersimpan ✓');}catch(e){showToast('Hero gagal disimpan')}};
document.getElementById('pickHeroMedia').onclick=()=>{heroPickMode=true;document.querySelector('.tab[data-panel="media"]').click();showToast('Klik gambar untuk memasangnya sebagai Hero');};

const settingIds={site_name:'setSiteName',tagline:'setTagline',logo_url:'setLogo',favicon_url:'setFavicon',hero_image:'setHero',address:'setAddress',phone:'setPhone',email:'setEmail',footer_text:'setFooter',primary_color:'setColor'};
const seoIds={seo_title:'seoTitle',seo_description:'seoDescription',seo_keywords:'seoKeywords',seo_author:'seoAuthor',seo_og_image:'seoOgImage',seo_canonical:'seoCanonical',seo_robots:'seoRobots'};
const contactIds={address:'contactAddress',phone:'contactPhone',whatsapp:'contactWhatsapp',email:'contactEmail',maps_link:'contactMapsLink',maps_embed_url:'contactMapsEmbed',facebook_url:'contactFacebook',instagram_url:'contactInstagram',youtube_url:'contactYoutube'};
const footerIds={footer_layout:'footerLayout',footer_bg:'footerBg',footer_text_color:'footerTextColor',footer_show_logo:'footerShowLogo',footer_show_quicklinks:'footerShowQuicklinks',footer_show_contact:'footerShowContact',footer_show_social:'footerShowSocial',footer_quicklinks:'footerQuicklinks'};
const headerIds={header_height:'headerHeight',header_sticky:'headerSticky',header_transparent:'headerTransparent',header_bg:'headerBg',header_overlay:'headerOverlay',header_logo_width:'headerLogoWidth',header_align:'headerAlign'};
let siteSettings={};
async function loadSettings(){
 try{const r=await fetch('/builder/settings.php',{credentials:'same-origin'});const d=await r.json();if(!d.ok)return;siteSettings=d.settings||{};
  Object.keys(settingIds).forEach(k=>{const el=document.getElementById(settingIds[k]);if(el)el.value=siteSettings[k]||'';});
  Object.keys(seoIds).forEach(k=>{const el=document.getElementById(seoIds[k]);if(el)el.value=siteSettings[k]||'';});
  Object.keys(contactIds).forEach(k=>{const el=document.getElementById(contactIds[k]);if(el)el.value=siteSettings[k]||'';});
Object.keys(footerIds).forEach(k=>{const el=document.getElementById(footerIds[k]);if(!el)return; if(el.type==='checkbox') el.checked=String(siteSettings[k]??'1')==='1'; else el.value=siteSettings[k]||'';});
updateFooterPreview();
  applySiteSettings(false);syncHeaderInputs();
 }catch(e){}
}
function applySiteSettings(notify=true){
 const name=siteSettings.site_name||'SDN CIBURAYUT 01', tag=siteSettings.tagline||'Portal Informasi Sekolah';
 preview.querySelectorAll('.preview-school').forEach(e=>e.textContent=name);
 preview.querySelectorAll('.preview-logo').forEach(e=>{const logo=siteSettings.logo_url||'';if(logo)e.innerHTML='<img src="'+escapeHtml(logo)+'" alt="Logo">';else e.textContent='01';});
 preview.style.setProperty('--builder-primary',siteSettings.primary_color||'#1565c0');
 if(siteSettings.hero_image){preview.style.setProperty('--builder-hero-image','url("'+siteSettings.hero_image.replace(/"/g,'')+'")');preview.classList.add('has-hero-image');}else preview.classList.remove('has-hero-image');
 applyHeaderSettings(false);
 if(notify){markDirty();showToast('Identitas website diperbarui');}
}
function headerBool(v){return v==='1'||v===1||v===true;}
function applyHeaderSettings(notify=true){
 const root=preview, nav=preview.querySelector('.preview-nav'); if(!nav)return;
 const h=Math.max(56,Math.min(120,parseInt(siteSettings.header_height||78,10)||78));
 const lw=Math.max(32,Math.min(72,parseInt(siteSettings.header_logo_width||46,10)||46));
 nav.style.setProperty('--preview-header-height',h+'px');nav.style.setProperty('--preview-logo-size',lw+'px');
 nav.style.background=siteSettings.header_bg||'#ffffff';
 nav.style.justifyContent=siteSettings.header_align==='center'?'center':(siteSettings.header_align==='left'?'flex-start':'space-between');
 nav.classList.toggle('header-transparent',headerBool(siteSettings.header_transparent));
 nav.classList.toggle('header-overlay',headerBool(siteSettings.header_overlay));
 nav.classList.toggle('header-sticky',headerBool(siteSettings.header_sticky));
 const lo=document.getElementById('headerHeightOut'),loo=document.getElementById('headerLogoWidthOut');if(lo)lo.textContent=h+' px';if(loo)loo.textContent=lw+' px';
 if(notify){markDirty();showToast('Header diperbarui');}
}
document.getElementById('saveSeo').onclick=async()=>{
 const data={};Object.keys(seoIds).forEach(k=>{const el=document.getElementById(seoIds[k]);data[k]=el?el.value.trim():'';});
 try{const r=await fetch('/builder/settings.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const d=await r.json();if(!r.ok||!d.ok)throw 0;Object.assign(siteSettings,data);showToast('SEO & metadata tersimpan ✓');}catch(e){showToast('SEO gagal disimpan');}
};

document.getElementById('saveSettings').onclick=async()=>{
 const data={};Object.keys(settingIds).forEach(k=>{const el=document.getElementById(settingIds[k]);data[k]=el?el.value.trim():'';});
 try{const r=await fetch('/builder/settings.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const d=await r.json();if(!r.ok||!d.ok)throw 0;siteSettings=data;applySiteSettings(false);showToast('Pengaturan website tersimpan ✓');}catch(e){showToast('Pengaturan gagal disimpan');}
};
Object.values(settingIds).forEach(id=>{const el=document.getElementById(id);if(el)el.addEventListener('input',()=>{siteSettings[Object.keys(settingIds).find(k=>settingIds[k]===id)]=el.value;applySiteSettings(false);});});


function syncHeaderInputs(){
 const map=headerIds;Object.keys(map).forEach(k=>{const el=document.getElementById(map[k]);if(!el)return;const v=siteSettings[k];if(el.type==='checkbox')el.checked=headerBool(v);else el.value=v??'';});
 const h=document.getElementById('headerHeight');if(h)document.getElementById('headerHeightOut').textContent=(h.value||78)+' px';
 const lw=document.getElementById('headerLogoWidth');if(lw)document.getElementById('headerLogoWidthOut').textContent=(lw.value||46)+' px';
}
function collectHeaderInputs(){Object.keys(headerIds).forEach(k=>{const el=document.getElementById(headerIds[k]);if(!el)return;siteSettings[k]=el.type==='checkbox'?(el.checked?'1':'0'):el.value;});applyHeaderSettings(false);}
Object.keys(headerIds).forEach(k=>{const el=document.getElementById(headerIds[k]);if(!el)return;el.addEventListener('input',()=>{collectHeaderInputs();markDirty();});el.addEventListener('change',()=>{collectHeaderInputs();markDirty();});});
document.getElementById('saveContact').onclick=async()=>{
 const data={};Object.keys(contactIds).forEach(k=>{const el=document.getElementById(contactIds[k]);data[k]=el?el.value.trim():'';});
 try{const r=await fetch('/builder/settings.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const d=await r.json();if(!r.ok||!d.ok)throw 0;Object.assign(siteSettings,data);showToast('Kontak & sosial media tersimpan ✓');markDirty();}catch(e){showToast('Kontak gagal disimpan')}};
Object.keys(footerIds).forEach(k=>{const el=document.getElementById(footerIds[k]);if(!el)return; const ev=el.type==='checkbox'?'change':'input'; el.addEventListener(ev,()=>{siteSettings[k]=el.type==='checkbox'?(el.checked?'1':'0'):el.value;updateFooterPreview();markDirty();});});
document.getElementById('saveFooterSettings')?.addEventListener('click',async()=>{const data={};Object.keys(footerIds).forEach(k=>data[k]=siteSettings[k]??'');try{const r=await fetch('/builder/settings.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const d=await r.json();if(!r.ok||!d.ok)throw 0;Object.assign(siteSettings,data);updateFooterPreview();showToast('Footer tersimpan ✓');}catch(e){showToast('Footer gagal disimpan')}});
function updateFooterPreview(){const f=document.querySelector('.builder-footer');if(!f)return; f.style.background=siteSettings.footer_bg||'#102a43';f.style.color=siteSettings.footer_text_color||'#fff';const g=f.querySelector('.builder-footer-grid');if(g)g.className='builder-footer-grid cols-'+(siteSettings.footer_layout||'3');f.querySelector('.builder-footer-brand')?.classList.toggle('is-hidden',String(siteSettings.footer_show_logo??'1')!=='1');f.querySelector('.builder-footer-links')?.classList.toggle('is-hidden',String(siteSettings.footer_show_quicklinks??'1')!=='1');f.querySelector('.builder-footer-contact')?.classList.toggle('is-hidden',String(siteSettings.footer_show_contact??'1')!=='1');f.querySelector('.builder-footer-social')?.classList.toggle('is-hidden',String(siteSettings.footer_show_social??'1')!=='1');}
Object.keys(contactIds).forEach(k=>{const el=document.getElementById(contactIds[k]);if(el)el.addEventListener('input',()=>{siteSettings[k]=el.value;markDirty();});});

document.getElementById('saveHeader').onclick=async()=>{collectHeaderInputs();try{const data={};Object.keys(settingIds).forEach(k=>data[k]=siteSettings[k]||'');Object.keys(headerIds).forEach(k=>data[k]=siteSettings[k]||'');const r=await fetch('/builder/settings.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const d=await r.json();if(!r.ok||!d.ok)throw 0;showToast('Header tersimpan ✓');}catch(e){showToast('Header gagal disimpan')}};
const panel=document.getElementById('sidePanel'),overlay=document.getElementById('overlay');
document.getElementById('openPanel').onclick=()=>{panel.classList.add('open');overlay.classList.add('show')};
overlay.onclick=()=>{panel.classList.remove('open');overlay.classList.remove('show')};
loadSettings();
loadHeroSettings();
loadNavbar();
loadDraft();
</script>
<script src="/builder/assets/menu_fix.js?v=20260914"></script>
</body>
</html>
