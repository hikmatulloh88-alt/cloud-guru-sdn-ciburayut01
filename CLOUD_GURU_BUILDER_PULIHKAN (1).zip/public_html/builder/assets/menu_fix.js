(function(){
  'use strict';
  function showPanel(name){
    var tabs=document.querySelectorAll('.panel-tabs .tab[data-panel]');
    var panels=document.querySelectorAll('.panel-content .builder-panel');
    var target=document.getElementById('panel-'+name);
    if(!target) return false;
    tabs.forEach(function(t){t.classList.toggle('active',t.getAttribute('data-panel')===name);});
    panels.forEach(function(p){p.hidden=true;});
    target.hidden=false;
    // Call existing loaders when available.
    try{
      if(name==='pages' && typeof window.loadPages==='function') window.loadPages();
      if(name==='themes' && typeof window.loadTheme==='function') window.loadTheme();
      if(name==='media' && typeof window.loadMedia==='function') window.loadMedia();
      if(name==='navbar' && typeof window.loadNavbar==='function') window.loadNavbar();
    }catch(e){ console.warn('Panel loader:',e); }
    return true;
  }
  function bind(){
    document.addEventListener('click',function(e){
      var tab=e.target.closest && e.target.closest('.panel-tabs .tab[data-panel]');
      if(!tab) return;
      e.preventDefault(); e.stopPropagation();
      showPanel(tab.getAttribute('data-panel'));
    },true);
    // Make the first panel deterministic.
    showPanel((document.querySelector('.panel-tabs .tab.active')||document.querySelector('.panel-tabs .tab'))?.getAttribute('data-panel')||'insert');
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',bind); else bind();
  window.CloudGuruShowPanel=showPanel;
})();
