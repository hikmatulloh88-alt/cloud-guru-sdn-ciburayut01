<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

if (!empty($_SESSION['user_id'])) {
    header('Location: ../dashboard/index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    if ($username === '' || $password === '') {
        $error = 'Username dan password wajib diisi.';
    } else {
        try {
            $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ? LIMIT 1');
            $stmt->execute([$username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                $error = 'Username atau password salah.';
            } else {
                $status = strtolower(trim((string)($user['status'] ?? 'aktif')));
                $active = in_array($status, ['', 'aktif', 'active', '1', 'ya'], true);

                $stored = (string)($user['password'] ?? '');
                $passwordOk = $stored !== '' && password_verify($password, $stored);

                // Kompatibilitas akun lama: migrasikan plain-text ke password_hash().
                if (!$passwordOk && $stored !== '' && hash_equals($stored, $password)) {
                    $passwordOk = true;
                    $newHash = password_hash($password, PASSWORD_DEFAULT);
                    $up = $pdo->prepare('UPDATE users SET password = ? WHERE username = ? LIMIT 1');
                    $up->execute([$newHash, $username]);
                }

                if (!$active) {
                    $error = 'Akun sedang tidak aktif.';
                } elseif (!$passwordOk) {
                    $error = 'Username atau password salah.';
                } else {
                    session_regenerate_id(true);

                    $id = $user['id_user'] ?? ($user['id'] ?? 0);
                    $name = $user['nama'] ?? ($user['name'] ?? $username);
                    $roleRaw = strtolower(trim((string)($user['role'] ?? '')));
                    $role = match ($roleRaw) {
                        'admin', 'administrator' => 'Admin',
                        'operator' => 'Operator',
                        'guru', 'teacher' => 'Guru',
                        'siswa', 'student' => 'Siswa',
                        default => ucfirst($roleRaw ?: 'Guru')
                    };

                    $_SESSION['user_id'] = (int)$id;
                    $_SESSION['user_name'] = (string)$name;
                    $_SESSION['username'] = $username;
                    $_SESSION['role'] = $role;

                    header('Location: ../dashboard/index.php');
                    exit;
                }
            }
        } catch (Throwable $e) {
            $error = 'Login tidak dapat diproses. Periksa koneksi database.';
        }
    }
}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login - Cloud Guru</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="login-page">
<div class="login-card">
<div class="logo">☁️</div>
<h1>Cloud Administrasi Guru</h1>
<p>Masuk ke penyimpanan berkas pribadi Anda.</p>
<?php if ($error): ?><div class="alert"><?=htmlspecialchars($error, ENT_QUOTES, 'UTF-8')?></div><?php endif; ?>
<form method="post" autocomplete="on">
<label>Username</label>
<input name="username" autocomplete="username" required autofocus>
<label>Password</label>
<input type="password" name="password" autocomplete="current-password" required>
<button class="btn primary full" type="submit">Masuk</button>
</form>
</div>
</body>
</html>
