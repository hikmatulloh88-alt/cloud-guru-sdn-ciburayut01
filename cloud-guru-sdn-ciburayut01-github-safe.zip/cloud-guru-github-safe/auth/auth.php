<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function wajib_login(): void
{
    if (empty($_SESSION['user_id'])) {
        header('Location: /auth/login.php');
        exit;
    }
}

function wajib_role(string ...$roles): void
{
    wajib_login();
    $roleUser = strtolower(trim((string)($_SESSION['role'] ?? '')));
    $allowed = array_map(static fn($r) => strtolower(trim($r)), $roles);

    if (!in_array($roleUser, $allowed, true)) {
        http_response_code(403);
        exit('Akses ditolak. Anda tidak memiliki izin untuk halaman ini.');
    }
}
