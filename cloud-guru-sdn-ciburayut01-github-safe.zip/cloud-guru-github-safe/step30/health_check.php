<?php
/** STEP 30.3 - Health Check robust table detection */
error_reporting(E_ALL); ini_set('display_errors','0');
$auth=__DIR__.'/../auth/auth.php';
if(!is_file($auth)){http_response_code(500);exit('Health Check: auth/auth.php tidak ditemukan.');}
require_once $auth;
if(session_status()!==PHP_SESSION_ACTIVE){@session_start();}
if(empty($_SESSION['user_id'])){header('Location: /auth/login.php');exit;}
if(($_SESSION['role']??'')!=='Admin'){http_response_code(403);exit('Akses ditolak. Health Check hanya untuk Admin.');}
$dbfile=__DIR__.'/../config/database.php';
if(!is_file($dbfile)){http_response_code(500);exit('Health Check: config/database.php tidak ditemukan.');}
require_once $dbfile;
function hc($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function ci($name,$ok,$detail){return ['name'=>$name,'ok'=>(bool)$ok,'detail'=>$detail];}
$checks=[];
$checks[]=ci('PHP',version_compare(PHP_VERSION,'8.0.0','>='),'Versi '.PHP_VERSION);
$checks[]=ci('PDO MySQL',extension_loaded('pdo_mysql'),extension_loaded('pdo_mysql')?'Aktif':'Tidak aktif');
$dbname='(tidak diketahui)'; $actualTables=[];
if(isset($pdo)&&$pdo instanceof PDO){
 try{
  $dbname=(string)$pdo->query('SELECT DATABASE()')->fetchColumn();
  $pdo->query('SELECT 1');
  $checks[]=ci('Database',true,'Koneksi berhasil • DB: '.$dbname);
  $st=$pdo->query("SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() ORDER BY TABLE_NAME");
  $actualTables=$st?$st->fetchAll(PDO::FETCH_COLUMN):[];
 }catch(Throwable $e){$checks[]=ci('Database',false,'Koneksi gagal');}
}else{$checks[]=ci('Database',false,'Objek PDO tidak tersedia');}
$tables=['users','school_profile','teachers','storage_files','storage_folders','dashboard_sections','website_builder_drafts','website_builder_published','website_builder_pages','website_builder_settings','website_builder_media','website_builder_news','website_builder_agenda'];
foreach($tables as $t){$exists=in_array($t,$actualTables,true);$checks[]=ci('Table '.$t,$exists,$exists?'Ada':'Belum terdeteksi');}
$dirs=['uploads','uploads/builder','builder','dashboard','auth','config'];
foreach($dirs as $d){$p=__DIR__.'/../'.$d;$ok=is_dir($p);$checks[]=ci('Folder /'.$d,$ok,$ok?'Ada':'Tidak ditemukan');}
$upload=__DIR__.'/../uploads/builder';if(is_dir($upload)){$w=is_writable($upload);$checks[]=ci('Upload builder writable',$w,$w?'Writable':'Tidak writable');}
$score=0;foreach($checks as $c){if($c['ok'])$score++;}$total=count($checks);$percent=$total?round($score/$total*100):0;
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Health Check — Cloud Guru</title><style>body{margin:0;font-family:Inter,system-ui,Arial;background:#f4f7fb;color:#172033}.wrap{max-width:1000px;margin:40px auto;padding:0 18px}.card{background:#fff;border:1px solid #e5eaf2;border-radius:18px;padding:22px;box-shadow:0 8px 30px #15233d0d;margin-bottom:18px}.top{display:flex;justify-content:space-between;gap:16px;align-items:center}.score{font-size:28px;font-weight:800}.bar{height:10px;background:#e9eef5;border-radius:20px;overflow:hidden}.fill{height:100%;background:#16a34a;width:<?=hc($percent)?>%}.row{display:flex;justify-content:space-between;gap:15px;padding:13px 0;border-bottom:1px solid #edf0f5}.row:last-child{border:0}.ok{color:#15803d;font-weight:700}.bad{color:#b91c1c;font-weight:700}.muted{color:#667085;font-size:14px}.diag{background:#f8fafc;border:1px solid #e5eaf2;padding:12px;border-radius:12px;font-size:13px}a{display:inline-block;margin-top:12px;text-decoration:none;color:#2563eb}</style></head><body><div class="wrap"><div class="card top"><div><h1>🩺 Cloud Guru Health Check</h1><div class="muted">Pemeriksaan read-only untuk sistem portal SDN Ciburayut 01.</div></div><div class="score"><?=hc($score)?>/<?=hc($total)?></div></div><div class="card"><div class="bar"><div class="fill"></div></div><p><strong><?=hc($percent)?>%</strong> pemeriksaan berhasil.</p><div class="diag"><strong>Database terhubung:</strong> <?=hc($dbname)?><br><strong>Jumlah tabel terdeteksi:</strong> <?=hc(count($actualTables))?></div></div><div class="card"><h2>Hasil Pemeriksaan</h2><?php foreach($checks as $c): ?><div class="row"><div><strong><?=hc($c['name'])?></strong><div class="muted"><?=hc($c['detail'])?></div></div><div class="<?=$c['ok']?'ok':'bad'?>"><?=$c['ok']?'✓ OK':'✕ CHECK'?></div></div><?php endforeach; ?></div><div class="card"><strong>Catatan:</strong><p class="muted">Setelah audit selesai, hapus folder /step30/ atau batasi aksesnya. Health Check ini read-only.</p><a href="/admin/tampilan/">← Kembali ke Website Sekolah</a></div></div></body></html>
