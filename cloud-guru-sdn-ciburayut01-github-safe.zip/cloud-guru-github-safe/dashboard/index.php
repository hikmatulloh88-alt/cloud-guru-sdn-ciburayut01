<?php
session_start();

require_once __DIR__ . '/../auth/auth.php';
wajib_login();

require_once __DIR__ . '/../config/database.php';

$page_title = 'Dashboard - Cloud Administrasi Guru';
$menu_aktif = 'dashboard';

$profile = $pdo->query("
    SELECT *
    FROM school_profile
    WHERE id = 1
    LIMIT 1
")->fetch() ?: [];

$sections = $pdo->query("
    SELECT *
    FROM dashboard_sections
    WHERE is_visible = 1
    ORDER BY sort_order ASC, id ASC
")->fetchAll();

function e($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<div class="dashboard-site">

    <!-- HERO -->
    <section class="site-hero">
        <div class="hero-content">

            <div class="hero-badge">
                🏫 <?= e($profile['school_name'] ?? 'SDN Ciburayut 01') ?>
            </div>

            <h1>
                <?= e($profile['welcome_title'] ?? 'Selamat Datang') ?>
            </h1>

            <p>
                <?= nl2br(e(
                    $profile['welcome_text']
                    ?? 'Selamat datang di Cloud Administrasi Guru.'
                )) ?>
            </p>

        </div>
    </section>


    <!-- PROFIL SEKOLAH -->
    <?php if ($profile): ?>

    <section class="dashboard-card school-profile-card">

        <div class="section-title">
            <div class="section-icon">🏫</div>
            <div>
                <h2><?= e($profile['school_name'] ?? 'Profil Sekolah') ?></h2>
                <p>Profil resmi sekolah</p>
            </div>
        </div>

        <div class="school-info-grid">

            <div class="info-box">
                <span>NPSN</span>
                <strong><?= e($profile['npsn'] ?? '-') ?></strong>
            </div>

            <div class="info-box">
                <span>Kepala Sekolah</span>
                <strong><?= e($profile['principal_name'] ?? '-') ?></strong>
            </div>

            <div class="info-box">
                <span>Telepon</span>
                <strong><?= e($profile['phone'] ?? '-') ?></strong>
            </div>

            <div class="info-box">
                <span>Email</span>
                <strong><?= e($profile['email'] ?? '-') ?></strong>
            </div>

        </div>

        <div class="school-address">
            <strong>📍 Alamat</strong>
            <p><?= nl2br(e($profile['address'] ?? '-')) ?></p>
        </div>

    </section>

    <?php endif; ?>


    <!-- SECTION DINAMIS -->
    <div class="dashboard-section-grid">

        <?php foreach ($sections as $section): ?>

        <?php
        $key = strtolower($section['section_key'] ?? '');
        ?>

        <section class="dashboard-card dynamic-card">

            <div class="section-title">

                <div class="section-icon">
                    <?= e($section['icon'] ?? '📌') ?>
                </div>

                <div>
                    <h2><?= e($section['title']) ?></h2>
                    <p>
                        <?= $key === 'profile'
                            ? 'Informasi sekolah'
                            : 'Informasi terbaru' ?>
                    </p>
                </div>

            </div>

            <div class="section-content">
                <?= nl2br(e($section['content'] ?? '')) ?>
            </div>

        </section>

        <?php endforeach; ?>

    </div>


    <!-- VISI MISI -->
    <?php if (!empty($profile['vision']) || !empty($profile['mission'])): ?>

    <section class="dashboard-card">

        <div class="section-title">
            <div class="section-icon">🎯</div>
            <div>
                <h2>Visi & Misi Sekolah</h2>
                <p>Arah dan tujuan pendidikan</p>
            </div>
        </div>

        <div class="vision-mission">

            <?php if (!empty($profile['vision'])): ?>
            <div>
                <h3>🎯 Visi</h3>
                <p><?= nl2br(e($profile['vision'])) ?></p>
            </div>
            <?php endif; ?>

            <?php if (!empty($profile['mission'])): ?>
            <div>
                <h3>🚀 Misi</h3>
                <p><?= nl2br(e($profile['mission'])) ?></p>
            </div>
            <?php endif; ?>

        </div>

    </section>

    <?php endif; ?>


    <!-- SEJARAH -->
    <?php if (!empty($profile['history'])): ?>

    <section class="dashboard-card">

        <div class="section-title">
            <div class="section-icon">📖</div>
            <div>
                <h2>Sejarah Sekolah</h2>
                <p>Perjalanan SDN Ciburayut 01</p>
            </div>
        </div>

        <div class="section-content">
            <?= nl2br(e($profile['history'])) ?>
        </div>

    </section>

    <?php endif; ?>

</div>

<style>
.dashboard-site {
    max-width: 1200px;
    margin: 0 auto;
    padding: 28px;
}

.site-hero {
    min-height: 260px;
    border-radius: 24px;
    margin-bottom: 24px;
    padding: 42px;
    display: flex;
    align-items: center;
    background: linear-gradient(135deg, #2563eb, #1e3a8a);
    color: white;
    box-shadow: 0 15px 35px rgba(15,23,42,.15);
}

.hero-badge {
    display: inline-block;
    background: rgba(255,255,255,.16);
    padding: 9px 15px;
    border-radius: 999px;
    margin-bottom: 16px;
}

.site-hero h1 {
    margin: 0 0 12px;
    font-size: 34px;
}

.site-hero p {
    margin: 0;
    max-width: 760px;
    line-height: 1.7;
    font-size: 16px;
}

.dashboard-card {
    background: white;
    border-radius: 20px;
    padding: 26px;
    margin-bottom: 24px;
    box-shadow: 0 8px 25px rgba(15,23,42,.07);
    border: 1px solid #e5e7eb;
}

.section-title {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 22px;
}

.section-title h2 {
    margin: 0;
    font-size: 21px;
    color: #0f172a;
}

.section-title p {
    margin: 4px 0 0;
    color: #64748b;
}

.section-icon {
    width: 48px;
    height: 48px;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #eff6ff;
    font-size: 24px;
}

.school-info-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.info-box {
    background: #f8fafc;
    border-radius: 14px;
    padding: 17px;
}

.info-box span {
    display: block;
    color: #64748b;
    font-size: 13px;
    margin-bottom: 7px;
}

.info-box strong {
    color: #0f172a;
}

.school-address {
    margin-top: 18px;
    padding: 18px;
    background: #f8fafc;
    border-radius: 14px;
}

.school-address p {
    margin-bottom: 0;
    color: #475569;
    line-height: 1.7;
}

.dashboard-section-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 24px;
}

.dashboard-section-grid .dashboard-card {
    margin-bottom: 0;
}

.section-content {
    color: #475569;
    line-height: 1.8;
    white-space: normal;
}

.vision-mission {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 24px;
}

.vision-mission > div {
    padding: 20px;
    background: #f8fafc;
    border-radius: 16px;
}

.vision-mission h3 {
    margin-top: 0;
}

.vision-mission p {
    color: #475569;
    line-height: 1.8;
}

@media (max-width: 800px) {
    .dashboard-site {
        padding: 15px;
    }

    .school-info-grid,
    .dashboard-section-grid,
    .vision-mission {
        grid-template-columns: 1fr;
    }

    .site-hero {
        padding: 28px;
    }

    .site-hero h1 {
        font-size: 27px;
    }
}
</style>

</main>
</body>
</html>