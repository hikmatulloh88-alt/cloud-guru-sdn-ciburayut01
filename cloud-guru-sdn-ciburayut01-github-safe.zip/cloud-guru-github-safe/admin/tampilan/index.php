<?php
declare(strict_types=1);

require_once __DIR__ . '/../../auth/auth.php';
wajib_login();
wajib_role('Admin');
require_once __DIR__ . '/../../config/database.php';

if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['website_admin_csrf'])) $_SESSION['website_admin_csrf'] = bin2hex(random_bytes(32));
$csrf = $_SESSION['website_admin_csrf'];

$defaults = [
    'site_name'=>'SDN CIBURAYUT 01',
    'tagline'=>'Portal Informasi Sekolah',
    'logo_url'=>'',
    'favicon_url'=>'',
    'primary_color'=>'#1565c0',
    'hero_image'=>'',
    'hero_eyebrow'=>'PORTAL INFORMASI SEKOLAH',
    'hero_title'=>'Selamat Datang di SDN Ciburayut 01',
    'hero_subtitle'=>'Portal resmi sekolah untuk informasi, kegiatan, profil guru, dan layanan digital.',
    'hero_button_text'=>'Jelajahi Portal →',
    'hero_button_url'=>'/?page=informasi',
    'hero_button2_text'=>'Profil Sekolah',
    'hero_button2_url'=>'/?page=profil',
    'profile_title'=>'Mengenal SDN Ciburayut 01',
    'profile_text'=>'Sekolah dasar yang terus berkembang melalui pembelajaran, kolaborasi, dan layanan digital.',
    'address'=>'Cigombong, Kabupaten Bogor',
    'phone'=>'',
    'email'=>'info@sdnciburayut01.com',
    'whatsapp'=>'',
    'facebook_url'=>'',
    'instagram_url'=>'',
    'youtube_url'=>'',
    'maps_embed_url'=>'',
    'maps_link'=>'',
    'navbar_enabled'=>'1',
    'navbar_items'=>json_encode([
        ['label'=>'Beranda','url'=>'/?page=home'],
        ['label'=>'Profil','url'=>'/?page=profil'],
        ['label'=>'Informasi','url'=>'/?page=informasi'],
        ['label'=>'Guru','url'=>'/?page=guru'],
        ['label'=>'Galeri','url'=>'/?page=galeri'],
    ], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
    'navbar_cta_text'=>'🔐 Masuk Sistem',
    'navbar_cta_url'=>'/auth/login.php',
    'footer_text'=>'© '.date('Y').' SDN Ciburayut 01. Semua hak dilindungi.',
    'footer_quicklinks'=>'Beranda|/?page=home\nProfil Sekolah|/?page=profil\nInformasi|/?page=informasi\nProfil Guru|/?page=guru\nGaleri|/?page=galeri',
    'footer_layout'=>'3',
    'footer_bg'=>'#102a43',
    'footer_text_color'=>'#ffffff',
    'footer_show_logo'=>'1','footer_show_quicklinks'=>'1','footer_show_contact'=>'1','footer_show_social'=>'1',
    'seo_title'=>'',
    'seo_description'=>'Portal resmi SDN Ciburayut 01. Informasi sekolah, berita, agenda, profil guru, galeri, dan layanan digital.',
    'seo_keywords'=>'SDN Ciburayut 01, sekolah dasar, Ciburayut, Cigombong, Bogor, portal sekolah',
    'seo_author'=>'SDN Ciburayut 01',
    'seo_og_image'=>'',
    'seo_canonical'=>'',
    'seo_robots'=>'index,follow',
];

$pdo->exec("CREATE TABLE IF NOT EXISTS website_builder_settings (id INT AUTO_INCREMENT PRIMARY KEY, setting_key VARCHAR(100) NOT NULL UNIQUE, setting_value TEXT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$pdo->exec("CREATE TABLE IF NOT EXISTS website_builder_published (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,page_slug VARCHAR(120) NOT NULL UNIQUE,content LONGTEXT NOT NULL,published_by INT UNSIGNED NULL,published_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,INDEX idx_page_slug(page_slug)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
$pdo->exec("CREATE TABLE IF NOT EXISTS website_home_gallery (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,file_url VARCHAR(500) NOT NULL UNIQUE,caption VARCHAR(255) NULL,sort_order INT NOT NULL DEFAULT 0,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX idx_gallery_sort(sort_order,id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
$pdo->exec("CREATE TABLE IF NOT EXISTS website_builder_pages (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,slug VARCHAR(120) NOT NULL UNIQUE,title VARCHAR(180) NOT NULL,status ENUM('draft','published') NOT NULL DEFAULT 'draft',sort_order INT NOT NULL DEFAULT 0,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$settings = $defaults;
try {
    $q = $pdo->query('SELECT setting_key,setting_value FROM website_builder_settings');
    foreach ($q as $r) if (array_key_exists($r['setting_key'], $settings)) $settings[$r['setting_key']] = (string)$r['setting_value'];
} catch (Throwable $e) {}

$school = [
    'school_name'=>'SDN Ciburayut 01','npsn'=>'','address'=>$settings['address'],'phone'=>$settings['phone'],'email'=>$settings['email'],'website'=>'sdnciburayut01.com',
    'principal_name'=>'','vision'=>'','mission'=>'','history'=>'','welcome_title'=>$settings['hero_title'],'welcome_text'=>$settings['hero_subtitle'],'logo'=>$settings['logo_url'],'banner'=>$settings['hero_image'],'theme_color'=>$settings['primary_color']
];
try { $q=$pdo->query('SELECT * FROM school_profile WHERE id=1 LIMIT 1'); if($r=$q->fetch()) $school=array_merge($school,$r); } catch(Throwable $e) {}

$message=''; $error='';
function h(mixed $v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function setting_save(PDO $pdo, array $data): void {
    $st=$pdo->prepare('INSERT INTO website_builder_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)');
    foreach($data as $k=>$v) $st->execute([$k,(string)$v]);
}
function navbar_json(string $raw): string {
    $items=[];
    foreach(preg_split('/\r?\n/',$raw) as $line){
        $line=trim($line); if($line==='') continue;
        [$label,$url]=array_pad(explode('|',$line,2),2,'');
        $label=trim($label); $url=trim($url);
        if($label!=='' && $url!=='' && $url!=='#') $items[]=['label'=>$label,'url'=>$url];
    }
    return json_encode($items,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
}
function navbar_text(string $json): string {
    $arr=json_decode($json,true); if(!is_array($arr)) return '';
    $out=[]; foreach($arr as $it){$label=trim((string)($it['label']??''));$url=trim((string)($it['url']??''));if($label&&$url)$out[]=$label.'|'.$url;}
    return implode("\n",$out);
}
function published_upsert(PDO $pdo,string $slug,string $html,int $userId): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS website_builder_versions (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,page_slug VARCHAR(120) NOT NULL,content LONGTEXT NOT NULL,version_note VARCHAR(255) NULL,published_by INT UNSIGNED NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX idx_page_created(page_slug,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $old=$pdo->prepare('SELECT content FROM website_builder_published WHERE page_slug=? LIMIT 1');
    $old->execute([$slug]); $oldContent=$old->fetchColumn();
    if($oldContent!==false && $oldContent!==''){
        $v=$pdo->prepare('INSERT INTO website_builder_versions(page_slug,content,version_note,published_by) VALUES(?,?,?,?)');
        $v->execute([$slug,$oldContent,'Versi sebelum publish',$userId ?: null]);
    }
    $st=$pdo->prepare('INSERT INTO website_builder_published(page_slug,content,published_by) VALUES(?,?,?) ON DUPLICATE KEY UPDATE content=VALUES(content),published_by=VALUES(published_by),published_at=CURRENT_TIMESTAMP');
    $st->execute([$slug,$html,$userId ?: null]);
}
function home_gallery_html(PDO $pdo): string {
    $rows=[]; try{$rows=$pdo->query("SELECT file_url,caption FROM website_home_gallery ORDER BY sort_order ASC,id ASC")->fetchAll();}catch(Throwable $e){}
    if(!$rows) return '';
    $items=[]; foreach($rows as $i=>$r){$url=h($r['file_url']);$cap=trim((string)($r['caption']??''));$alt=$cap!==''?h($cap):'Foto kegiatan SDN Ciburayut 01 '.($i+1);$items[]='<figure class="builder-gallery-item"><a href="'.$url.'" class="gallery-link" data-lightbox="1"><img src="'.$url.'" alt="'.$alt.'">'.($cap!==''?'<figcaption>'.h($cap).'</figcaption>':'').'</a></figure>';}
    return '<section class="preview-section home-gallery-section"><div class="eyebrow">DOKUMENTASI SEKOLAH</div><h2>Aktivitas & Kegiatan Sekolah</h2><p>Dokumentasi terbaru SDN Ciburayut 01.</p><div class="builder-gallery"><div class="builder-gallery-grid">'.implode('',$items).'</div></div></section>';
}

function make_pages(array $s,array $school, PDO $pdo): array {
    $name=h($s['site_name']); $tag=h($s['tagline']); $addr=h($s['address']);
    $heroImg=trim((string)$s['hero_image']);
    $heroStyle=$heroImg!=='' ? ' style="background-image:linear-gradient(90deg,rgba(7,36,76,.86),rgba(7,36,76,.48)),url(\''.h($heroImg).'\');background-size:cover;background-position:center;"' : '';
    $home='<section class="hero-block builder-hero public-hero-fallback"'.$heroStyle.'><div class="hero-content"><div class="eyebrow">'.h($s['hero_eyebrow']).'</div><h1>'.h($s['hero_title']).'</h1><p>'.h($s['hero_subtitle']).'</p><div class="hero-actions"><a class="hero-btn-primary" href="'.h($s['hero_button_url']).'">'.h($s['hero_button_text']).'</a><a class="hero-btn-secondary" href="'.h($s['hero_button2_url']).'">'.h($s['hero_button2_text']).'</a></div></div><div class="hero-image-badge">🏫<span>Portal Sekolah Digital</span></div></section>';
    $sectionHtml=[];
    $sectionHtml['hero']=$home;
    $sectionHtml['profile']='<section class="preview-section"><div class="eyebrow">PROFIL SEKOLAH</div><h2>'.h($s['profile_title']).'</h2><p>'.h($s['profile_text']).'</p><div class="public-info-grid"><div><b>Nama Sekolah</b><span>'.$name.'</span></div><div><b>Alamat</b><span>'.$addr.'</span></div><div><b>Website</b><span>sdnciburayut01.com</span></div></div></section>';
    $sectionHtml['gallery']=home_gallery_html($pdo);
    $sectionHtml['news']='<section class="preview-section"><div class="eyebrow">INFORMASI SEKOLAH</div><h2>Informasi Terbaru</h2><div data-news-block="1"><div class="news-placeholder">Memuat informasi sekolah...</div></div></section>';
    $sectionHtml['agenda']='<section class="preview-section"><div class="eyebrow">AGENDA</div><h2>Kegiatan Sekolah</h2><div data-agenda-block="1"><div class="agenda-placeholder">Memuat agenda sekolah...</div></div></section>';
    $sectionHtml['teachers']='<section class="preview-section"><div class="eyebrow">TENAGA PENDIDIK</div><h2>Profil Guru</h2><div data-teachers-block="1"></div></section>';
    $sectionHtml['video']='<section class="preview-section"><div class="eyebrow">VIDEO</div><h2>Kegiatan Sekolah</h2><div data-video-block="1"><p>Video dapat ditambahkan dari pengaturan website.</p></div></section>';
    $sectionHtml['contact']='<section class="preview-section" data-contact-block="1"><div class="eyebrow">HUBUNGI KAMI</div><h2>Kontak Sekolah</h2><p>'.h($s['address']).'</p></section>';
    $sectionOrder=[]; try{$q=$pdo->prepare("SELECT setting_value FROM website_builder_settings WHERE setting_key='home_sections' LIMIT 1");$q->execute();$raw=$q->fetchColumn();$sectionOrder=$raw?json_decode((string)$raw,true):[];}catch(Throwable $e){}
    if(!is_array($sectionOrder)||!$sectionOrder)$sectionOrder=['hero','profile','news','agenda','gallery','teachers','video','contact'];
    $home=''; foreach($sectionOrder as $key){if(isset($sectionHtml[$key]) && $sectionHtml[$key]!=='')$home.=$sectionHtml[$key];} 

    $profile='<section class="public-page-section"><div class="eyebrow">PROFIL SEKOLAH</div><h1>'.$name.'</h1><p>'.h($school['welcome_text'] ?: $s['profile_text']).'</p><div class="public-info-grid"><div><b>NPSN</b><span>'.h($school['npsn']).'</span></div><div><b>Kepala Sekolah</b><span>'.h($school['principal_name']).'</span></div><div><b>Alamat</b><span>'.$addr.'</span></div></div><div class="preview-section"><div class="eyebrow">VISI</div><p>'.nl2br(h($school['vision'])).'</p></div><div class="preview-section"><div class="eyebrow">MISI</div><p>'.nl2br(h($school['mission'])).'</p></div><div class="preview-section"><div class="eyebrow">SEJARAH</div><p>'.nl2br(h($school['history'])).'</p></div></section>';
    $info='<section class="public-page-section"><div class="eyebrow">INFORMASI SEKOLAH</div><h1>Pengumuman & Berita</h1><p>Informasi terbaru dari SDN Ciburayut 01.</p><div data-news-block="1"><div class="news-placeholder">Memuat informasi sekolah...</div></div></section>';
    $guru='<section class="public-page-section"><div class="eyebrow">TENAGA PENDIDIK</div><h1>Profil Guru</h1><p>Kenali tenaga pendidik dan kependidikan SDN Ciburayut 01.</p><div data-teachers-block="1"></div></section>';
    $galeri='<section class="public-page-section"><div class="eyebrow">DOKUMENTASI</div><h1>Galeri Sekolah</h1><p>Dokumentasi kegiatan SDN Ciburayut 01.</p><div class="builder-gallery"><div class="builder-gallery-grid"></div></div></section>';
    $contact='<section class="public-page-section" data-contact-block="1"><div class="eyebrow">HUBUNGI KAMI</div><h1>Kontak Sekolah</h1><p>Gunakan informasi berikut untuk menghubungi SDN Ciburayut 01.</p></section>';
    return ['home'=>$home,'profil'=>$profile,'informasi'=>$info,'guru'=>$guru,'galeri'=>$galeri,'contact'=>$contact];
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!hash_equals($csrf,(string)($_POST['_csrf']??''))){$error='Token keamanan tidak valid. Silakan muat ulang halaman.';}
    else {
        try {
            $action=$_POST['action']??'save';
            if($action==='upload'){
                if(empty($_FILES['image']) || $_FILES['image']['error']!==UPLOAD_ERR_OK) throw new RuntimeException('File gambar belum dipilih.');
                $f=$_FILES['image']; if($f['size']>8*1024*1024) throw new RuntimeException('Ukuran gambar maksimal 8 MB.');
                $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']); $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif']; if(!isset($allowed[$mime])) throw new RuntimeException('Format gambar harus JPG, PNG, WEBP, atau GIF.');
                $dir=__DIR__.'/../../uploads/builder'; if(!is_dir($dir)) mkdir($dir,0755,true);
                $name='website_'.date('Ymd_His').'_'.bin2hex(random_bytes(4)).'.'.$allowed[$mime];
                require_once __DIR__.'/../../includes/image_compress.php';
                compress_uploaded_image($f['tmp_name'],$mime,$dir.'/'.$name); $url='/uploads/builder/'.$name;
                $target=(string)($_POST['target']??'logo');
                if($target==='home_gallery'){
                    $caption=trim((string)($_POST['caption']??''));
                    $max=(int)$pdo->query('SELECT COALESCE(MAX(sort_order),0) FROM website_home_gallery')->fetchColumn();
                    $st=$pdo->prepare('INSERT INTO website_home_gallery(file_url,caption,sort_order) VALUES(?,?,?) ON DUPLICATE KEY UPDATE caption=VALUES(caption)');
                    $st->execute([$url,$caption,$max+1]);
                    $message='Gambar berhasil ditambahkan ke galeri Beranda dan dipublikasikan.';
                } else {
                    $target=$target==='hero'?'hero_image':'logo_url'; setting_save($pdo,[$target=>$url]); $settings[$target]=$url; $message='Gambar berhasil diunggah, dipasang, dan dipublikasikan.';
                }
                // Langsung publikasikan ulang halaman supaya perubahan gambar tampil di website tanpa harus klik "Simpan & Publikasikan".
                $pages=make_pages($settings,$school,$pdo); $uid=(int)($_SESSION['user_id']??0);
                foreach($pages as $slug=>$html) published_upsert($pdo,$slug,$html,$uid);
            } else {
                $keys=['site_name','tagline','logo_url','favicon_url','primary_color','hero_image','hero_eyebrow','hero_title','hero_subtitle','hero_button_text','hero_button_url','hero_button2_text','hero_button2_url','profile_title','profile_text','address','phone','email','whatsapp','facebook_url','instagram_url','youtube_url','maps_embed_url','maps_link','navbar_enabled','navbar_cta_text','navbar_cta_url','footer_text','footer_quicklinks','footer_layout','footer_bg','footer_text_color','footer_show_logo','footer_show_quicklinks','footer_show_contact','footer_show_social','seo_title','seo_description','seo_keywords','seo_author','seo_og_image','seo_canonical','seo_robots'];
                $save=[]; foreach($keys as $k){$v=trim((string)($_POST[$k]??$defaults[$k]??'')); if(in_array($k,['primary_color','footer_bg','footer_text_color'],true) && !preg_match('/^#[0-9a-fA-F]{6}$/',$v)) $v=$defaults[$k]; if(mb_strlen($v)>10000)$v=mb_substr($v,0,10000); $save[$k]=$v;}
                foreach(['footer_show_logo','footer_show_quicklinks','footer_show_contact','footer_show_social'] as $checkKey) $save[$checkKey]=isset($_POST[$checkKey])?'1':'0';
                $save['navbar_items']=navbar_json((string)($_POST['navbar_items_text']??''));
                setting_save($pdo,$save); $settings=array_merge($settings,$save);
                $profileData=['school_name'=>$save['site_name'],'npsn'=>trim((string)($_POST['npsn']??'')),'address'=>$save['address'],'phone'=>$save['phone'],'email'=>$save['email'],'website'=>'sdnciburayut01.com','principal_name'=>trim((string)($_POST['principal_name']??'')),'vision'=>trim((string)($_POST['vision']??'')),'mission'=>trim((string)($_POST['mission']??'')),'history'=>trim((string)($_POST['history']??'')),'welcome_title'=>$save['hero_title'],'welcome_text'=>$save['profile_text'],'logo'=>$save['logo_url'],'banner'=>$save['hero_image'],'theme_color'=>$save['primary_color']];
                $cols=[]; foreach($profileData as $k=>$v){$cols[]="$k=?";} $exists=(int)$pdo->query('SELECT COUNT(*) FROM school_profile WHERE id=1')->fetchColumn();
                if($exists){$st=$pdo->prepare('UPDATE school_profile SET '.implode(',',$cols).' WHERE id=1');$st->execute(array_values($profileData));} else {$st=$pdo->prepare('INSERT INTO school_profile (id,'.implode(',',array_keys($profileData)).') VALUES (1,'.implode(',',array_fill(0,count($profileData),'?')).')');$st->execute(array_values($profileData));}
                $school=array_merge($school,$profileData);
                if($action==='publish'){
                    $pages=make_pages($settings,$school,$pdo); $uid=(int)($_SESSION['user_id']??0); foreach($pages as $slug=>$html) published_upsert($pdo,$slug,$html,$uid);
                    $message='Website berhasil disimpan dan dipublikasikan.';
                } else $message='Pengaturan website berhasil disimpan. Klik “Publikasikan” untuk menerapkan perubahan ke halaman website.';
            }
        } catch(Throwable $e){$error='Gagal menyimpan: '.$e->getMessage();}
    }
}
$settings=array_merge($defaults,$settings);
$navText=navbar_text((string)$settings['navbar_items']);
$publishedAt=''; try{$q=$pdo->query("SELECT published_at FROM website_builder_published WHERE page_slug='home' LIMIT 1");$publishedAt=(string)($q->fetchColumn()?:'');}catch(Throwable $e){}
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Website Sekolah — Cloud Guru</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:Inter,system-ui,-apple-system,Segoe UI,Arial,sans-serif;background:#f4f7fb;color:#102a43}.wrap{max-width:1220px;margin:auto;padding:24px}.top{display:flex;justify-content:space-between;align-items:center;gap:18px;margin-bottom:18px}.brand{font-size:22px;font-weight:900}.sub{color:#627d98;font-size:13px;margin-top:5px}.actions{display:flex;gap:8px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;gap:7px;padding:10px 14px;border-radius:10px;border:1px solid #d9e2ec;background:#fff;color:#243b53;text-decoration:none;font-weight:800;cursor:pointer}.btn.primary{background:#1565c0;color:#fff;border-color:#1565c0}.btn.green{background:#15803d;color:#fff;border-color:#15803d}.hero{background:linear-gradient(135deg,#0b5ed7,#1677e8);color:#fff;border-radius:20px;padding:24px;margin-bottom:18px}.hero h1{margin:0 0 7px}.hero p{margin:0;opacity:.9}.status{margin-top:8px;font-size:12px;opacity:.85}.notice{padding:13px 15px;border-radius:11px;margin:12px 0}.ok{background:#dcfce7;color:#166534}.err{background:#fee2e2;color:#991b1b}.tabs{display:flex;gap:8px;overflow:auto;background:#fff;border:1px solid #e5ebf2;padding:8px;border-radius:14px;margin-bottom:16px;position:sticky;top:8px;z-index:10}.tab{border:0;background:#f5f7fa;color:#52667a;padding:10px 14px;border-radius:10px;font-weight:800;cursor:pointer;white-space:nowrap}.tab.active{background:#e8f1ff;color:#0757b8}.tabs a.tab{text-decoration:none}.panel{display:none;background:#fff;border:1px solid #e5ebf2;border-radius:18px;padding:22px;box-shadow:0 7px 24px rgba(16,42,67,.05)}.panel.active{display:block}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:15px}.grid.three{grid-template-columns:repeat(3,minmax(0,1fr))}.full{grid-column:1/-1}.field label{display:block;font-size:12px;font-weight:900;color:#334e68;margin:0 0 6px}.field input,.field textarea,.field select{width:100%;border:1px solid #d7e0ea;border-radius:10px;padding:11px 12px;font:inherit;color:#102a43;background:#fff}.field textarea{min-height:105px;resize:vertical}.help{font-size:12px;color:#829ab1;margin-top:5px;line-height:1.5}.section-title{font-size:17px;margin:0 0 14px}.section-title small{display:block;color:#829ab1;font-weight:500;font-size:12px;margin-top:4px}.preview{display:flex;gap:10px;align-items:center;padding:14px;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:12px}.preview img{width:70px;height:55px;object-fit:cover;border-radius:8px}.check{display:flex;align-items:center;gap:8px;font-weight:700;font-size:13px}.check input{width:auto}.upload{border:1px dashed #b7c6d8;border-radius:12px;padding:12px;background:#f8fafc}.bottom-save{position:sticky;bottom:12px;margin-top:18px;background:rgba(255,255,255,.94);backdrop-filter:blur(10px);border:1px solid #dce5ee;border-radius:14px;padding:10px;display:flex;justify-content:flex-end;gap:8px;z-index:9}.danger-note{background:#fff7ed;color:#9a3412;border:1px solid #fed7aa;padding:12px;border-radius:10px;font-size:12px;line-height:1.5}@media(max-width:800px){.wrap{padding:14px}.top{align-items:flex-start;flex-direction:column}.grid,.grid.three{grid-template-columns:1fr}.tabs{position:static}.hero h1{font-size:23px}}
</style></head><body><div class="wrap">
<div class="top"><div><div class="brand">🌐 Website Sekolah</div><div class="sub">Editor website SDN Ciburayut 01 — tanpa Builder / drag & drop.</div></div><div class="actions"><a class="btn" href="/dashboard/index.php">← Dashboard</a><a class="btn" href="/?page=home" target="_blank">👁 Lihat Website</a></div></div>
<div class="hero"><h1>Edit Portal SDN Ciburayut 01</h1><p>Atur isi website langsung dari Admin. Perubahan tidak menyentuh modul absensi, data siswa, profil guru, atau menu lain.</p><div class="status">Status publik terakhir: <?=h($publishedAt?:'belum dipublikasikan')?></div></div>
<?php if($message):?><div class="notice ok">✅ <?=h($message)?></div><?php endif;?><?php if($error):?><div class="notice err">⚠️ <?=h($error)?></div><?php endif;?>
<div class="tabs"><button class="tab active" data-tab="identitas">🏫 Identitas</button><button class="tab" data-tab="beranda">✨ Beranda</button><button class="tab" data-tab="profil">📖 Profil</button><button class="tab" data-tab="navigasi">🧭 Navigasi</button><button class="tab" data-tab="kontak">📍 Kontak</button><button class="tab" data-tab="footer">🧩 Footer</button><button class="tab" data-tab="seo">🔎 SEO</button><button class="tab" data-tab="media">🖼️ Media</button><a class="tab" href="/admin/tampilan/sections.php">🧩 Bagian Beranda</a><a class="tab" href="/admin/tampilan/pages.php">📄 Halaman</a><a class="tab" href="/admin/tampilan/galeri.php">🖼️ Gambar Beranda</a><a class="tab" href="/admin/tampilan/tema.php">🎨 Tema</a></div>
<form method="post" enctype="multipart/form-data"><input type="hidden" name="_csrf" value="<?=h($csrf)?>"><input type="hidden" name="action" id="formAction" value="save">
<section class="panel active" id="tab-identitas"><h2 class="section-title">Identitas Website<small>Nama, tagline, logo dan warna utama.</small></h2><div class="grid"><div class="field"><label>Nama Sekolah</label><input name="site_name" value="<?=h($settings['site_name'])?>"></div><div class="field"><label>Tagline</label><input name="tagline" value="<?=h($settings['tagline'])?>"></div><div class="field"><label>Logo URL</label><input name="logo_url" value="<?=h($settings['logo_url'])?>" placeholder="/uploads/builder/logo.png"></div><div class="field"><label>Warna Utama</label><input type="color" name="primary_color" value="<?=h($settings['primary_color'])?>"></div><div class="field"><label>Alamat</label><textarea name="address"><?=h($settings['address'])?></textarea></div><div class="field"><label>Website</label><input value="sdnciburayut01.com" disabled></div></div></section>
<section class="panel" id="tab-beranda"><h2 class="section-title">Beranda / Hero<small>Bagian paling atas website yang dilihat pengunjung.</small></h2><div class="grid"><div class="field"><label>Teks kecil</label><input name="hero_eyebrow" value="<?=h($settings['hero_eyebrow'])?>"></div><div class="field"><label>Judul utama</label><input name="hero_title" value="<?=h($settings['hero_title'])?>"></div><div class="field full"><label>Deskripsi</label><textarea name="hero_subtitle"><?=h($settings['hero_subtitle'])?></textarea></div><div class="field"><label>Tombol 1</label><input name="hero_button_text" value="<?=h($settings['hero_button_text'])?>"></div><div class="field"><label>Link tombol 1</label><input name="hero_button_url" value="<?=h($settings['hero_button_url'])?>"></div><div class="field"><label>Tombol 2</label><input name="hero_button2_text" value="<?=h($settings['hero_button2_text'])?>"></div><div class="field"><label>Link tombol 2</label><input name="hero_button2_url" value="<?=h($settings['hero_button2_url'])?>"></div><div class="field full"><label>Gambar Hero URL</label><input name="hero_image" value="<?=h($settings['hero_image'])?>" placeholder="/uploads/builder/hero.jpg"></div><div class="field full"><label>Profil singkat di Beranda</label><textarea name="profile_text"><?=h($settings['profile_text'])?></textarea></div><div class="field"><label>Judul Profil</label><input name="profile_title" value="<?=h($settings['profile_title'])?>"></div></div></section>
<section class="panel" id="tab-profil"><h2 class="section-title">Profil Sekolah<small>Data ini dipakai pada halaman Profil.</small></h2><div class="grid"><div class="field"><label>NPSN</label><input name="npsn" value="<?=h($school['npsn'])?>" id="npsn"><div class="help">Disimpan ke data profil sekolah saat publikasi.</div></div><div class="field"><label>Kepala Sekolah</label><input name="principal_name" value="<?=h($school['principal_name'])?>" id="principal_name"></div><div class="field full"><label>Visi</label><textarea name="vision" id="vision"><?=h($school['vision'])?></textarea></div><div class="field full"><label>Misi</label><textarea name="mission" id="mission"><?=h($school['mission'])?></textarea></div><div class="field full"><label>Sejarah Sekolah</label><textarea name="history" id="history"><?=h($school['history'])?></textarea></div></div><div class="danger-note" style="margin-top:15px">Data NPSN, Kepala Sekolah, Visi, Misi, dan Sejarah tersimpan di profil sekolah. Tidak mengubah data Dapodik/Absensi.</div></section>
<section class="panel" id="tab-navigasi"><h2 class="section-title">Navigasi Website<small>Satu menu per baris dengan format: Nama Menu|Link.</small></h2><div class="grid"><div class="field full"><label>Menu Navigasi</label><textarea name="navbar_items_text" rows="9"><?=h($navText)?></textarea></div><div class="field"><label>Tombol kanan</label><input name="navbar_cta_text" value="<?=h($settings['navbar_cta_text'])?>"></div><div class="field"><label>Link tombol kanan</label><input name="navbar_cta_url" value="<?=h($settings['navbar_cta_url'])?>"></div><div class="field"><label>Navbar</label><select name="navbar_enabled"><option value="1" <?=$settings['navbar_enabled']==='1'?'selected':''?>>Tampilkan</option><option value="0" <?=$settings['navbar_enabled']==='0'?'selected':''?>>Sembunyikan</option></select></div></div></section>
<section class="panel" id="tab-kontak"><h2 class="section-title">Kontak & Sosial Media<small>Informasi yang tampil di footer dan blok kontak.</small></h2><div class="grid"><div class="field"><label>Telepon</label><input name="phone" value="<?=h($settings['phone'])?>"></div><div class="field"><label>WhatsApp</label><input name="whatsapp" value="<?=h($settings['whatsapp'])?>"></div><div class="field"><label>Email</label><input name="email" value="<?=h($settings['email'])?>"></div><div class="field"><label>Google Maps Link</label><input name="maps_link" value="<?=h($settings['maps_link'])?>"></div><div class="field full"><label>Google Maps Embed URL</label><input name="maps_embed_url" value="<?=h($settings['maps_embed_url'])?>"></div><div class="field"><label>Facebook</label><input name="facebook_url" value="<?=h($settings['facebook_url'])?>"></div><div class="field"><label>Instagram</label><input name="instagram_url" value="<?=h($settings['instagram_url'])?>"></div><div class="field"><label>YouTube</label><input name="youtube_url" value="<?=h($settings['youtube_url'])?>"></div></div></section>
<section class="panel" id="tab-footer"><h2 class="section-title">Footer<small>Bagian paling bawah website.</small></h2><div class="grid"><div class="field"><label>Warna Footer</label><input type="color" name="footer_bg" value="<?=h($settings['footer_bg'])?>"></div><div class="field"><label>Warna Teks</label><input type="color" name="footer_text_color" value="<?=h($settings['footer_text_color'])?>"></div><div class="field full"><label>Menu Cepat</label><textarea name="footer_quicklinks" rows="7"><?=h($settings['footer_quicklinks'])?></textarea><div class="help">Format: Nama|Link, satu baris satu menu.</div></div><div class="field full"><label>Teks Copyright</label><input name="footer_text" value="<?=h($settings['footer_text'])?>"></div><div class="field"><label>Layout Kolom</label><select name="footer_layout"><option value="1" <?=$settings['footer_layout']==='1'?'selected':''?>>1 Kolom</option><option value="2" <?=$settings['footer_layout']==='2'?'selected':''?>>2 Kolom</option><option value="3" <?=$settings['footer_layout']==='3'?'selected':''?>>3 Kolom</option><option value="4" <?=$settings['footer_layout']==='4'?'selected':''?>>4 Kolom</option></select></div><div class="field"><label>Komponen</label><label class="check"><input type="checkbox" name="footer_show_logo" value="1" <?=$settings['footer_show_logo']==='1'?'checked':''?>> Logo/Nama</label><label class="check"><input type="checkbox" name="footer_show_quicklinks" value="1" <?=$settings['footer_show_quicklinks']==='1'?'checked':''?>> Menu cepat</label><label class="check"><input type="checkbox" name="footer_show_contact" value="1" <?=$settings['footer_show_contact']==='1'?'checked':''?>> Kontak</label><label class="check"><input type="checkbox" name="footer_show_social" value="1" <?=$settings['footer_show_social']==='1'?'checked':''?>> Sosial media</label></div></div></section>
<section class="panel" id="tab-seo"><h2 class="section-title">SEO Website<small>Judul dan deskripsi yang dibaca mesin pencari.</small></h2><div class="grid"><div class="field"><label>SEO Title</label><input name="seo_title" value="<?=h($settings['seo_title'])?>"></div><div class="field"><label>Author</label><input name="seo_author" value="<?=h($settings['seo_author'])?>"></div><div class="field full"><label>Meta Description</label><textarea name="seo_description"><?=h($settings['seo_description'])?></textarea></div><div class="field full"><label>Keywords</label><textarea name="seo_keywords"><?=h($settings['seo_keywords'])?></textarea></div><div class="field"><label>OG Image</label><input name="seo_og_image" value="<?=h($settings['seo_og_image'])?>"></div><div class="field"><label>Robots</label><select name="seo_robots"><option value="index,follow" <?=$settings['seo_robots']==='index,follow'?'selected':''?>>index,follow</option><option value="noindex,nofollow" <?=$settings['seo_robots']==='noindex,nofollow'?'selected':''?>>noindex,nofollow</option></select></div></div></section>
<div class="bottom-save"><button class="btn" type="submit" onclick="document.getElementById('formAction').value='save'">💾 Simpan Pengaturan</button><button class="btn green" type="submit" onclick="document.getElementById('formAction').value='publish'">🚀 Simpan & Publikasikan</button></div>
</form><section class="panel" id="tab-media"><h2 class="section-title">Media Website<small>Upload logo atau gambar hero tanpa Builder.</small></h2><div class="grid"><div class="upload"><form method="post" enctype="multipart/form-data"><input type="hidden" name="_csrf" value="<?=h($csrf)?>"><input type="hidden" name="action" value="upload"><input type="hidden" name="target" value="logo"><div class="field"><label>Upload Logo</label><input type="file" name="image" accept="image/jpeg,image/png,image/webp,image/gif"></div><button class="btn primary" type="submit">⬆️ Upload & Pasang Logo</button></form></div><div class="upload"><form method="post" enctype="multipart/form-data"><input type="hidden" name="_csrf" value="<?=h($csrf)?>"><input type="hidden" name="action" value="upload"><input type="hidden" name="target" value="hero"><div class="field"><label>Upload Gambar Hero</label><input type="file" name="image" accept="image/jpeg,image/png,image/webp,image/gif"></div><button class="btn primary" type="submit">⬆️ Upload & Pasang Hero</button></form></div><div class="upload"><form method="post" enctype="multipart/form-data"><input type="hidden" name="_csrf" value="<?=h($csrf)?>"><input type="hidden" name="action" value="upload"><input type="hidden" name="target" value="home_gallery"><div class="field"><label>Tambah Gambar ke Beranda</label><input type="file" name="image" accept="image/jpeg,image/png,image/webp,image/gif" required></div><div class="field"><label>Keterangan Foto (opsional)</label><input name="caption" maxlength="255" placeholder="Contoh: Kegiatan MPLS 2026"></div><button class="btn primary" type="submit">🖼️ Tambahkan ke Beranda</button></form></div></div><div class="preview" style="margin-top:15px"><?php if($settings['logo_url']):?><img src="<?=h($settings['logo_url'])?>" alt="Logo"><div><b>Logo aktif</b><div class="help"><?=h($settings['logo_url'])?></div></div><?php else:?><div><b>Belum ada logo khusus.</b><div class="help">Website akan memakai logo/identitas bawaan.</div></div><?php endif;?></div></section></div>
<script>
const tabs=document.querySelectorAll('.tab');const panels=document.querySelectorAll('.panel');tabs.forEach(btn=>btn.addEventListener('click',()=>{tabs.forEach(x=>x.classList.remove('active'));panels.forEach(x=>x.classList.remove('active'));btn.classList.add('active');document.getElementById('tab-'+btn.dataset.tab).classList.add('active');window.scrollTo({top:0,behavior:'smooth'});}));
</script></body></html>
