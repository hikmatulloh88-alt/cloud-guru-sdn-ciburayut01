<?php
declare(strict_types=1);
require_once __DIR__ . '/../../auth/auth.php'; wajib_login(); wajib_role('Admin');
require_once __DIR__ . '/../../config/database.php';
if(session_status()!==PHP_SESSION_ACTIVE) session_start();
if(empty($_SESSION['website_admin_csrf'])) $_SESSION['website_admin_csrf']=bin2hex(random_bytes(32));
$csrf=$_SESSION['website_admin_csrf'];
function h($v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
$defaults=[
 ['hero','✨ Hero / Sambutan','Bagian pembuka website'],
 ['profile','🏫 Profil Sekolah','Ringkasan sekolah'],
 ['news','📰 Berita Terbaru','Berita dan pengumuman'],
 ['agenda','📅 Agenda Sekolah','Kegiatan mendatang'],
 ['gallery','📸 Galeri','Dokumentasi kegiatan'],
 ['teachers','👨‍🏫 Profil Guru','Data guru dari aplikasi utama'],
 ['video','🎥 Video','Video kegiatan sekolah'],
 ['contact','📍 Kontak','Alamat dan kontak sekolah']
];
$defaultKeys=array_column($defaults,0);
function get_sections(PDO $pdo,array $defaults):array{
 try{$q=$pdo->prepare("SELECT setting_value FROM website_builder_settings WHERE setting_key='home_sections' LIMIT 1");$q->execute();$raw=$q->fetchColumn();$arr=$raw?json_decode((string)$raw,true):null;if(is_array($arr)){
   $valid=array_column($defaults,0);$out=[];foreach($arr as $key){if(in_array($key,$valid,true)&&!in_array($key,$out,true))$out[]=$key;}foreach($valid as $key)if(!in_array($key,$out,true))$out[]=$key;return $out;
 }}catch(Throwable $e){}
 return array_column($defaults,0);
}
function save_sections(PDO $pdo,array $keys):void{
 $allowed=['hero','profile','news','agenda','gallery','teachers','video','contact'];$out=[];foreach($keys as $k){$k=(string)$k;if(in_array($k,$allowed,true)&&!in_array($k,$out,true))$out[]=$k;}foreach($allowed as $k)if(!in_array($k,$out,true))$out[]=$k;
 $st=$pdo->prepare("INSERT INTO website_builder_settings(setting_key,setting_value) VALUES('home_sections',?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");$st->execute([json_encode($out,JSON_UNESCAPED_UNICODE)]);
}
$sections=get_sections($pdo,$defaults);$msg='';$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!hash_equals($csrf,(string)($_POST['_csrf']??''))){$err='Token keamanan tidak valid.';}else{try{$action=$_POST['action']??'';if($action==='save'){$sections=(array)($_POST['sections']??[]);save_sections($pdo,$sections);$sections=get_sections($pdo,$defaults);$msg='Susunan Beranda berhasil disimpan. Klik Publikasikan di Website Sekolah untuk menerapkannya.';}}catch(Throwable $e){$err=$e->getMessage();}}
}
$by=[];foreach($defaults as $d)$by[$d[0]]=$d;
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Bagian Beranda — Website Sekolah</title><style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#102a43;font-family:Inter,system-ui,-apple-system,Segoe UI,Arial,sans-serif}.wrap{max-width:900px;margin:auto;padding:24px}.top{display:flex;justify-content:space-between;align-items:center;gap:15px}.btn{display:inline-block;padding:10px 14px;border:1px solid #d9e2ec;border-radius:10px;background:#fff;color:#243b53;text-decoration:none;font-weight:800}.primary{background:#1565c0;color:#fff;border-color:#1565c0}.card{background:#fff;border:1px solid #e5ebf2;border-radius:18px;padding:20px;margin-top:18px}.hint{background:#eff6ff;color:#1e40af;padding:13px;border-radius:12px;font-size:13px;line-height:1.5}.item{display:flex;align-items:center;gap:12px;padding:14px;border:1px solid #e5ebf2;border-radius:14px;background:#fff;margin:9px 0;cursor:grab}.handle{font-size:20px;color:#829ab1}.item strong{display:block}.item small{color:#829ab1}.num{margin-left:auto;width:28px;height:28px;border-radius:50%;background:#eef2ff;display:flex;align-items:center;justify-content:center;font-weight:900}.savebar{position:sticky;bottom:10px;background:rgba(255,255,255,.96);padding:10px;border:1px solid #dce5ee;border-radius:14px;display:flex;justify-content:flex-end;margin-top:16px}.notice{padding:12px;border-radius:10px;margin-top:15px}.ok{background:#dcfce7;color:#166534}.err{background:#fee2e2;color:#991b1b}@media(max-width:600px){.wrap{padding:14px}.top{align-items:flex-start;flex-direction:column}}
</style></head><body><div class="wrap"><div class="top"><div><h1>🧩 Bagian Beranda</h1><p>Atur urutan isi Beranda seperti Google Sites: <b>geser lalu simpan</b>.</p></div><a class="btn" href="/admin/tampilan/">← Website Sekolah</a></div><?php if($msg):?><div class="notice ok">✅ <?=h($msg)?></div><?php endif;?><?php if($err):?><div class="notice err">⚠️ <?=h($err)?></div><?php endif;?><div class="card"><div class="hint"><b>Caranya:</b> tekan dan geser bagian ke atas/bawah. Bagian yang tidak ingin dipakai bisa disembunyikan. Urutan ini hanya mengatur Beranda website.</div><form method="post" id="sectionForm"><input type="hidden" name="_csrf" value="<?=h($csrf)?>"><input type="hidden" name="action" value="save"><div id="list"><?php foreach($sections as $i=>$key):$d=$by[$key];?><div class="item" draggable="true" data-key="<?=h($key)?>"><span class="handle">☰</span><div><strong><?=h($d[1])?></strong><small><?=h($d[2])?></small></div><span class="num"><?=($i+1)?></span><input type="hidden" name="sections[]" value="<?=h($key)?>"></div><?php endforeach;?></div><div class="savebar"><button class="btn primary" type="submit">💾 Simpan Susunan</button></div></form></div><div class="card"><h3>📌 Kelola isi bagian</h3><p>Isi bagian menggunakan menu Website Sekolah: Beranda untuk Hero/Profil, Halaman untuk halaman baru, Gambar Beranda untuk foto, Tema untuk warna, dan Media untuk upload.</p><div style="display:flex;gap:8px;flex-wrap:wrap"><a class="btn" href="/admin/tampilan/pages.php">📄 Halaman</a><a class="btn" href="/admin/tampilan/galeri.php">📸 Galeri</a><a class="btn" href="/admin/tampilan/tema.php">🎨 Tema</a></div></div></div><script>
const list=document.getElementById('list');let drag=null;function refresh(){[...list.children].forEach((el,i)=>el.querySelector('.num').textContent=i+1)}
list.addEventListener('dragstart',e=>{drag=e.target.closest('.item');if(drag)e.dataTransfer.effectAllowed='move'});list.addEventListener('dragover',e=>{e.preventDefault();const t=e.target.closest('.item');if(!drag||!t||t===drag)return;const r=t.getBoundingClientRect();list.insertBefore(drag,e.clientY<r.top+r.height/2?t:t.nextSibling);refresh()});refresh();
</script></body></html>