<?php
session_start();
require_once __DIR__ . '/../../auth/auth.php';
wajib_login();
wajib_role('Admin');
require_once __DIR__ . '/../../config/database.php';

$message = $_GET['msg'] ?? '';
$error = '';
$upload_dir = __DIR__ . '/../../uploads/guru';
if (!is_dir($upload_dir)) @mkdir($upload_dir, 0755, true);

function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function go($m){ header('Location: /admin/guru/?msg='.urlencode($m)); exit; }

if ($_SERVER['REQUEST_METHOD']==='POST') {
    try {
        if (isset($_POST['delete_teacher'])) {
            $id=(int)($_POST['id']??0);
            $s=$pdo->prepare("SELECT photo FROM teachers WHERE id=?"); $s->execute([$id]); $old=$s->fetch();
            if ($old && $old['photo'] && is_file($upload_dir.'/'.basename($old['photo']))) @unlink($upload_dir.'/'.basename($old['photo']));
            $pdo->prepare("DELETE FROM teachers WHERE id=?")->execute([$id]);
            go('Profil guru berhasil dihapus.');
        }

        if (isset($_POST['save_teacher'])) {
            $id=(int)($_POST['id']??0);
            $name=trim($_POST['name']??'');
            if ($name==='') throw new Exception('Nama guru wajib diisi.');

            $photo=null;
            if (!empty($_FILES['photo']['name']) && $_FILES['photo']['error']!==UPLOAD_ERR_NO_FILE) {
                if ($_FILES['photo']['error']!==UPLOAD_ERR_OK) throw new Exception('Upload foto gagal.');
                if ($_FILES['photo']['size']>5*1024*1024) throw new Exception('Ukuran foto maksimal 5 MB.');
                $mime=(new finfo(FILEINFO_MIME_TYPE))->file($_FILES['photo']['tmp_name']);
                $map=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
                if (!isset($map[$mime])) throw new Exception('Foto harus JPG, PNG, atau WEBP.');
                $photo='guru_'.date('YmdHis').'_'.bin2hex(random_bytes(4)).'.'.$map[$mime];
                if (!move_uploaded_file($_FILES['photo']['tmp_name'],$upload_dir.'/'.$photo)) throw new Exception('Foto tidak dapat disimpan.');
            }

            $data=[
                $name,trim($_POST['nip']??''),trim($_POST['nuptk']??''),
                in_array($_POST['gender']??'', ['L','P'], true)?$_POST['gender']:null,
                trim($_POST['position']??''),trim($_POST['subject']??''),trim($_POST['education']??''),
                trim($_POST['email']??''),trim($_POST['phone']??''),trim($_POST['bio']??''),
                (int)($_POST['sort_order']??0),isset($_POST['is_active'])?1:0
            ];

            if ($id) {
                if ($photo) {
                    $s=$pdo->prepare("SELECT photo FROM teachers WHERE id=?"); $s->execute([$id]); $old=$s->fetch();
                    $data[]=$photo; $data[]=$id;
                    $pdo->prepare("UPDATE teachers SET name=?,nip=?,nuptk=?,gender=?,position=?,subject=?,education=?,email=?,phone=?,bio=?,sort_order=?,is_active=?,photo=? WHERE id=?")->execute($data);
                    if ($old && $old['photo'] && is_file($upload_dir.'/'.basename($old['photo']))) @unlink($upload_dir.'/'.basename($old['photo']));
                } else {
                    $data[]=$id;
                    $pdo->prepare("UPDATE teachers SET name=?,nip=?,nuptk=?,gender=?,position=?,subject=?,education=?,email=?,phone=?,bio=?,sort_order=?,is_active=? WHERE id=?")->execute($data);
                }
                go('Profil guru berhasil diperbarui.');
            } else {
                $data[]=$photo;
                $pdo->prepare("INSERT INTO teachers (name,nip,nuptk,gender,position,subject,education,email,phone,bio,sort_order,is_active,photo) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)")->execute($data);
                go('Profil guru berhasil ditambahkan.');
            }
        }
    } catch(Throwable $ex){ $error=$ex->getMessage(); }
}

$edit=null;
if(isset($_GET['edit'])){
    $s=$pdo->prepare("SELECT * FROM teachers WHERE id=?"); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch()?:null;
}
$q=trim($_GET['q']??'');
if($q!==''){
    $s=$pdo->prepare("SELECT * FROM teachers WHERE name LIKE ? OR nip LIKE ? OR nuptk LIKE ? OR position LIKE ? OR subject LIKE ? ORDER BY sort_order,id");
    $like='%'.$q.'%'; $s->execute([$like,$like,$like,$like,$like]); $teachers=$s->fetchAll();
}else $teachers=$pdo->query("SELECT * FROM teachers ORDER BY sort_order,id")->fetchAll();

$page_title='Profil Guru'; $menu_aktif='guru';
require_once __DIR__ . '/../../includes/header.php';
?>

<div class="guru-admin">
  <div class="page-head">
    <div><h1>👨‍🏫 Profil Guru</h1><p>Kelola data, foto, dan profil guru sekolah.</p></div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <a class="guru-btn" href="/guru/">👁️ Lihat Profil</a>
      <a class="guru-btn secondary" href="/absensi_sd/modules/pengguna/generate_guru.php">🔑 Buat Akun Guru</a>
    </div>
  </div>

  <?php if($message): ?><div class="guru-alert success"><?=e($message)?></div><?php endif; ?>
  <?php if($error): ?><div class="guru-alert error"><?=e($error)?></div><?php endif; ?>

  <section class="guru-card">
    <h2><?= $edit?'✏️ Edit Guru':'➕ Tambah Guru' ?></h2>
    <form method="post" enctype="multipart/form-data">
      <input type="hidden" name="save_teacher" value="1"><input type="hidden" name="id" value="<?= (int)($edit['id']??0) ?>">
      <div class="guru-form-grid">
        <label>Nama Lengkap *<input required name="name" value="<?=e($edit['name']??'')?>"></label>
        <label>NIP<input name="nip" value="<?=e($edit['nip']??'')?>"></label>
        <label>NUPTK<input name="nuptk" value="<?=e($edit['nuptk']??'')?>"></label>
        <label>Jenis Kelamin<select name="gender"><option value="">Pilih</option><option value="L" <?=($edit['gender']??'')==='L'?'selected':''?>>Laki-laki</option><option value="P" <?=($edit['gender']??'')==='P'?'selected':''?>>Perempuan</option></select></label>
        <label>Jabatan<input name="position" value="<?=e($edit['position']??'')?>" placeholder="Guru Kelas"></label>
        <label>Mata Pelajaran<input name="subject" value="<?=e($edit['subject']??'')?>"></label>
        <label>Pendidikan<input name="education" value="<?=e($edit['education']??'')?>" placeholder="S1 PGSD"></label>
        <label>Email<input type="email" name="email" value="<?=e($edit['email']??'')?>"></label>
        <label>Telepon<input name="phone" value="<?=e($edit['phone']??'')?>"></label>
        <label>Urutan<input type="number" name="sort_order" value="<?= (int)($edit['sort_order']??0) ?>"></label>
      </div>
      <label>Foto Guru<input type="file" name="photo" accept=".jpg,.jpeg,.png,.webp"><small>JPG/PNG/WEBP, maksimal 5 MB.</small></label>
      <?php if(!empty($edit['photo'])): ?><div class="current-photo"><img src="/uploads/guru/<?=e(basename($edit['photo']))?>" alt=""><span>Foto saat ini</span></div><?php endif; ?>
      <label>Biodata / Deskripsi<textarea name="bio" rows="4"><?=e($edit['bio']??'')?></textarea></label>
      <label class="checkline"><input type="checkbox" name="is_active" <?=(!isset($edit['is_active'])||$edit['is_active'])?'checked':''?>> Tampilkan di Profil Guru</label>
      <div class="guru-actions"><button class="guru-btn" type="submit">💾 <?=$edit?'Simpan Perubahan':'Tambah Guru'?></button><?php if($edit):?><a class="guru-btn secondary" href="/admin/guru/">Batal</a><?php endif;?></div>
    </form>
  </section>

  <section class="guru-card">
    <div class="list-head"><div><h2>📋 Daftar Guru</h2><p><?=count($teachers)?> data ditemukan.</p></div>
      <form class="search-guru" method="get"><input name="q" value="<?=e($q)?>" placeholder="Cari nama, NIP, jabatan..."><button class="guru-btn">🔎 Cari</button></form>
    </div>
    <div class="guru-table-wrap"><table class="guru-table"><thead><tr><th>Foto</th><th>Guru</th><th>Jabatan/Mapel</th><th>Status</th><th>Aksi</th></tr></thead><tbody>
    <?php foreach($teachers as $t): ?><tr>
      <td><?php if($t['photo']):?><img class="avatar-small" src="/uploads/guru/<?=e(basename($t['photo']))?>" alt=""><?php else:?><div class="avatar-small placeholder">👤</div><?php endif;?></td>
      <td><strong><?=e($t['name'])?></strong><br><small>NIP: <?=e($t['nip']?:'-')?> · NUPTK: <?=e($t['nuptk']?:'-')?></small></td>
      <td><?=e($t['position']?:'-')?><br><small><?=e($t['subject']?:'-')?></small></td>
      <td><?=$t['is_active']?'<span class="status on">Aktif</span>':'<span class="status off">Disembunyikan</span>'?></td>
      <td class="actions"><a href="?edit=<?=(int)$t['id']?>">✏️ Edit</a><form method="post" onsubmit="return confirm('Hapus profil guru ini?')"><input type="hidden" name="delete_teacher" value="1"><input type="hidden" name="id" value="<?=(int)$t['id']?>"><button>🗑️ Hapus</button></form></td>
    </tr><?php endforeach; ?>
    <?php if(!$teachers):?><tr><td colspan="5" class="empty">Belum ada data guru.</td></tr><?php endif;?>
    </tbody></table></div>
  </section>
</div>
</main></body></html>
