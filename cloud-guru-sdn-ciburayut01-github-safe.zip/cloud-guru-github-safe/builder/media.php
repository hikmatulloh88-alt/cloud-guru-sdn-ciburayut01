<?php
require_once dirname(__DIR__) . '/auth/auth.php';
wajib_login(); wajib_role('Admin');
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/../config/database.php';
header('Content-Type: application/json; charset=utf-8');
try {
 $pdo->exec("CREATE TABLE IF NOT EXISTS website_builder_media (id INT AUTO_INCREMENT PRIMARY KEY, file_name VARCHAR(255) NOT NULL, file_url VARCHAR(500) NOT NULL, mime VARCHAR(80) NOT NULL, size_bytes BIGINT NOT NULL DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uq_url(file_url)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $action=$_GET['action']??'list';
 if($_SERVER['REQUEST_METHOD']==='POST'){ csrf_require(); }
 $dir=dirname(__DIR__).'/uploads/builder';
 if(!is_dir($dir)) @mkdir($dir,0755,true);
 if($action==='list'){
   $rows=$pdo->query("SELECT id,file_name,file_url,mime,size_bytes,created_at FROM website_builder_media ORDER BY id DESC")->fetchAll();
   echo json_encode(['ok'=>true,'files'=>$rows]); exit;
 }
 if($action==='upload'){
   if(empty($_FILES['image']) || $_FILES['image']['error']!==UPLOAD_ERR_OK) throw new Exception('File tidak diterima');
   $f=$_FILES['image']; if($f['size']>8*1024*1024) throw new Exception('Maksimal 8 MB');
   $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
   $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
   if(!isset($allowed[$mime])) throw new Exception('Format harus JPG, PNG, WEBP, atau GIF');
   $base=pathinfo($f['name'],PATHINFO_FILENAME); $base=preg_replace('/[^a-zA-Z0-9_-]+/','-', $base); $base=trim($base,'-')?:'gambar';
   $name=$base.'-'.bin2hex(random_bytes(5)).'.'.$allowed[$mime]; $target=$dir.'/'.$name;
   if(!move_uploaded_file($f['tmp_name'],$target)) throw new Exception('Gagal menyimpan file');
   $url='/uploads/builder/'.$name; $st=$pdo->prepare("INSERT INTO website_builder_media(file_name,file_url,mime,size_bytes) VALUES(?,?,?,?)");$st->execute([$f['name'],$url,$mime,$f['size']]);
   echo json_encode(['ok'=>true,'file'=>['id'=>$pdo->lastInsertId(),'file_name'=>$f['name'],'file_url'=>$url,'mime'=>$mime,'size_bytes'=>$f['size']]]); exit;
 }
 if($action==='delete'){
   $id=(int)($_POST['id']??0); $st=$pdo->prepare("SELECT file_url FROM website_builder_media WHERE id=?");$st->execute([$id]);$r=$st->fetch(); if(!$r) throw new Exception('File tidak ditemukan');
   $path=dirname(__DIR__).parse_url($r['file_url'],PHP_URL_PATH); if(is_file($path)) @unlink($path);
   $pdo->prepare("DELETE FROM website_builder_media WHERE id=?")->execute([$id]); echo json_encode(['ok'=>true]); exit;
 }
 throw new Exception('Aksi tidak dikenal');
} catch(Throwable $e){ http_response_code(400); echo json_encode(['ok'=>false,'message'=>$e->getMessage()]); }
