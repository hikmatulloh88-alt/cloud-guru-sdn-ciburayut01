<?php
require_once __DIR__ . '/../auth/auth.php';
wajib_login(); wajib_role('Admin');
require_once __DIR__ . '/../builder/security.php';
require_once __DIR__ . '/../config/database.php';
header('Content-Type: application/json; charset=utf-8');

try {
  $pdo->exec("CREATE TABLE IF NOT EXISTS website_builder_settings (id INT AUTO_INCREMENT PRIMARY KEY, setting_key VARCHAR(100) NOT NULL UNIQUE, setting_value TEXT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_require();
    $data=json_decode(file_get_contents('php://input'),true) ?: [];
    $theme=preg_replace('/[^a-z0-9_-]/i','', (string)($data['theme']??''));
    $allowed=['blue','green','purple','orange','dark','minimal'];
    if(!in_array($theme,$allowed,true)) throw new Exception('Tema tidak valid');
    $st=$pdo->prepare("INSERT INTO website_builder_settings(setting_key,setting_value) VALUES('theme',?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");
    $st->execute([$theme]);
    echo json_encode(['ok'=>true,'theme'=>$theme]); exit;
  }
  $st=$pdo->prepare("SELECT setting_value FROM website_builder_settings WHERE setting_key='theme' LIMIT 1");
  $st->execute(); $theme=$st->fetchColumn() ?: 'blue';
  echo json_encode(['ok'=>true,'theme'=>$theme]);
} catch(Throwable $e) {
  http_response_code(500); echo json_encode(['ok'=>false,'message'=>$e->getMessage()]);
}
