<?php
require_once __DIR__ . '/../auth/auth.php';
wajib_login(); wajib_role('Admin');
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/../config/database.php';
header('Content-Type: application/json; charset=utf-8');
$defaults=[
 'navbar_enabled'=>'1',
 'navbar_items'=>json_encode([
  ['label'=>'Beranda','url'=>'/?page=home'],['label'=>'Profil','url'=>'/?page=profil'],['label'=>'Informasi','url'=>'/?page=informasi'],['label'=>'Guru','url'=>'/?page=guru'],['label'=>'Galeri','url'=>'/?page=galeri']
 ],JSON_UNESCAPED_UNICODE),
 'navbar_cta_text'=>'🔐 Masuk Sistem','navbar_cta_url'=>'/auth/login.php','navbar_style'=>'glass'
];
try{
 $pdo->exec("CREATE TABLE IF NOT EXISTS website_builder_settings (id INT AUTO_INCREMENT PRIMARY KEY, setting_key VARCHAR(100) NOT NULL UNIQUE, setting_value TEXT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 if($_SERVER['REQUEST_METHOD']==='POST'){ csrf_require(); }
if($_SERVER['REQUEST_METHOD']==='POST'){
  $d=json_decode(file_get_contents('php://input'),true) ?: [];
  $items=is_array($d['navbar_items']??null)?$d['navbar_items']:[]; $clean=[];
  foreach($items as $it){$label=trim((string)($it['label']??''));$url=trim((string)($it['url']??''));if($label==='')continue;if(strlen($label)>60)$label=substr($label,0,60);if(!preg_match('#^(https?://|/|\?)[^\s]{0,400}$#i',$url))$url='#';$clean[]=['label'=>$label,'url'=>$url];}
  if(!$clean)$clean=json_decode($defaults['navbar_items'],true);
  $save=['navbar_enabled'=>!empty($d['navbar_enabled'])?'1':'0','navbar_items'=>json_encode($clean,JSON_UNESCAPED_UNICODE),'navbar_cta_text'=>trim((string)($d['navbar_cta_text']??$defaults['navbar_cta_text'])),'navbar_cta_url'=>trim((string)($d['navbar_cta_url']??$defaults['navbar_cta_url'])),'navbar_style'=>in_array(($d['navbar_style']??''),['solid','glass','minimal'],true)?$d['navbar_style']:'glass'];
  foreach($save as $k=>$v){if(strlen($v)>5000)$v=substr($v,0,5000);$st=$pdo->prepare("INSERT INTO website_builder_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");$st->execute([$k,$v]);}
  echo json_encode(['ok'=>true]);exit;
 }
 $out=$defaults;$q=$pdo->query("SELECT setting_key,setting_value FROM website_builder_settings WHERE setting_key LIKE 'navbar_%'");foreach($q as $r)if(array_key_exists($r['setting_key'],$out))$out[$r['setting_key']]=$r['setting_value'];
 $out['navbar_items']=json_decode($out['navbar_items'],true) ?: json_decode($defaults['navbar_items'],true);
 $out['navbar_enabled']=$out['navbar_enabled']==='1';echo json_encode(['ok'=>true,'navbar'=>$out],JSON_UNESCAPED_UNICODE);
}catch(Throwable $e){http_response_code(500);echo json_encode(['ok'=>false,'message'=>'Gagal memproses navbar']);}
