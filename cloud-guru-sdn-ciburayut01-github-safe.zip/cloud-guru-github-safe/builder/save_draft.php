<?php
require_once __DIR__ . '/../auth/auth.php';
wajib_login();
wajib_role('Admin');
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok'=>false,'message'=>'Metode tidak diizinkan']);
    exit;
}

csrf_require();

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data) || empty($data['html'])) {
    http_response_code(422);
    echo json_encode(['ok'=>false,'message'=>'Data draft tidak valid']);
    exit;
}

$html = (string)$data['html'];
$pageSlug = strtolower(trim((string)($data['page_slug'] ?? 'home')));
if (!preg_match('/^[a-z0-9-]{1,120}$/', $pageSlug)) $pageSlug='home';
if (strlen($html) > 2000000) {
    http_response_code(413);
    echo json_encode(['ok'=>false,'message'=>'Draft terlalu besar']);
    exit;
}

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS website_builder_drafts (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        page_slug VARCHAR(100) NOT NULL DEFAULT 'home',
        content LONGTEXT NOT NULL,
        updated_by INT UNSIGNED NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_page_slug (page_slug)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $userId = function_exists('user_id') ? (int)user_id() : (int)($_SESSION['user_id'] ?? 0);
    $stmt = $pdo->prepare("INSERT INTO website_builder_drafts (page_slug, content, updated_by)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE content=VALUES(content), updated_by=VALUES(updated_by), updated_at=CURRENT_TIMESTAMP");
    $stmt->execute([$pageSlug, $html, $userId ?: null]);
    // Sinkronkan status halaman menjadi draft.
    $pdo->exec("CREATE TABLE IF NOT EXISTS website_builder_pages (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, slug VARCHAR(120) NOT NULL UNIQUE, title VARCHAR(180) NOT NULL, status ENUM('draft','published') NOT NULL DEFAULT 'draft', sort_order INT NOT NULL DEFAULT 0, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $u=$pdo->prepare("UPDATE website_builder_pages SET status='draft' WHERE slug=?"); $u->execute([$pageSlug]);

    echo json_encode(['ok'=>true,'message'=>'Draft tersimpan','updated_at'=>date('c')]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'message'=>'Gagal menyimpan draft ke database']);
}
