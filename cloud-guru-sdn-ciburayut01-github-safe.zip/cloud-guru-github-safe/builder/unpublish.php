<?php
require_once __DIR__ . '/../auth/auth.php'; wajib_login(); wajib_role('Admin');
require_once __DIR__ . '/security.php'; require_once __DIR__ . '/../config/database.php'; header('Content-Type: application/json; charset=utf-8');
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);echo json_encode(['ok'=>false,'message'=>'Metode tidak diizinkan']);exit;}
$data=json_decode(file_get_contents('php://input'),true)?:[];$slug=strtolower(trim((string)($data['page_slug']??'home')));if(!preg_match('/^[a-z0-9-]{1,120}$/',$slug))$slug='home';
try{$pdo->beginTransaction();$s=$pdo->prepare("DELETE FROM website_builder_published WHERE page_slug=?");$s->execute([$slug]);$u=$pdo->prepare("UPDATE website_builder_pages SET status='draft' WHERE slug=?");$u->execute([$slug]);$pdo->commit();echo json_encode(['ok'=>true,'message'=>'Halaman dikembalikan ke Draft']);}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();http_response_code(500);echo json_encode(['ok'=>false,'message'=>'Gagal melakukan unpublish']);}
