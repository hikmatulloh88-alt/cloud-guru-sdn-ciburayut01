<?php
require_once __DIR__ . '/../auth/auth.php';
wajib_login();
wajib_role('Admin');
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/../config/database.php';
header('Content-Type: application/json; charset=utf-8');

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS website_builder_pages (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        slug VARCHAR(120) NOT NULL,
        title VARCHAR(180) NOT NULL,
        status ENUM('draft','published') NOT NULL DEFAULT 'draft',
        sort_order INT NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_slug (slug)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    if ((int)$pdo->query("SELECT COUNT(*) FROM website_builder_pages")->fetchColumn()===0) {
        $s=$pdo->prepare("INSERT INTO website_builder_pages(slug,title,status,sort_order) VALUES(?,?,?,?)");
        foreach([
            ['home','Beranda','published',0],
            ['profil','Profil Sekolah','draft',1],
            ['informasi','Informasi','draft',2],
            ['guru','Profil Guru','draft',3],
            ['galeri','Galeri','draft',4]
        ] as $p) $s->execute($p);
    }

    $action=$_GET['action']??'list';

    if($action==='list'){
        $rows=$pdo->query("SELECT id,slug,title,status,sort_order,updated_at FROM website_builder_pages ORDER BY sort_order,id")->fetchAll();
        echo json_encode(['ok'=>true,'pages'=>$rows]); exit;
    }

if ($_SERVER['REQUEST_METHOD']==='POST') { csrf_require(); }
    if($action==='add' && $_SERVER['REQUEST_METHOD']==='POST'){
        $d=json_decode(file_get_contents('php://input'),true)?:[];
        $title=trim((string)($d['title']??'Halaman Baru'));
        if($title==='')$title='Halaman Baru';
        $slug=strtolower(trim(preg_replace('/[^a-z0-9]+/i','-',$title),'-'));
        if($slug==='')$slug='halaman-baru';
        $base=$slug;$n=2;
        while(true){
            $q=$pdo->prepare("SELECT COUNT(*) FROM website_builder_pages WHERE slug=?");
            $q->execute([$slug]);
            if((int)$q->fetchColumn()===0)break;
            $slug=$base.'-'.$n++;
        }
        $max=(int)$pdo->query("SELECT COALESCE(MAX(sort_order),0) FROM website_builder_pages")->fetchColumn();
        $q=$pdo->prepare("INSERT INTO website_builder_pages(slug,title,status,sort_order) VALUES(?,?,'draft',?)");
        $q->execute([$slug,$title,$max+1]);
        echo json_encode(['ok'=>true,'id'=>$pdo->lastInsertId(),'slug'=>$slug]); exit;
    }

    if($action==='rename' && $_SERVER['REQUEST_METHOD']==='POST'){
        $d=json_decode(file_get_contents('php://input'),true)?:[];
        $id=(int)($d['id']??0);$title=trim((string)($d['title']??''));
        if(!$id||$title==='')throw new RuntimeException('Data halaman tidak valid');
        $q=$pdo->prepare("UPDATE website_builder_pages SET title=? WHERE id=? AND slug<>'home'");
        $q->execute([$title,$id]);
        echo json_encode(['ok'=>true]); exit;
    }

    if($action==='delete' && $_SERVER['REQUEST_METHOD']==='POST'){
        $d=json_decode(file_get_contents('php://input'),true)?:[];
        $id=(int)($d['id']??0);
        $q=$pdo->prepare("DELETE FROM website_builder_pages WHERE id=? AND slug<>'home'");
        $q->execute([$id]);
        echo json_encode(['ok'=>true]); exit;
    }

    http_response_code(400);echo json_encode(['ok'=>false,'message'=>'Aksi tidak dikenal']);
}catch(Throwable $e){
    http_response_code(500);echo json_encode(['ok'=>false,'message'=>'Gagal mengelola halaman']);
}
