<?php
require_once dirname(__DIR__) . '/auth/auth.php';
wajib_login();
wajib_role('Admin');
require_once __DIR__ . '/security.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_FILES['image'])) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'message'=>'Tidak ada gambar']);
    exit;
}

csrf_require();

$f=$_FILES['image'];
if ($f['error'] !== UPLOAD_ERR_OK) {
    $map = [UPLOAD_ERR_INI_SIZE=>'File melebihi batas upload server', UPLOAD_ERR_FORM_SIZE=>'File melebihi batas form', UPLOAD_ERR_PARTIAL=>'Upload file tidak lengkap', UPLOAD_ERR_NO_FILE=>'Tidak ada file', UPLOAD_ERR_NO_TMP_DIR=>'Folder temporary server tidak tersedia', UPLOAD_ERR_CANT_WRITE=>'Server tidak dapat menulis file', UPLOAD_ERR_EXTENSION=>'Upload dihentikan ekstensi server'];
    http_response_code(400); echo json_encode(['ok'=>false,'message'=>$map[$f['error']] ?? ('Upload gambar gagal (kode '.$f['error'].')')]); exit;
}
if ($f['size'] > 10*1024*1024) {
    http_response_code(413); echo json_encode(['ok'=>false,'message'=>'Ukuran gambar maksimal 10 MB']); exit;
}

$mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
$allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
if (!isset($allowed[$mime])) {
    http_response_code(415); echo json_encode(['ok'=>false,'message'=>'Format hanya JPG, PNG, atau WEBP']); exit;
}

$dir=dirname(__DIR__).'/uploads/builder';
if (!is_dir($dir) && !mkdir($dir,0755,true)) {
    http_response_code(500); echo json_encode(['ok'=>false,'message'=>'Folder upload tidak dapat dibuat']); exit;
}
$name='img_'.bin2hex(random_bytes(12)).'.'.$allowed[$mime];
$target=$dir.'/'.$name;
$tmpUploaded=$dir.'/tmp_'.bin2hex(random_bytes(6));
if (!move_uploaded_file($f['tmp_name'],$tmpUploaded)) {
    http_response_code(500); echo json_encode(['ok'=>false,'message'=>'Gambar gagal disimpan']); exit;
}
require_once dirname(__DIR__).'/includes/image_compress.php';
compress_uploaded_image($tmpUploaded,$mime,$target);
@unlink($tmpUploaded);
clearstatcache();
if (!is_file($target)) {
    http_response_code(500); echo json_encode(['ok'=>false,'message'=>'Gambar gagal disimpan']); exit;
}

$url='/uploads/builder/'.$name;
try {
    $dbFile=dirname(__DIR__).'/config/database.php';
    if(is_file($dbFile)){ require_once $dbFile; $pdo->exec("CREATE TABLE IF NOT EXISTS website_builder_media (id INT AUTO_INCREMENT PRIMARY KEY, file_name VARCHAR(255) NOT NULL, file_url VARCHAR(500) NOT NULL UNIQUE, mime VARCHAR(80) NOT NULL, size_bytes BIGINT NOT NULL DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
      $st=$pdo->prepare('INSERT IGNORE INTO website_builder_media(file_name,file_url,mime,size_bytes) VALUES(?,?,?,?)'); $st->execute([$f['name'],$url,$mime,filesize($target)?:$f['size']]);
    }
} catch(Throwable $e) { /* file upload remains successful even if media indexing fails */ }
echo json_encode(['ok'=>true,'url'=>$url,'name'=>$name]);
