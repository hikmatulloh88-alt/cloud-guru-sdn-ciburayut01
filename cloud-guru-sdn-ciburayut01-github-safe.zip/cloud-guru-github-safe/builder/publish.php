<?php
require_once __DIR__ . '/../auth/auth.php';
wajib_login();
wajib_role('Admin');
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/../config/database.php';
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); echo json_encode(['ok'=>false,'message'=>'Metode tidak diizinkan']); exit;
}

csrf_require();
$data = json_decode(file_get_contents('php://input'), true);
$html = is_array($data) ? (string)($data['html'] ?? '') : '';
$pageSlug = is_array($data) ? strtolower(trim((string)($data['page_slug'] ?? 'home'))) : 'home';
if (!preg_match('/^[a-z0-9-]{1,120}$/', $pageSlug)) $pageSlug='home';
if ($html === '') { http_response_code(422); echo json_encode(['ok'=>false,'message'=>'Tidak ada konten untuk dipublikasikan']); exit; }
if (strlen($html) > 2000000) { http_response_code(413); echo json_encode(['ok'=>false,'message'=>'Konten terlalu besar']); exit; }
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS website_builder_published (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        page_slug VARCHAR(100) NOT NULL DEFAULT 'home',
        content LONGTEXT NOT NULL,
        published_by INT UNSIGNED NULL,
        published_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_page_slug (page_slug)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $userId = function_exists('user_id') ? (int)user_id() : (int)($_SESSION['user_id'] ?? 0);
    $pdo->exec("CREATE TABLE IF NOT EXISTS website_builder_versions (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,page_slug VARCHAR(120) NOT NULL,content LONGTEXT NOT NULL,version_note VARCHAR(255) NULL,published_by INT UNSIGNED NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX idx_page_created(page_slug,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $oldStmt=$pdo->prepare("SELECT content FROM website_builder_published WHERE page_slug=? LIMIT 1"); $oldStmt->execute([$pageSlug]); $oldContent=$oldStmt->fetchColumn();
    if($oldContent!==false && $oldContent!==''){ $vs=$pdo->prepare("INSERT INTO website_builder_versions(page_slug,content,version_note,published_by) VALUES(?,?,?,?)"); $vs->execute([$pageSlug,$oldContent,'Versi sebelum publish',$userId ?: null]); $trim=$pdo->prepare("DELETE FROM website_builder_versions WHERE page_slug=? AND id NOT IN (SELECT id FROM (SELECT id FROM website_builder_versions WHERE page_slug=? ORDER BY id DESC LIMIT 20) keep)"); $trim->execute([$pageSlug,$pageSlug]); }
    $stmt = $pdo->prepare("INSERT INTO website_builder_published (page_slug,content,published_by)
        VALUES (?,?,?)
        ON DUPLICATE KEY UPDATE content=VALUES(content),published_by=VALUES(published_by),published_at=CURRENT_TIMESTAMP");
    $stmt->execute([$pageSlug, $html, $userId ?: null]);
    $pdo->exec("CREATE TABLE IF NOT EXISTS website_builder_pages (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, slug VARCHAR(120) NOT NULL UNIQUE, title VARCHAR(180) NOT NULL, status ENUM('draft','published') NOT NULL DEFAULT 'draft', sort_order INT NOT NULL DEFAULT 0, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $u=$pdo->prepare("UPDATE website_builder_pages SET status='published' WHERE slug=?"); $u->execute([$pageSlug]);
    echo json_encode(['ok'=>true,'message'=>'Website berhasil dipublikasikan','published_at'=>date('c')]);
} catch (Throwable $e) {
    http_response_code(500); echo json_encode(['ok'=>false,'message'=>'Gagal mempublikasikan website']);
}
