<?php
/**
 * Sanitasi ringan HTML Builder. Hanya menghapus literal nilai placeholder
 * "undefined" dari teks yang akan disimpan/dipublikasikan.
 */
function builder_sanitize_html(string $html): string {
    // Exact visible text node: > undefined < (whitespace is preserved around the tag).
    $html = preg_replace('/>(\s*)undefined(\s*)</i', '>$1$2<', $html) ?? $html;
    // Common malformed profile title from old drafts.
    $html = preg_replace('/(<h2\b[^>]*>)\s*undefined\s*(<\/h2>)/i', '$1$2', $html) ?? $html;
    return $html;
}
