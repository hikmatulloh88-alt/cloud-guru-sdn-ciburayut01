<?php
// Security helpers for Cloud Guru Builder
if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
function csrf_token(): string {
    if (empty($_SESSION['builder_csrf'])) {
        $_SESSION['builder_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['builder_csrf'];
}
function csrf_require(): void {
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['_csrf'] ?? '');
    if (!is_string($token) || $token === '' || empty($_SESSION['builder_csrf']) || !hash_equals($_SESSION['builder_csrf'], $token)) {
        http_response_code(419);
        if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== false || str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json')) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok'=>false,'message'=>'Token keamanan tidak valid. Muat ulang halaman lalu coba lagi.']);
        } else {
            echo 'Permintaan ditolak: token keamanan tidak valid.';
        }
        exit;
    }
}

// Basic browser hardening for builder responses.
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-Frame-Options: SAMEORIGIN');
}
