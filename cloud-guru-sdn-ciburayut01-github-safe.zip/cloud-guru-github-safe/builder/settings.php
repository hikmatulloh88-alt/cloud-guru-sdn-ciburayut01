<?php
require_once __DIR__ . '/../auth/auth.php';
wajib_login(); wajib_role('Admin');
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/../config/database.php';
header('Content-Type: application/json; charset=utf-8');
try {
$pdo->exec("CREATE TABLE IF NOT EXISTS website_builder_settings (id INT AUTO_INCREMENT PRIMARY KEY, setting_key VARCHAR(100) NOT NULL UNIQUE, setting_value TEXT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$defaults=[
'site_name'=>'SDN CIBURAYUT 01','tagline'=>'Portal Informasi Sekolah','logo_url'=>'','favicon_url'=>'','hero_image'=>'','address'=>'Cigombong, Kabupaten Bogor','phone'=>'','email'=>'info@sdnciburayut01.com','whatsapp'=>'','facebook_url'=>'','instagram_url'=>'','youtube_url'=>'','maps_embed_url'=>'','maps_link'=>'','footer_text'=>'© '.date('Y').' SDN Ciburayut 01. Semua hak dilindungi.','primary_color'=>'#1565c0','seo_title'=>'','seo_description'=>'Portal resmi SDN Ciburayut 01. Informasi sekolah, berita, agenda, profil guru, galeri, dan layanan digital.','seo_keywords'=>'SDN Ciburayut 01, sekolah dasar, Ciburayut, Cigombong, Bogor, portal sekolah','seo_author'=>'SDN Ciburayut 01','seo_og_image'=>'','seo_canonical'=>'','seo_robots'=>'index,follow','header_height'=>'78','header_sticky'=>'1','header_transparent'=>'0','header_bg'=>'#ffffff','header_overlay'=>'0','header_logo_width'=>'46','header_align'=>'between','hero_overlay'=>'0','hero_height'=>'520','hero_align'=>'left','hero_eyebrow'=>'PORTAL INFORMASI SEKOLAH','hero_title'=>'Selamat Datang di SDN Ciburayut 01','hero_subtitle'=>'Portal resmi sekolah untuk informasi, kegiatan, profil guru, dan layanan digital.','hero_button_text'=>'Jelajahi Portal →','hero_button_url'=>'/?page=informasi','hero_button2_text'=>'Profil Sekolah','hero_button2_url'=>'/?page=profil','hero_text_color'=>'#ffffff','hero_position'=>'center','hero_animation'=>'fade','footer_layout'=>'3','footer_bg'=>'#102a43','footer_text_color'=>'#ffffff','footer_show_logo'=>'1','footer_show_quicklinks'=>'1','footer_show_contact'=>'1','footer_show_social'=>'1','footer_quicklinks'=>'Beranda|/?page=home\nProfil Sekolah|/?page=profil\nInformasi|/?page=informasi\nProfil Guru|/?page=guru\nGaleri|/?page=galeri'
];
if($_SERVER['REQUEST_METHOD']==='POST'){ csrf_require(); }
if($_SERVER['REQUEST_METHOD']==='POST'){
 $data=json_decode(file_get_contents('php://input'),true) ?: [];
 foreach($defaults as $k=>$v){ if(array_key_exists($k,$data)){ $val=trim((string)$data[$k]); if($k==='primary_color' && !preg_match('/^#[0-9a-fA-F]{6}$/',$val)) $val=$v; if(strlen($val)>500) $val=substr($val,0,500); $st=$pdo->prepare("INSERT INTO website_builder_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)"); $st->execute([$k,$val]); }}
 echo json_encode(['ok'=>true]); exit;
}
$out=$defaults; $q=$pdo->query("SELECT setting_key,setting_value FROM website_builder_settings"); foreach($q as $r){if(array_key_exists($r['setting_key'],$out))$out[$r['setting_key']]=$r['setting_value'];}
if(trim((string)$out['footer_quicklinks'])==='')$out['footer_quicklinks']=$defaults['footer_quicklinks'];
if(trim((string)$out['footer_text'])==='')$out['footer_text']=$defaults['footer_text'];
echo json_encode(['ok'=>true,'settings'=>$out]);
} catch(Throwable $e){http_response_code(500);echo json_encode(['ok'=>false,'message'=>'Gagal memuat pengaturan']);}
