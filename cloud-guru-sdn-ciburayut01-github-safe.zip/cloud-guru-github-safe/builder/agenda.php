<?php
require_once __DIR__ . '/../auth/auth.php';
wajib_login(); wajib_role('Admin');
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/../config/database.php';
header('Content-Type: text/html; charset=utf-8');

$pdo->exec("CREATE TABLE IF NOT EXISTS website_builder_agenda (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(220) NOT NULL,
 category VARCHAR(80) NOT NULL DEFAULT 'Kegiatan Sekolah',
 event_date DATE NOT NULL,
 start_time TIME NULL,
 end_time TIME NULL,
 location VARCHAR(220) NULL,
 description TEXT NULL,
 status ENUM('draft','published') NOT NULL DEFAULT 'draft',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_agenda_date_status (event_date,status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){ csrf_require(); }
if($_SERVER['REQUEST_METHOD']==='POST'){
 $action=$_POST['action']??''; $id=(int)($_POST['id']??0);
 try{
  if($action==='save'){
   $title=trim($_POST['title']??''); $date=trim($_POST['event_date']??'');
   if($title==='') throw new Exception('Nama kegiatan wajib diisi.');
   if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)) throw new Exception('Tanggal kegiatan belum valid.');
   $status=($_POST['status']??'draft')==='published'?'published':'draft';
   $data=[$title,trim($_POST['category']??'Kegiatan Sekolah'),$date,trim($_POST['start_time']??'')?:null,trim($_POST['end_time']??'')?:null,trim($_POST['location']??''),trim($_POST['description']??''),$status];
   if($id){
    $q=$pdo->prepare('UPDATE website_builder_agenda SET title=?,category=?,event_date=?,start_time=?,end_time=?,location=?,description=?,status=? WHERE id=?');
    $q->execute([...$data,$id]);
   }else{
    $q=$pdo->prepare('INSERT INTO website_builder_agenda(title,category,event_date,start_time,end_time,location,description,status) VALUES(?,?,?,?,?,?,?,?)');
    $q->execute($data);
   }
   header('Location: /builder/agenda.php?saved=1'); exit;
  }
  if($action==='delete' && $id){$q=$pdo->prepare('DELETE FROM website_builder_agenda WHERE id=?');$q->execute([$id]);header('Location: /builder/agenda.php?deleted=1');exit;}
  if($action==='toggle' && $id){$q=$pdo->prepare("UPDATE website_builder_agenda SET status=IF(status='published','draft','published') WHERE id=?");$q->execute([$id]);header('Location: /builder/agenda.php');exit;}
 }catch(Throwable $e){$err=$e->getMessage();}
}
$edit=null;
if(isset($_GET['edit'])){$q=$pdo->prepare('SELECT * FROM website_builder_agenda WHERE id=?');$q->execute([(int)$_GET['edit']]);$edit=$q->fetch();}
$rows=$pdo->query("SELECT * FROM website_builder_agenda ORDER BY event_date ASC, start_time ASC, id DESC")->fetchAll();
function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function timeLabel($v){return $v?date('H:i',strtotime($v)):'';}
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Agenda Sekolah — Cloud Guru</title>
<style>
body{font-family:Inter,system-ui,sans-serif;background:#f4f7fb;margin:0;color:#16324a}.wrap{max-width:1120px;margin:30px auto;padding:0 18px}.top{display:flex;justify-content:space-between;align-items:center;gap:15px}.card{background:#fff;border:1px solid #e5ebf2;border-radius:18px;padding:20px;margin:18px 0;box-shadow:0 8px 30px #16324a0a}label{display:block;font-weight:700;font-size:13px;margin:12px 0}input,textarea,select{width:100%;box-sizing:border-box;margin-top:6px;border:1px solid #d9e2ec;border-radius:10px;padding:11px;font:inherit}textarea{min-height:110px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}button,.btn{border:0;border-radius:10px;padding:10px 14px;font-weight:800;cursor:pointer;text-decoration:none;display:inline-block}.save{background:#1565c0;color:#fff}.muted{background:#eef3f8;color:#234}.danger{background:#fee2e2;color:#991b1b}.agenda-row{display:grid;grid-template-columns:78px 1fr auto;gap:16px;align-items:center;padding:15px 0;border-bottom:1px solid #edf1f5}.datebox{border-radius:14px;background:#edf5ff;text-align:center;padding:10px 5px;color:#1565c0}.datebox b{display:block;font-size:24px;line-height:1}.datebox small{font-size:10px;font-weight:800;text-transform:uppercase}.badge{font-size:11px;font-weight:800;padding:5px 8px;border-radius:20px;background:#e8f5e9;color:#176b2c}.draft{background:#fff3cd;color:#805d00}.actions{display:flex;gap:6px;flex-wrap:wrap}.meta{font-size:12px;color:#718096;margin-top:6px}.notice{padding:11px 14px;border-radius:12px;background:#ecfdf5;color:#166534}.err{padding:11px 14px;border-radius:12px;background:#fff1f2;color:#9f1239}@media(max-width:700px){.grid{grid-template-columns:1fr}.agenda-row{grid-template-columns:64px 1fr}.agenda-row .actions{grid-column:1/-1}.datebox{padding:8px 4px}.datebox b{font-size:20px}}
</style></head><body><div class="wrap">
<div class="top"><div><h1>📅 Agenda Sekolah</h1><p>Kelola kegiatan sekolah yang tampil otomatis di website publik.</p></div><a class="btn muted" href="/builder/">← Kembali ke Builder</a></div>
<?php if(isset($_GET['saved'])):?><div class="notice">✓ Agenda berhasil disimpan.</div><?php endif;?>
<?php if(isset($_GET['deleted'])):?><div class="notice">✓ Agenda berhasil dihapus.</div><?php endif;?>
<?php if($err):?><div class="err">⚠️ <?=h($err)?></div><?php endif;?>
<div class="card"><h2><?= $edit?'✏️ Edit Agenda':'➕ Tambah Agenda'?></h2><form method="post"><input type="hidden" name="_csrf" value="<?=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8')?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=h($edit['id']??0)?>">
<div class="grid"><label>Nama Kegiatan<input required name="title" value="<?=h($edit['title']??'')?>" placeholder="Contoh: Upacara Hari Senin"></label><label>Kategori<input name="category" value="<?=h($edit['category']??'Kegiatan Sekolah')?>"></label>
<label>Tanggal<input required type="date" name="event_date" value="<?=h($edit['event_date']??date('Y-m-d'))?>"></label><label>Status<select name="status"><option value="draft" <?=($edit['status']??'draft')==='draft'?'selected':''?>>Draft</option><option value="published" <?=($edit['status']??'')==='published'?'selected':''?>>Published</option></select></label>
<label>Jam Mulai<input type="time" name="start_time" value="<?=h($edit['start_time']??'')?>"></label><label>Jam Selesai<input type="time" name="end_time" value="<?=h($edit['end_time']??'')?>"></label>
<label>Lokasi<input name="location" value="<?=h($edit['location']??'')?>" placeholder="Contoh: Lapangan sekolah"></label></div>
<label>Deskripsi<textarea name="description" placeholder="Keterangan kegiatan..."> <?=h($edit['description']??'')?></textarea></label>
<button class="save">💾 Simpan Agenda</button> <?php if($edit):?><a class="btn muted" href="/builder/agenda.php">Batal</a><?php endif;?></form></div>
<div class="card"><h2>📋 Daftar Agenda</h2><?php if(!$rows):?><p>Belum ada agenda. Tambahkan kegiatan pertama di atas.</p><?php endif;?>
<?php foreach($rows as $r):?><div class="agenda-row"><div class="datebox"><b><?=date('d',strtotime($r['event_date']))?></b><small><?=date('M Y',strtotime($r['event_date']))?></small></div><div><b><?=h($r['title'])?></b><div class="meta">🏷️ <?=h($r['category'])?><?php if($r['start_time']):?> · ⏰ <?=h(timeLabel($r['start_time']))?><?= $r['end_time']?'–'.h(timeLabel($r['end_time'])):''?><?php endif;?><?php if($r['location']):?> · 📍 <?=h($r['location'])?><?php endif;?> · <span class="badge <?= $r['status']==='draft'?'draft':''?>"><?=h($r['status'])?></span></div><?php if($r['description']):?><div class="meta"><?=h(mb_strimwidth($r['description'],0,150,'…'))?></div><?php endif;?></div><div class="actions"><a class="btn muted" href="/builder/agenda.php?edit=<?=$r['id']?>">✏️ Edit</a><form method="post"><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn muted"><?= $r['status']==='published'?'↘ Draft':'🟢 Publish'?></button></form><form method="post" onsubmit="return confirm('Hapus agenda ini?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="danger">🗑️</button></form></div></div><?php endforeach;?></div>
</div></body></html>
