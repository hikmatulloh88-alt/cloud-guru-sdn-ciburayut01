<?php
declare(strict_types=1);

require_once __DIR__ . '/../auth/auth.php';
wajib_login();
wajib_role('Admin');

require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json; charset=utf-8');

function json_response(array $data, int $status = 200): never
{
    http_response_code($status);
    echo json_encode(
        $data,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
    exit;
}

try {

    $pageSlug = strtolower(
        trim((string)($_GET['page_slug'] ?? 'home'))
    );

    if (!preg_match('/^[a-z0-9-]{1,120}$/', $pageSlug)) {
        $pageSlug = 'home';
    }

    /*
     * Pastikan tabel draft tersedia.
     */
    $check = $pdo->prepare("
        SELECT COUNT(*)
        FROM information_schema.tables
        WHERE table_schema = DATABASE()
          AND table_name = 'website_builder_drafts'
    ");
    $check->execute();

    if ((int)$check->fetchColumn() === 0) {
        json_response([
            'ok' => true,
            'draft' => null,
            'page_slug' => $pageSlug,
            'message' => 'Draft belum tersedia.'
        ]);
    }

    /*
     * PENTING:
     * Gunakan prepare() + execute().
     * Jangan menggunakan query() lalu execute().
     */
    $stmt = $pdo->prepare("
        SELECT content, updated_at
        FROM website_builder_drafts
        WHERE page_slug = ?
        LIMIT 1
    ");

    $stmt->execute([$pageSlug]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        json_response([
            'ok' => true,
            'draft' => null,
            'page_slug' => $pageSlug
        ]);
    }

    json_response([
        'ok' => true,
        'page_slug' => $pageSlug,
        'draft' => [
            'html' => (string)($row['content'] ?? ''),
            'updated_at' => !empty($row['updated_at'])
                ? (string)$row['updated_at']
                : null
        ]
    ]);

} catch (PDOException $e) {

    json_response([
        'ok' => false,
        'draft' => null,
        'error' => 'Gagal mengambil draft dari database.'
    ], 500);

} catch (Throwable $e) {

    json_response([
        'ok' => false,
        'draft' => null,
        'error' => 'Gagal memuat draft.'
    ], 500);
}