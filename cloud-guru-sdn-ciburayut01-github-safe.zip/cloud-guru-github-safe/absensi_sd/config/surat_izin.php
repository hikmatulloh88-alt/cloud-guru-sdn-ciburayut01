<?php
/* Helper bersama untuk fitur Surat Izin/Sakit Siswa.
   Dipakai oleh Portal Siswa (pengajuan) dan halaman Admin/Guru (persetujuan). */

function surat_izin_bootstrap($koneksi) {
    mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS surat_izin (
        id_surat INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        id_siswa INT UNSIGNED NOT NULL,
        tanggal_izin DATE NOT NULL,
        jenis ENUM('Sakit','Izin') NOT NULL DEFAULT 'Sakit',
        keterangan VARCHAR(255) NULL,
        file_surat VARCHAR(255) NULL,
        status ENUM('Menunggu','Disetujui','Ditolak') NOT NULL DEFAULT 'Menunggu',
        catatan_admin VARCHAR(255) NULL,
        diproses_oleh VARCHAR(150) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY idx_surat_siswa (id_siswa),
        KEY idx_surat_status (status),
        CONSTRAINT fk_surat_siswa FOREIGN KEY (id_siswa) REFERENCES siswa(id_siswa) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

/**
 * Terapkan surat izin/sakit yang disetujui ke tabel absensi_siswa pada tanggal terkait.
 * Memakai kelas siswa saat ini & tahun ajaran aktif. Aman dipanggil berkali-kali
 * (memakai ON DUPLICATE KEY UPDATE sesuai unique key id_siswa+tanggal+id_tahun_ajaran).
 */
function surat_izin_terapkan_ke_absensi($koneksi, $id_siswa, $tanggal, $jenis, $keterangan) {
    $q = mysqli_prepare($koneksi, "SELECT id_kelas FROM siswa WHERE id_siswa = ? LIMIT 1");
    if (!$q) { return false; }
    mysqli_stmt_bind_param($q, 'i', $id_siswa);
    mysqli_stmt_execute($q);
    $res = mysqli_stmt_get_result($q);
    $row = $res ? mysqli_fetch_assoc($res) : null;
    $id_kelas = $row ? (int)$row['id_kelas'] : 0;
    if ($id_kelas <= 0) { return false; }

    $qt = mysqli_query($koneksi, "SELECT id_tahun_ajaran FROM tahun_ajaran ORDER BY aktif DESC, id_tahun_ajaran DESC LIMIT 1");
    $ta = $qt ? mysqli_fetch_assoc($qt) : null;
    $id_tahun_ajaran = $ta ? (int)$ta['id_tahun_ajaran'] : 0;
    if ($id_tahun_ajaran <= 0) { return false; }

    $stmt = mysqli_prepare(
        $koneksi,
        "INSERT INTO absensi_siswa (id_siswa, id_kelas, id_tahun_ajaran, tanggal, status, keterangan)
         VALUES (?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE status = VALUES(status), keterangan = VALUES(keterangan)"
    );
    if (!$stmt) { return false; }
    mysqli_stmt_bind_param($stmt, 'iiisss', $id_siswa, $id_kelas, $id_tahun_ajaran, $tanggal, $jenis, $keterangan);
    return mysqli_stmt_execute($stmt);
}
