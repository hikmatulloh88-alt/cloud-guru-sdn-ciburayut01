<?php
/**
 * Pembatasan akses Guru berdasarkan kelas yang menjadi wali kelasnya.
 * Admin/Operator tidak dibatasi oleh helper ini.
 */
if (session_status() === PHP_SESSION_NONE) { session_start(); }

function guru_access_aktif(): bool {
    $role = strtolower(trim((string)($_SESSION['role'] ?? '')));
    return in_array($role, ['guru','teacher'], true);
}

function guru_id_login(): int {
    return (int)($_SESSION['id_guru'] ?? 0);
}

function guru_kelas_ids(mysqli $db): array {
    static $cache = null;
    if ($cache !== null) return $cache;
    $cache = [];
    if (!guru_access_aktif()) return $cache;
    $id_guru = guru_id_login();
    if ($id_guru <= 0) return $cache;
    $st = mysqli_prepare($db, "SELECT id_kelas FROM kelas WHERE id_wali_kelas = ? ORDER BY tingkat, nama_kelas");
    if (!$st) return $cache;
    mysqli_stmt_bind_param($st, 'i', $id_guru);
    mysqli_stmt_execute($st);
    $rs = mysqli_stmt_get_result($st);
    if ($rs) while ($r = mysqli_fetch_assoc($rs)) $cache[] = (int)$r['id_kelas'];
    mysqli_stmt_close($st);
    return $cache;
}

function guru_boleh_kelas(mysqli $db, int $id_kelas): bool {
    if (!guru_access_aktif()) return true;
    if ($id_kelas <= 0) return false;
    return in_array($id_kelas, guru_kelas_ids($db), true);
}

function guru_boleh_siswa(mysqli $db, int $id_siswa): bool {
    if (!guru_access_aktif()) return true;
    if ($id_siswa <= 0) return false;
    $st = mysqli_prepare($db, "SELECT id_kelas FROM siswa WHERE id_siswa = ? LIMIT 1");
    if (!$st) return false;
    mysqli_stmt_bind_param($st, 'i', $id_siswa);
    mysqli_stmt_execute($st);
    $rs = mysqli_stmt_get_result($st);
    $r = $rs ? mysqli_fetch_assoc($rs) : null;
    mysqli_stmt_close($st);
    return $r && guru_boleh_kelas($db, (int)$r['id_kelas']);
}

function guru_boleh_absensi(mysqli $db, int $id_absensi, string $primary_key): bool {
    if (!guru_access_aktif()) return true;
    $allowed_keys = ['id_absensi_siswa','id_absensi','id'];
    if (!in_array($primary_key, $allowed_keys, true) || $id_absensi <= 0) return false;
    $st = mysqli_prepare($db, "SELECT s.id_kelas FROM absensi_siswa a INNER JOIN siswa s ON s.id_siswa=a.id_siswa WHERE a.`$primary_key`=? LIMIT 1");
    if (!$st) return false;
    mysqli_stmt_bind_param($st, 'i', $id_absensi);
    mysqli_stmt_execute($st);
    $rs = mysqli_stmt_get_result($st);
    $r = $rs ? mysqli_fetch_assoc($rs) : null;
    mysqli_stmt_close($st);
    return $r && guru_boleh_kelas($db, (int)$r['id_kelas']);
}

function guru_scope_sql(mysqli $db, string $alias='s', string $field='id_kelas'): string {
    if (!guru_access_aktif()) return '';
    $ids = guru_kelas_ids($db);
    if (!$ids) return ' AND 1=0';
    return ' AND '.$alias.'.'.$field.' IN ('.implode(',', array_map('intval', $ids)).')';
}

function guru_wajib_kelas(mysqli $db, int $id_kelas): void {
    if (guru_access_aktif() && !guru_boleh_kelas($db, $id_kelas)) {
        http_response_code(403);
        exit('Akses ditolak: akun Guru hanya dapat mengakses kelas yang menjadi tanggung jawabnya.');
    }
}

function guru_wajib_siswa(mysqli $db, int $id_siswa): void {
    if (guru_access_aktif() && !guru_boleh_siswa($db, $id_siswa)) {
        http_response_code(403);
        exit('Akses ditolak: siswa tersebut bukan bagian dari kelas Anda.');
    }
}
