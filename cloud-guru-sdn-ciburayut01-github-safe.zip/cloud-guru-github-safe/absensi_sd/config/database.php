<?php

$host = 'localhost';
$user = 'USER_DATABASE_ABSENSI';
$password = 'ISI_PASSWORD_DATABASE_DI_SERVER';
$database = 'NAMA_DATABASE_ABSENSI';

$koneksi = mysqli_connect($host, $user, $password, $database);

if (!$koneksi) {
    die('Koneksi database gagal.');
}

mysqli_set_charset($koneksi, 'utf8mb4');

// Jangan menjalankan migrasi/schema bootstrap otomatis pada repository.
// File schema_bootstrap.php tetap tersedia sebagai source, tetapi dipanggil
// hanya saat deployment yang memang membutuhkan.
