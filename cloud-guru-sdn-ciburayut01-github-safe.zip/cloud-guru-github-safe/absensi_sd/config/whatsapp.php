<?php
/**
 * WhatsApp otomatis untuk notifikasi ALPA.
 * Provider: Fonnte API.
 * Token TIDAK disimpan di file ini; simpan melalui menu Pengaturan WhatsApp.
 */
if (!function_exists('wa_alpa_init')) {
    function wa_alpa_init(mysqli $db): void {
        static $done = false;
        if ($done) return;
        $done = true;
        mysqli_query($db, "CREATE TABLE IF NOT EXISTS whatsapp_settings (
            id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
            provider VARCHAR(30) NOT NULL DEFAULT 'fonnte',
            api_token TEXT NULL,
            enabled TINYINT(1) NOT NULL DEFAULT 0,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        mysqli_query($db, "INSERT IGNORE INTO whatsapp_settings (id,provider,enabled) VALUES (1,'fonnte',0)");
        mysqli_query($db, "CREATE TABLE IF NOT EXISTS whatsapp_notifikasi (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            id_siswa INT UNSIGNED NOT NULL,
            tanggal DATE NOT NULL,
            jenis VARCHAR(30) NOT NULL DEFAULT 'ALPA',
            target VARCHAR(30) NULL,
            pesan TEXT NULL,
            status ENUM('Menunggu','Terkirim','Gagal','Tidak Aktif','Tanpa Nomor') NOT NULL DEFAULT 'Menunggu',
            response_api TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uk_wa_siswa_tanggal_jenis (id_siswa,tanggal,jenis),
            KEY idx_wa_status (status), KEY idx_wa_tanggal (tanggal)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
}

if (!function_exists('wa_alpa_settings')) {
    function wa_alpa_settings(mysqli $db): array {
        wa_alpa_init($db);
        $r = mysqli_query($db, "SELECT * FROM whatsapp_settings WHERE id=1 LIMIT 1");
        return $r ? (mysqli_fetch_assoc($r) ?: []) : [];
    }
}

if (!function_exists('wa_normalize_target')) {
    function wa_normalize_target(string $number): string {
        $n = preg_replace('/[^0-9+]/', '', trim($number));
        if ($n === '') return '';
        if (strpos($n, '+') === 0) $n = substr($n, 1);
        if (strpos($n, '00') === 0) $n = substr($n, 2);
        if (strpos($n, '0') === 0) $n = '62' . substr($n, 1);
        return preg_match('/^62[0-9]{8,15}$/', $n) ? $n : '';
    }
}

if (!function_exists('wa_kirim_fonnte')) {
    function wa_kirim_fonnte(string $token, string $target, string $message): array {
        if (!function_exists('curl_init')) return ['ok'=>false,'response'=>'cURL PHP tidak tersedia di server.'];
        $ch = curl_init('https://api.fonnte.com/send');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => [
                'target' => $target,
                'message' => $message,
                'countryCode' => '62'
            ],
            CURLOPT_HTTPHEADER => ['Authorization: ' . $token],
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CONNECTTIMEOUT => 10,
        ]);
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($response === false) return ['ok'=>false,'response'=>$error ?: 'Gagal terhubung ke API WhatsApp.','http_code'=>$code];
        $json = json_decode($response, true);
        $ok = is_array($json) && !empty($json['status']);
        return ['ok'=>$ok,'response'=>$response,'http_code'=>$code];
    }
}

if (!function_exists('wa_kirim_notifikasi_alpa')) {
    function wa_kirim_notifikasi_alpa(mysqli $db, int $id_siswa, string $tanggal, bool $force = false): array {
        wa_alpa_init($db);
        $settings = wa_alpa_settings($db);
        $q = mysqli_prepare($db, "SELECT s.nama_siswa,s.no_wa_aktif,s.nis,s.nisn,k.nama_kelas FROM siswa s LEFT JOIN kelas k ON k.id_kelas=s.id_kelas WHERE s.id_siswa=? LIMIT 1");
        if (!$q) return ['ok'=>false,'status'=>'Gagal','message'=>'Data siswa tidak dapat dibaca.'];
        mysqli_stmt_bind_param($q,'i',$id_siswa); mysqli_stmt_execute($q);
        $r = mysqli_stmt_get_result($q); $s = $r ? mysqli_fetch_assoc($r) : null;
        if (!$s) return ['ok'=>false,'status'=>'Gagal','message'=>'Siswa tidak ditemukan.'];

        $target = wa_normalize_target((string)($s['no_wa_aktif'] ?? ''));
        if ($target === '') {
            $msg = 'Nomor WhatsApp aktif belum diisi atau formatnya tidak valid.';
            $st = mysqli_prepare($db, "INSERT INTO whatsapp_notifikasi (id_siswa,tanggal,jenis,target,status,response_api) VALUES (?,?, 'ALPA',NULL,'Tanpa Nomor',?) ON DUPLICATE KEY UPDATE target=NULL,status='Tanpa Nomor',response_api=VALUES(response_api)");
            if ($st) { mysqli_stmt_bind_param($st,'iss',$id_siswa,$tanggal,$msg); mysqli_stmt_execute($st); }
            return ['ok'=>false,'status'=>'Tanpa Nomor','message'=>$msg];
        }
        if (empty($settings['enabled'])) {
            return ['ok'=>false,'status'=>'Tidak Aktif','message'=>'Notifikasi WhatsApp belum diaktifkan.'];
        }
        $token = trim((string)($settings['api_token'] ?? ''));
        if ($token === '') return ['ok'=>false,'status'=>'Tidak Aktif','message'=>'Token WhatsApp belum diisi.'];

        $cek = mysqli_prepare($db, "SELECT id,status FROM whatsapp_notifikasi WHERE id_siswa=? AND tanggal=? AND jenis='ALPA' LIMIT 1");
        if ($cek) {
            mysqli_stmt_bind_param($cek,'is',$id_siswa,$tanggal); mysqli_stmt_execute($cek);
            $cr = mysqli_stmt_get_result($cek); $old = $cr ? mysqli_fetch_assoc($cr) : null;
            if ($old && !$force && $old['status'] === 'Terkirim') return ['ok'=>true,'status'=>'Terkirim','message'=>'Notifikasi ALPA sudah pernah dikirim.','duplicate'=>true];
        }

        $nama = trim((string)$s['nama_siswa']);
        $kelas = trim((string)($s['nama_kelas'] ?? '-')) ?: '-';
        $tgl = date('d-m-Y', strtotime($tanggal));
        $message = "🔔 NOTIFIKASI KEHADIRAN SISWA\n\nYth. Bapak/Ibu Orang Tua/Wali Siswa\n\nNama Siswa : {$nama}\nKelas : {$kelas}\nTanggal : {$tgl}\nStatus : ALPA (Tidak Hadir Tanpa Keterangan)\n\nMohon perhatian Bapak/Ibu. Silakan menghubungi pihak sekolah apabila terdapat informasi/keterangan terkait ketidakhadiran siswa.\n\nTerima kasih.\nSDN CIBURAYUT 01";

        $sent = wa_kirim_fonnte($token,$target,$message);
        $status = $sent['ok'] ? 'Terkirim' : 'Gagal';
        $resp = substr((string)($sent['response'] ?? ''),0,6000);
        $sql = "INSERT INTO whatsapp_notifikasi (id_siswa,tanggal,jenis,target,pesan,status,response_api) VALUES (?,?, 'ALPA',?,?,?,?) ON DUPLICATE KEY UPDATE target=VALUES(target),pesan=VALUES(pesan),status=VALUES(status),response_api=VALUES(response_api)";
        $st = mysqli_prepare($db,$sql);
        if ($st) { mysqli_stmt_bind_param($st,'isssss',$id_siswa,$tanggal,$target,$message,$status,$resp); mysqli_stmt_execute($st); }
        return ['ok'=>$sent['ok'],'status'=>$status,'message'=>$sent['ok']?'Notifikasi ALPA berhasil dikirim ke WhatsApp.':'Pengiriman WhatsApp gagal: '.($resp ?: 'tidak ada respons API.'),'target'=>$target,'response'=>$resp];
    }
}
