<?php
require_once __DIR__ . '/../../config/auth.php';
wajib_login();
wajib_role('Admin');
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/whatsapp.php';
$menu_aktif='pengaturan';
$page_title='Pengaturan WhatsApp - SDN Ciburayut 01';
function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
wa_alpa_init($koneksi);
$msg='';$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $aksi=$_POST['aksi']??'';
  if($aksi==='simpan'){
    $enabled=isset($_POST['enabled'])?1:0;
    $token=trim((string)($_POST['api_token']??''));
    if($token===''){
      $old=wa_alpa_settings($koneksi); $token=(string)($old['api_token']??'');
    }
    $st=mysqli_prepare($koneksi,"UPDATE whatsapp_settings SET enabled=?,api_token=?,provider='fonnte' WHERE id=1");
    if($st){mysqli_stmt_bind_param($st,'is',$enabled,$token);if(mysqli_stmt_execute($st))$msg='Pengaturan WhatsApp berhasil disimpan.';else $err='Gagal menyimpan pengaturan.';}
  }
  if($aksi==='test'){
    $target=wa_normalize_target((string)($_POST['target']??''));
    $settings=wa_alpa_settings($koneksi);
    if($target==='')$err='Nomor tujuan tidak valid.';
    elseif(empty($settings['api_token']))$err='Token Fonnte belum diisi.';
    else{
      $res=wa_kirim_fonnte((string)$settings['api_token'],$target,"✅ Tes WhatsApp SDN CIBURAYUT 01\n\nNotifikasi WhatsApp dari aplikasi Absensi berhasil terhubung.\n\nJika pesan ini diterima, sistem siap digunakan untuk notifikasi ALPA.");
      if($res['ok'])$msg='Pesan uji berhasil dikirim.';else $err='Pesan uji gagal dikirim: '.substr((string)($res['response']??''),0,500);
    }
  }
}
$settings=wa_alpa_settings($koneksi);$token=(string)($settings['api_token']??'');$masked=$token!==''?substr($token,0,4).'••••••••'.substr($token,-4):'';
require_once __DIR__ . '/../../includes/header.php';require_once __DIR__ . '/../../includes/sidebar.php';
?>
<main class="main-content"><div style="max-width:950px">
<h1 style="margin:0 0 6px">📱 Pengaturan WhatsApp</h1><p style="color:#64748b;margin-top:0">Hubungkan aplikasi absensi dengan WhatsApp Gateway agar orang tua menerima notifikasi ALPA secara otomatis.</p>
<?php if($msg):?><div style="background:#ecfdf5;color:#166534;border:1px solid #bbf7d0;padding:12px 15px;border-radius:12px;margin:15px 0">✅ <?=h($msg)?></div><?php endif;?>
<?php if($err):?><div style="background:#fff1f2;color:#be123c;border:1px solid #fecdd3;padding:12px 15px;border-radius:12px;margin:15px 0">⚠️ <?=h($err)?></div><?php endif;?>
<div style="background:#fff;border-radius:18px;padding:22px;box-shadow:0 8px 25px rgba(15,35,70,.07);margin-top:18px">
<h3 style="margin-top:0">⚙️ Koneksi WhatsApp Gateway</h3>
<form method="post"><input type="hidden" name="aksi" value="simpan">
<label style="display:flex;align-items:center;gap:10px;font-weight:700;margin-bottom:18px"><input type="checkbox" name="enabled" value="1" <?=$settings['enabled']?'checked':''?>> Aktifkan notifikasi WhatsApp otomatis</label>
<label style="display:block;font-weight:700;margin-bottom:7px">Provider</label><input value="Fonnte API" disabled style="width:100%;box-sizing:border-box;padding:11px;border:1px solid #dbe3ef;border-radius:10px;background:#f8fafc">
<label style="display:block;font-weight:700;margin:16px 0 7px">Token API Fonnte</label><input type="password" name="api_token" value="" placeholder="<?=h($masked ?: 'Masukkan token API Fonnte')?>" autocomplete="off" style="width:100%;box-sizing:border-box;padding:11px;border:1px solid #dbe3ef;border-radius:10px"><div style="font-size:12px;color:#64748b;margin-top:7px">Token lama tidak ditampilkan penuh. Kosongkan jika ingin mempertahankan token yang sudah tersimpan.</div>
<div style="margin-top:18px"><button style="border:0;background:#2563eb;color:#fff;padding:11px 18px;border-radius:10px;font-weight:700;cursor:pointer">💾 Simpan Pengaturan</button></div>
</form></div>
<div style="background:#fff;border-radius:18px;padding:22px;box-shadow:0 8px 25px rgba(15,35,70,.07);margin-top:18px">
<h3 style="margin-top:0">🧪 Tes Kirim WhatsApp</h3><p style="color:#64748b">Masukkan nomor WhatsApp tujuan untuk memastikan gateway sudah tersambung.</p>
<form method="post" style="display:flex;gap:10px;flex-wrap:wrap"><input type="hidden" name="aksi" value="test"><input name="target" placeholder="Contoh: 081234567890" style="flex:1;min-width:240px;padding:11px;border:1px solid #dbe3ef;border-radius:10px"><button style="border:0;background:#16a34a;color:#fff;padding:11px 18px;border-radius:10px;font-weight:700;cursor:pointer">📤 Kirim Pesan Uji</button></form></div>
<div style="background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af;border-radius:14px;padding:15px;margin-top:18px"><b>Alur otomatis:</b><br>Profil Siswa menyimpan satu Nomor WhatsApp Aktif → guru/operator menetapkan status <b>Alpa</b> → sistem mengambil nomor tersebut → sistem mengirim notifikasi WhatsApp → hasil pengiriman dicatat agar tidak mengirim duplikat pada tanggal yang sama.</div>
</div></main>
