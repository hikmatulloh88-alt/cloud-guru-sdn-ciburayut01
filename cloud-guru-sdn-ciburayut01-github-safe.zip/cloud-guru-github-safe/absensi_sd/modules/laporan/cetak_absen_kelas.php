<?php
session_start();
require_once __DIR__ . '/../../config/database.php';

if (empty($_SESSION['login_user']) && empty($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit;
}

function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$db = $koneksi ?? $conn ?? null;
if (!$db) die('Koneksi database tidak tersedia.');

function q($sql){
    global $db;
    return @mysqli_query($db, $sql);
}
function first_col($cols, $names){
    foreach($names as $n) if(isset($cols[$n])) return $n;
    return null;
}
function table_columns($table){
    $cols=[];
    $r=q("SHOW COLUMNS FROM `".str_replace('`','',$table)."`");
    if($r) while($x=mysqli_fetch_assoc($r)) $cols[$x['Field']]=true;
    return $cols;
}

/* Deteksi tabel siswa/kelas/absensi tanpa mengikat ke satu nama tabel. */
$tables=[];
$r=q("SHOW TABLES");
if($r) while($x=mysqli_fetch_row($r)) $tables[]=$x[0];

$student_table=null; $class_table=null; $att_table=null;
foreach($tables as $t){
    $low=strtolower($t);
    if(!$student_table && preg_match('/^(siswa|students|data_siswa|student)$/',$low)) $student_table=$t;
    if(!$class_table && preg_match('/^(kelas|classes|data_kelas|rombel)$/',$low)) $class_table=$t;
    if(!$att_table && preg_match('/(absen|attendance|kehadiran)/',$low)) $att_table=$t;
}

$student_rows=[];
$class_rows=[];
$att_cols=$att_table ? table_columns($att_table) : [];

if($student_table){
    $c=table_columns($student_table);
    $id=first_col($c,['id_siswa','id_student','id']);
    $name=first_col($c,['nama_siswa','nama','name','nama_lengkap']);
    $nisn=first_col($c,['nisn','nis']);
    $gender=first_col($c,['jk','jenis_kelamin','gender','lp']);
    $class=first_col($c,['id_kelas','kelas_id','rombel_id','kelas','rombel']);
    if($name){
        $select=[];
        if($id) $select[]="`$id` AS sid";
        if($name) $select[]="`$name` AS nama";
        if($nisn) $select[]="`$nisn` AS nisn";
        if($gender) $select[]="`$gender` AS jk";
        if($class) $select[]="`$class` AS kelas_ref";
        $sql="SELECT ".implode(',',$select)." FROM `$student_table` ORDER BY `$name`";
        if($rr=q($sql)) while($row=mysqli_fetch_assoc($rr)) $student_rows[]=$row;
    }
}

if($class_table){
    $c=table_columns($class_table);
    $id=first_col($c,['id_kelas','id_class','id']);
    $name=first_col($c,['nama_kelas','kelas','nama','name','rombel']);
    if($name){
        $select=[];
        if($id) $select[]="`$id` AS cid";
        $select[]="`$name` AS nama_kelas";
        $class_sql="SELECT ".implode(',',$select)." FROM `$class_table`";
        if (guru_access_aktif()) { $ids=guru_kelas_ids($db); $class_sql .= $ids ? " WHERE `$id` IN (".implode(',',array_map('intval',$ids)).")" : " WHERE 1=0"; }
        $class_sql .= " ORDER BY `$name`";
        if($rr=q($class_sql)) while($row=mysqli_fetch_assoc($rr)) $class_rows[]=$row;
    }
}

$selected_class=trim($_GET['kelas'] ?? '');
if (guru_access_aktif() && $selected_class !== '') guru_wajib_kelas($db, (int)$selected_class);
if (guru_access_aktif() && $selected_class === '') { $ids=guru_kelas_ids($db); if($ids) $selected_class=(string)$ids[0]; else $selected_class='-1'; }
$month=(int)($_GET['bulan'] ?? date('n'));
$year=(int)($_GET['tahun'] ?? date('Y'));
if($month<1 || $month>12) $month=date('n');
if($year<2020 || $year>2100) $year=date('Y');

$days=cal_days_in_month(CAL_GREGORIAN,$month,$year);
$month_names=[1=>'Januari',2=>'Februari',3=>'Maret',4=>'April',5=>'Mei',6=>'Juni',7=>'Juli',8=>'Agustus',9=>'September',10=>'Oktober',11=>'November',12=>'Desember'];

/* Filter siswa berdasarkan kelas bila data kelas tersedia. */
$visible=$student_rows;
if($selected_class!==''){
    $visible=array_values(array_filter($student_rows,function($s)use($selected_class,$class_rows){
        if((string)($s['kelas_ref']??'')===$selected_class) return true;
        foreach($class_rows as $c) if((string)($c['cid']??'')===$selected_class && strcasecmp(trim((string)($c['nama_kelas']??'')),trim((string)($s['kelas_ref']??'')))===0) return true;
        return strcasecmp(trim((string)($s['kelas_ref']??'')),trim($selected_class))===0;
    }));
}

/* Data absensi diambil jika tabel dan kolom umum tersedia. */
$attendance=[];
if($att_table){
    $date_col=first_col($att_cols,['tanggal','date','tgl']);
    $student_col=first_col($att_cols,['id_siswa','student_id','siswa_id']);
    $status_col=first_col($att_cols,['status','kehadiran','keterangan','absen']);
    if($date_col && $student_col && $status_col){
        $start=sprintf('%04d-%02d-01',$year,$month);
        $end=sprintf('%04d-%02d-%02d',$year,$month,$days);
        $sql="SELECT `$student_col` sid, `$date_col` tanggal, `$status_col` status FROM `$att_table` WHERE `$date_col` BETWEEN '$start' AND '$end'";
        if($rr=q($sql)) while($a=mysqli_fetch_assoc($rr)){
            $d=date('j',strtotime($a['tanggal']));
            $attendance[(string)$a['sid']][$d]=$a['status'];
        }
    }
}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cetak Absensi Siswa per Kelas</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#12213b;font:14px Arial,sans-serif}
.wrap{max-width:1400px;margin:24px auto;padding:0 18px}.head{display:flex;justify-content:space-between;gap:15px;align-items:center;margin-bottom:18px}
h1{margin:0;font-size:25px}.sub{color:#60738c;margin-top:6px}.card{background:#fff;border:1px solid #dce5ef;border-radius:14px;padding:18px;box-shadow:0 8px 25px rgba(20,45,75,.06)}
.filters{display:flex;flex-wrap:wrap;gap:10px;align-items:end}.field{display:flex;flex-direction:column;gap:5px}.field label{font-weight:700;font-size:12px}
select,input{height:40px;border:1px solid #cbd8e6;border-radius:8px;padding:0 10px;background:#fff}
.btn{height:40px;border:0;border-radius:8px;padding:0 15px;background:#146fe8;color:#fff;font-weight:700;cursor:pointer}.btn.secondary{background:#e9eff6;color:#16304d}
.table-wrap{overflow:auto;margin-top:18px}.print-title{display:none}
table{border-collapse:collapse;width:100%;min-width:900px;background:#fff}th,td{border:1px solid #8fa1b5;padding:5px 6px;text-align:center;font-size:11px}th{background:#e9f1f8;font-weight:700}td.name{text-align:left;min-width:210px}td.status{font-weight:700}.note{margin-top:12px;color:#60738c;font-size:12px}
@media print{
 body{background:#fff}.wrap{max-width:none;margin:0;padding:0}.no-print{display:none!important}.card{border:0;box-shadow:none;padding:0}
 .print-title{display:block;text-align:center;margin-bottom:10px}.print-title h2{margin:0;font-size:16px}.print-title p{margin:3px 0;font-size:11px}
 table{min-width:0;width:100%}th,td{font-size:8px;padding:3px}.note{display:none}
}
</style>
</head>
<body>
<div class="wrap">
<div class="head no-print">
 <div><h1>🖨️ Cetak Absensi Siswa per Kelas</h1><div class="sub">Cetak daftar hadir bulanan berdasarkan kelas/rombel.</div></div>
 <button class="btn" onclick="window.print()">🖨️ Cetak Sekarang</button>
</div>
<div class="card no-print">
<form method="get" class="filters">
 <div class="field"><label>Kelas / Rombel</label>
 <select name="kelas"><option value="">Semua Kelas</option>
 <?php foreach($class_rows as $c): ?><option value="<?=e($c['cid']??$c['nama_kelas'])?>" <?=((string)$selected_class===(string)($c['cid']??$c['nama_kelas'])?'selected':'')?>><?=e($c['nama_kelas'])?></option><?php endforeach; ?>
 </select></div>
 <div class="field"><label>Bulan</label><select name="bulan"><?php foreach($month_names as $n=>$v): ?><option value="<?=$n?>" <?=$month===$n?'selected':''?>><?=e($v)?></option><?php endforeach; ?></select></div>
 <div class="field"><label>Tahun</label><input type="number" name="tahun" value="<?=$year?>" min="2020" max="2100"></div>
 <button class="btn" type="submit">Tampilkan</button>
 <a class="btn secondary" href="pusat_cetak.php" style="text-decoration:none;display:inline-flex;align-items:center">Kembali</a>
</form>
</div>

<div class="card" style="margin-top:18px">
<div class="print-title">
 <h2>DAFTAR HADIR SISWA</h2>
 <p>SDN CIBURAYUT 01</p>
 <p><?=e($month_names[$month])?> <?=$year?><?= $selected_class!==''?' — Kelas '.e($selected_class):'' ?></p>
</div>
<div class="table-wrap">
<table>
<thead><tr><th rowspan="2">NO</th><th rowspan="2">NISN / NIS</th><th rowspan="2">NAMA SISWA</th><th rowspan="2">L/P</th><th colspan="<?=$days?>"><?=e($month_names[$month])?> <?=$year?></th></tr>
<tr><?php for($d=1;$d<=$days;$d++): ?><th><?=$d?></th><?php endfor; ?></tr></thead>
<tbody>
<?php $no=1; foreach($visible as $s): $sid=(string)($s['sid']??''); ?>
<tr><td><?=$no++?></td><td><?=e($s['nisn']??'')?></td><td class="name"><?=e($s['nama']??'')?></td><td><?=e($s['jk']??'')?></td>
<?php for($d=1;$d<=$days;$d++): $v=$attendance[$sid][$d]??''; ?><td class="status"><?=e($v)?></td><?php endfor; ?>
</tr>
<?php endforeach; ?>
<?php if(!$visible): ?><tr><td colspan="<?=$days+4?>">Belum ada data siswa untuk pilihan kelas tersebut.</td></tr><?php endif; ?>
</tbody>
</table>
</div>
<div class="note">Status absensi mengikuti data yang tersimpan pada sistem. Jika tabel/kolom absensi menggunakan struktur berbeda, modul akan menampilkan daftar siswa tanpa status sampai struktur tersebut dipetakan.</div>
</div>
</div>
</body>
</html>
