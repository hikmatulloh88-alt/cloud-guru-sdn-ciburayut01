<?php
require_once '../../config/auth.php';
wajib_login();
wajib_role('Admin','Operator');
require_once '../../config/database.php';
$page_title='Cetak Akun Siswa - SDN Ciburayut 01';
$kelas_id=(int)($_GET['kelas']??0);
$kelas=[];
$q=mysqli_query($koneksi,"SELECT id_kelas,nama_kelas FROM kelas WHERE status='Aktif' ORDER BY tingkat,nama_kelas");
if($q) while($r=mysqli_fetch_assoc($q)) $kelas[]=$r;
$where="u.role='Siswa' AND u.status='Aktif'";
if($kelas_id>0) $where.=' AND s.id_kelas='.$kelas_id;
$sql="SELECT u.username,u.nama,u.password,s.nis,s.nisn,k.nama_kelas FROM users u LEFT JOIN siswa s ON s.id_siswa=u.id_siswa LEFT JOIN kelas k ON k.id_kelas=s.id_kelas WHERE $where ORDER BY k.tingkat,k.nama_kelas,u.nama";
$data=[];$q=mysqli_query($koneksi,$sql);if($q) while($r=mysqli_fetch_assoc($q)) $data[]=$r;
function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
require_once '../../includes/header.php'; require_once '../../includes/sidebar.php';
?>
<style>
.ak-wrap{max-width:1250px;margin:auto;padding-bottom:35px}.ak-head{display:flex;justify-content:space-between;gap:15px;align-items:center;margin-bottom:18px}.ak-head h1{margin:0 0 5px}.ak-head p{margin:0;color:#64748b}.ak-tools{background:#fff;border:1px solid #e5edf6;border-radius:14px;padding:14px;margin-bottom:14px;display:flex;gap:10px;align-items:end;flex-wrap:wrap}.ak-tools label{display:block;font-size:12px;font-weight:700;margin-bottom:6px}.ak-tools select{height:40px;min-width:180px;border:1px solid #dbe4ef;border-radius:9px;padding:0 10px;background:#fff}.btn{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:9px;padding:10px 14px;text-decoration:none;font-weight:700;cursor:pointer}.primary{background:#1671e8;color:#fff}.gray{background:#eef3f9;color:#334155}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.akun{background:#fff;border:1px solid #e5edf6;border-radius:14px;padding:15px;box-shadow:0 5px 18px rgba(15,35,70,.05);break-inside:avoid;page-break-inside:avoid}.akun h3{margin:0 0 9px;color:#17233c;font-size:15px;line-height:1.25}.akun table{width:100%;border-collapse:collapse;font-size:12px}.akun td{padding:4px 0;border-bottom:1px solid #f0f3f7;vertical-align:top}.akun tr:last-child td{border-bottom:0}.akun td:first-child{width:105px;color:#64748b}.pw{font-family:monospace;font-weight:800}.count{color:#64748b;margin:7px 0 13px;font-size:13px}.print-title{display:none}
@media(max-width:750px){.grid{grid-template-columns:1fr}.ak-head{align-items:flex-start;flex-direction:column}}
@media print{
 @page{size:A4 portrait;margin:8mm}
 html,body{background:#fff!important;margin:0!important;padding:0!important}
 body>header,body>nav,header,.navbar,.topbar,.sidebar,.app-sidebar,aside,body nav{display:none!important}
 .no-print{display:none!important}
 .main-content{margin:0!important;padding:0!important;width:100%!important;max-width:none!important}
 .ak-wrap{max-width:none!important;margin:0!important;padding:0!important}
 .print-title{display:block;text-align:center;margin:0 0 5mm;padding-bottom:3mm;border-bottom:1px solid #cbd5e1}
 .print-title h2{margin:0;font-size:15px}.print-title p{margin:2px 0 0;font-size:9px;color:#64748b}
 .grid{grid-template-columns:repeat(2,1fr);gap:4mm;}
 .akun{height:58mm;box-sizing:border-box;padding:4mm;border:1px solid #aeb8c6;border-radius:2mm;box-shadow:none;overflow:hidden}
 .akun h3{font-size:10.5pt;margin-bottom:2.5mm}.akun table{font-size:8.5pt}.akun td{padding:1.5mm 0}.akun td:first-child{width:29mm}
 .count{font-size:9pt;margin:0 0 3mm}.grid .akun:nth-child(8n){page-break-after:always}
}
</style>
<main class="main-content"><div class="ak-wrap">
<div class="ak-head"><div><h1>👨‍🎓 Cetak Akun Siswa</h1><p>Username menggunakan NIS dan password awal menggunakan NISN.</p></div><button class="btn primary no-print" onclick="window.print()">🖨️ Cetak Semua</button></div>
<form class="ak-tools no-print" method="get"><div><label>Kelas</label><select name="kelas"><option value="0">Semua Kelas</option><?php foreach($kelas as $k): ?><option value="<?=h($k['id_kelas'])?>" <?=$kelas_id==(int)$k['id_kelas']?'selected':''?>><?=h($k['nama_kelas'])?></option><?php endforeach;?></select></div><button class="btn primary">Tampilkan</button><a class="btn gray" href="cetak_akun_siswa.php">Reset</a></form>
<div class="count"><?=count($data)?> akun siswa ditemukan.</div>
<div class="grid"><?php foreach($data as $r): ?><div class="akun"><h3>👨‍🎓 <?=h($r['nama'] ?: 'Siswa')?></h3><table><tr><td>Kelas</td><td><?=h($r['nama_kelas'] ?: '-')?></td></tr><tr><td>NIS</td><td><?=h($r['nis'] ?: '-')?></td></tr><tr><td>NISN</td><td><?=h($r['nisn'] ?: '-')?></td></tr><tr><td>Username</td><td><strong><?=h($r['username'])?></strong></td></tr><tr><td>Password awal</td><td class="pw"><?=h($r['nisn'] ?: 'Tidak tersedia')?></td></tr></table></div><?php endforeach;?></div>
<?php if(!$data): ?><div class="akun">Belum ada akun siswa aktif.</div><?php endif; ?></div></main></body></html>
