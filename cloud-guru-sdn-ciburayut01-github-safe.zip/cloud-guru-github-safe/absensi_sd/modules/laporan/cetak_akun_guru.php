<?php
require_once '../../config/auth.php';
wajib_login();
wajib_role('Admin','Operator');
require_once '../../config/database.php';
$page_title='Cetak Akun Guru - SDN Ciburayut 01';
$pw=(string)($_GET['password']??'');
$cari=trim((string)($_GET['cari']??''));
$where="u.role='Guru' AND u.status='Aktif'";
if($cari!==''){ $x=mysqli_real_escape_string($koneksi,$cari); $where.=" AND (u.nama LIKE '%$x%' OR u.username LIKE '%$x%' OR g.nip LIKE '%$x%' OR g.nuptk LIKE '%$x%')"; }
$sql="SELECT u.username,u.nama,g.nip,g.nuptk,g.jabatan FROM users u LEFT JOIN guru g ON g.id_guru=u.id_guru WHERE $where ORDER BY u.nama";
$data=[];$q=mysqli_query($koneksi,$sql);if($q) while($r=mysqli_fetch_assoc($q)) $data[]=$r;
function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
require_once '../../includes/header.php'; require_once '../../includes/sidebar.php';
?>
<style>
.ak-wrap{max-width:1250px;margin:auto;padding-bottom:35px}.ak-head{display:flex;justify-content:space-between;gap:15px;align-items:center;margin-bottom:18px}.ak-head h1{margin:0 0 5px}.ak-head p{margin:0;color:#64748b}.ak-tools{background:#fff;border:1px solid #e5edf6;border-radius:14px;padding:14px;margin-bottom:14px;display:flex;gap:10px;align-items:end;flex-wrap:wrap}.ak-tools label{display:block;font-size:12px;font-weight:700;margin-bottom:6px}.ak-tools input{height:40px;border:1px solid #dbe4ef;border-radius:9px;padding:0 10px}.btn{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:9px;padding:10px 14px;text-decoration:none;font-weight:700;cursor:pointer}.primary{background:#1671e8;color:#fff}.gray{background:#eef3f9;color:#334155}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.akun{background:#fff;border:1px solid #e5edf6;border-radius:14px;padding:15px;box-shadow:0 5px 18px rgba(15,35,70,.05);break-inside:avoid;page-break-inside:avoid}.akun h3{margin:0 0 9px;color:#17233c;font-size:15px;line-height:1.25}.akun table{width:100%;border-collapse:collapse;font-size:12px}.akun td{padding:4px 0;border-bottom:1px solid #f0f3f7;vertical-align:top}.akun tr:last-child td{border-bottom:0}.akun td:first-child{width:112px;color:#64748b}.pw{font-family:monospace;font-weight:800}.count{color:#64748b;margin:7px 0 13px;font-size:13px}.note{background:#fff8e7;border:1px solid #fde6a8;color:#7a5a00;border-radius:10px;padding:10px 12px;font-size:12px;margin-bottom:12px}.print-title{display:none}
@media(max-width:750px){.grid{grid-template-columns:1fr}.ak-head{align-items:flex-start;flex-direction:column}}
@media print{
 @page{size:A4 portrait;margin:8mm}
 html,body{background:#fff!important;margin:0!important;padding:0!important}
 body>header,body>nav,header,.navbar,.topbar,.sidebar,.app-sidebar,aside,body nav{display:none!important}
 .no-print{display:none!important}
 .main-content{margin:0!important;padding:0!important;width:100%!important;max-width:none!important}
 .ak-wrap{max-width:none!important;margin:0!important;padding:0!important}
 .print-title{display:block;text-align:center;margin:0 0 5mm;padding-bottom:3mm;border-bottom:1px solid #cbd5e1}
 .print-title h2{margin:0;font-size:15px}.print-title p{margin:2px 0 0;font-size:9px;color:#64748b}
 .grid{grid-template-columns:repeat(2,1fr);gap:4mm}
 .akun{height:58mm;box-sizing:border-box;padding:4mm;border:1px solid #aeb8c6;border-radius:2mm;box-shadow:none;overflow:hidden}
 .akun h3{font-size:10.5pt;margin-bottom:2.5mm}.akun table{font-size:8.5pt}.akun td{padding:1.5mm 0}.akun td:first-child{width:29mm}
 .count{font-size:9pt;margin:0 0 3mm}.grid .akun:nth-child(8n){page-break-after:always}
}
</style>
<main class="main-content"><div class="ak-wrap">
<div class="ak-head"><div><h1>👨‍🏫 Cetak Akun Guru</h1><p>Cetak akun Guru yang sudah dibuat pada menu Pengguna.</p></div><button class="btn primary no-print" onclick="window.print()">🖨️ Cetak Semua</button></div>
<form class="ak-tools no-print" method="get"><div><label>Cari Guru</label><input name="cari" value="<?=h($cari)?>" placeholder="Nama, username, NIP/NUPTK"></div><div><label>Password saat Generate</label><input name="password" value="<?=h($pw)?>" placeholder="Isi jika ingin dicetak"></div><button class="btn primary">Tampilkan</button><a class="btn gray" href="cetak_akun_guru.php">Reset</a></form>
<div class="note no-print">🔐 Password tersimpan di database dalam bentuk hash sehingga tidak bisa dibaca kembali. Jika akun dibuat melalui <strong>Generate Akun Guru</strong>, masukkan password yang digunakan saat proses generate agar ikut tercetak. Password tidak disimpan oleh halaman ini.</div>
<div class="count"><?=count($data)?> akun guru aktif ditemukan.</div>
<div class="grid"><?php foreach($data as $r): ?><div class="akun"><h3>👨‍🏫 <?=h($r['nama'] ?: 'Guru')?></h3><table><tr><td>Jabatan</td><td><?=h($r['jabatan'] ?: '-')?></td></tr><tr><td>NIP</td><td><?=h($r['nip'] ?: '-')?></td></tr><tr><td>NUPTK</td><td><?=h($r['nuptk'] ?: '-')?></td></tr><tr><td>Username</td><td><strong><?=h($r['username'])?></strong></td></tr><tr><td>Password</td><td class="pw"><?=h($pw!==''?$pw:'Tidak diisi')?></td></tr></table></div><?php endforeach;?></div>
<?php if(!$data): ?><div class="akun">Belum ada akun Guru aktif.</div><?php endif; ?></div></main></body></html>
