<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator');
require_once "../../config/database.php";

$menu_aktif = 'buku_induk_masal';
$page_title = 'Cetak Buku Induk Masal - SDN Ciburayut 01';

function h($v){ return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function v($row,$keys,$default=''){
    foreach((array)$keys as $k){
        if(isset($row[$k]) && trim((string)$row[$k])!=='') return $row[$k];
    }
    return $default;
}
function tgl_id($d){
    if(!$d || $d==='0000-00-00') return '';
    $t=strtotime((string)$d);
    return $t ? date('d-m-Y',$t) : (string)$d;
}
function first_name($name){
    $name=trim(preg_replace('/\s+/',' ',(string)$name));
    return $name!=='' ? explode(' ',$name)[0] : '';
}
function norm_mapel($s){
    $s=strtolower(trim((string)$s));
    $s=str_replace(['pendidikan agama islam','pendidikan agama','pai'],'agama',$s);
    $s=str_replace(['pendidikan pancasila dan kewarganegaraan','pendidikan pancasila','ppkn'],'ppkn',$s);
    $s=str_replace(['ilmu pengetahuan alam','ipa'],'ipa',$s);
    $s=str_replace(['ilmu pengetahuan sosial','ips'],'ips',$s);
    $s=str_replace(['pendidikan jasmani olahraga dan kesehatan','pendidikan jasmani','pjok','penjaskes'],'penjaskes',$s);
    $s=str_replace(['bahasa sunda','bahasa jawa','bahasa daerah','b. daerah'],'daerah',$s);
    $s=str_replace('bahasa indonesia','bahasaindonesia',$s);
    $s=str_replace('bahasa inggris','bahasainggris',$s);
    $s=str_replace('seni budaya','senibudaya',$s);
    $s=str_replace('matematika','matematika',$s);
    return preg_replace('/[^a-z0-9]+/','',$s);
}
function overlay($x,$y,$w,$text,$class=''){
    if($text===null || trim((string)$text)==='') return;
    echo '<span class="ov '.h($class).'" style="left:'.(float)$x.'pt;top:'.(float)$y.'pt;width:'.(float)$w.'pt;">'.h($text).'</span>';
}
function overlay_center($cx,$y,$w,$text,$class='center'){
    if($text===null || trim((string)$text)==='') return;
    overlay($cx-($w/2),$y,$w,$text,$class.' center');
}

$id_kelas=(int)($_GET['id_kelas']??0);
$kelas=[];
$qk=mysqli_query($koneksi,"SELECT k.id_kelas,k.nama_kelas,k.tingkat,k.id_wali_kelas,k.id_tahun_ajaran,g.nama AS nama_wali_kelas,ta.tahun_ajaran,ta.semester FROM kelas k LEFT JOIN guru g ON g.id_guru=k.id_wali_kelas LEFT JOIN tahun_ajaran ta ON ta.id_tahun_ajaran=k.id_tahun_ajaran WHERE k.status='Aktif' ORDER BY k.tingkat,k.nama_kelas");
if($qk) while($r=mysqli_fetch_assoc($qk)) $kelas[]=$r;

$kelas_terpilih=null;
if($id_kelas){
    $st=mysqli_prepare($koneksi,"SELECT k.id_kelas,k.nama_kelas,k.tingkat,k.id_wali_kelas,k.id_tahun_ajaran,g.nama AS nama_wali_kelas,ta.tahun_ajaran,ta.semester FROM kelas k LEFT JOIN guru g ON g.id_guru=k.id_wali_kelas LEFT JOIN tahun_ajaran ta ON ta.id_tahun_ajaran=k.id_tahun_ajaran WHERE k.id_kelas=? LIMIT 1");
    if($st){
        mysqli_stmt_bind_param($st,'i',$id_kelas); mysqli_stmt_execute($st);
        $rr=mysqli_stmt_get_result($st); $kelas_terpilih=$rr?mysqli_fetch_assoc($rr):null;
    }
}

$siswa=[];
if($id_kelas){
    $sql="SELECT s.*,k.nama_kelas,k.tingkat,k.id_wali_kelas,g.nama AS nama_wali_kelas,ta.tahun_ajaran AS tahun_ajaran_aktif,ta.semester AS semester_aktif
          FROM siswa s
          LEFT JOIN kelas k ON k.id_kelas=s.id_kelas
          LEFT JOIN guru g ON g.id_guru=k.id_wali_kelas
          LEFT JOIN tahun_ajaran ta ON ta.id_tahun_ajaran=k.id_tahun_ajaran
          WHERE s.status_siswa='Aktif' AND s.id_kelas=? ORDER BY s.nama_siswa";
    $st=mysqli_prepare($koneksi,$sql);
    if($st){ mysqli_stmt_bind_param($st,'i',$id_kelas); mysqli_stmt_execute($st); $rs=mysqli_stmt_get_result($st); while($rs && ($r=mysqli_fetch_assoc($rs))) $siswa[]=$r; }
}

/* Buku Induk menjadi sumber data khusus buku induk. Data master siswa tetap menjadi fallback untuk field Dapodik. */
$bi=[]; $bi_cols=[];
$qbi=mysqli_query($koneksi,"SHOW COLUMNS FROM buku_induk");
if($qbi) while($r=mysqli_fetch_assoc($qbi)) $bi_cols[$r['Field']]=true;
if($siswa){
    $ids=implode(',',array_map(fn($x)=>(int)$x['id_siswa'],$siswa));
    $qb=mysqli_query($koneksi,"SELECT * FROM buku_induk WHERE id_siswa IN ($ids)");
    if($qb) while($r=mysqli_fetch_assoc($qb)) $bi[(int)$r['id_siswa']]=$r;
}

/* Nilai historis: kelas 1-6 x semester 1-2. */
$nilai=[];
if($siswa){
    $ids=implode(',',array_map(fn($x)=>(int)$x['id_siswa'],$siswa));
    $qv=mysqli_query($koneksi,"SELECT n.id_siswa,n.id_tahun_ajaran,n.id_kelas,n.id_mapel,n.nilai_akhir,n.nilai_rapor,ta.tahun_ajaran,ta.semester,k.tingkat,mp.nama_mapel
        FROM nilai n
        LEFT JOIN tahun_ajaran ta ON ta.id_tahun_ajaran=n.id_tahun_ajaran
        LEFT JOIN kelas k ON k.id_kelas=n.id_kelas
        LEFT JOIN mata_pelajaran mp ON mp.id_mapel=n.id_mapel
        WHERE n.id_siswa IN ($ids)");
    if($qv) while($r=mysqli_fetch_assoc($qv)) $nilai[(int)$r['id_siswa']][]=$r;
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>
<style>
.bi-page{max-width:1500px}.head{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}.head h1{margin:0 0 5px}.head p{margin:0;color:#64748b}.card{background:#fff;border-radius:18px;padding:20px;margin-bottom:18px;box-shadow:0 8px 25px rgba(15,35,70,.07)}
.filters{display:grid;grid-template-columns:1fr auto;gap:12px;align-items:end}.fc{width:100%;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 10px;background:#fff}.lbl{font-size:13px;font-weight:700;color:#334155;display:block;margin-bottom:7px}.btn{border:0;border-radius:10px;padding:11px 16px;font-weight:700;cursor:pointer}.pri{background:#1265dc;color:#fff}.info{padding:12px 14px;background:#eef6ff;border:1px solid #d6e8fb;border-radius:10px;color:#245c9b;font-size:13px}
.bi-sheet{position:relative;width:612pt;height:792pt;margin:0 auto 20px;background:#fff center/100% 100% no-repeat;overflow:hidden;page-break-after:always;break-after:page}
.bi-sheet.p1{background-image:url('../../assets/images/buku_induk_template/page1.png')}.bi-sheet.p2{background-image:url('../../assets/images/buku_induk_template/page2.png')}.bi-sheet.p3{width:792pt;height:612pt;background-image:url('../../assets/images/buku_induk_template/page3.png')}
.ov{position:absolute;z-index:4;font-family:Arial,Helvetica,sans-serif;font-size:9pt;line-height:1.12;color:#111;white-space:nowrap;overflow:hidden;text-overflow:clip;background:#fff;padding:0 1.5pt;box-sizing:border-box}.ov.center{text-align:center}.photo{position:absolute;z-index:3;object-fit:cover;background:#fff}
.print-only{display:block}
@media print{
 @page biPortrait{size:letter portrait;margin:0} @page biLandscape{size:letter landscape;margin:0}
 html,body{margin:0!important;padding:0!important;background:#fff!important}.sidebar,.head,.filter-card,.no-print{display:none!important}.main-content{margin:0!important;padding:0!important}.bi-page{max-width:none!important}
 .bi-sheet{width:612pt;height:792pt;margin:0;page:biPortrait;background-size:100% 100%!important;-webkit-print-color-adjust:exact;print-color-adjust:exact;page-break-after:always;break-after:page}
 .bi-sheet.p3{width:792pt;height:612pt;page:biLandscape}.bi-sheet:last-child{page-break-after:auto;break-after:auto}.ov{font-size:9pt}
}
</style>
<main class="main-content"><div class="bi-page">
<div class="head"><div><h1>Cetak Buku Induk Masal</h1><p>Template cetak 100% mengikuti dokumen Buku Induk SDN Ciburayut 01 (3 halaman per siswa).</p></div></div>
<div class="card filter-card no-print"><form method="get" id="formPilihKelas"><div class="filters"><div><label class="lbl">Pilih Kelas</label><select class="fc" name="id_kelas" onchange="document.getElementById('formPilihKelas').submit()"><option value="0">Pilih Kelas</option><?php foreach($kelas as $k): $jml=0; $qj=mysqli_query($koneksi,"SELECT COUNT(*) jml FROM siswa WHERE id_kelas=".(int)$k['id_kelas']." AND status_siswa='Aktif'"); if($qj&&($rj=mysqli_fetch_assoc($qj)))$jml=(int)$rj['jml']; ?><option value="<?=h($k['id_kelas'])?>" <?=$id_kelas===(int)$k['id_kelas']?'selected':''?>><?=h($k['nama_kelas'])?><?php if(!empty($k['nama_wali_kelas']))echo' — '.h($k['nama_wali_kelas']);?> (<?=$jml?> siswa)</option><?php endforeach;?></select></div><button class="btn pri" type="submit">🔎 Tampilkan</button></div></form></div>
<?php if(!$kelas): ?><div class="card"><div class="info">Belum ada kelas aktif pada database.</div></div>
<?php elseif(!$id_kelas): ?><div class="card"><div class="info">Pilih kelas. Setiap siswa akan dicetak tepat 3 halaman sesuai template baru.</div></div>
<?php elseif(!$siswa): ?><div class="card"><div class="info">Kelas <?=h($kelas_terpilih['nama_kelas']??'')?> belum memiliki siswa aktif.</div></div>
<?php else: ?>
<div class="card no-print"><div class="info"><strong><?=count($siswa)?> siswa</strong> — <?=h($kelas_terpilih['nama_kelas']??'')?><?php if(!empty($kelas_terpilih['nama_wali_kelas']))echo' — Wali Kelas: '.h($kelas_terpilih['nama_wali_kelas']);?><br><button type="button" class="btn pri" style="margin-top:10px" onclick="window.print()">🖨️ Cetak Semua Buku Induk</button></div></div>
<div class="print-only">
<?php foreach($siswa as $s):
    $book=$bi[(int)$s['id_siswa']]??[];
    $d=array_merge($s,$book);
    $get=function($keys,$default='')use($d){return v($d,$keys,$default);};

    $photo='';
    $photoDb=$get(['foto'],'');
    if($photoDb){
        $candidate=__DIR__.'/../../'.ltrim(str_replace('\\','/',$photoDb),'/');
        if(is_file($candidate)) $photo='../../'.ltrim(str_replace('\\','/',$photoDb),'/');
    }
    if(!$photo){
        foreach(['jpg','jpeg','png','webp'] as $e){
            $candidate=__DIR__.'/../../assets/images/siswa/'.(int)$s['id_siswa'].'.'.$e;
            if(is_file($candidate)){ $photo='../../assets/images/siswa/'.(int)$s['id_siswa'].'.'.$e; break; }
        }
    }

    /* Nilai historis */
    $all=$nilai[(int)$s['id_siswa']]??[];
    $map=[]; $years=[];
    foreach($all as $n){
        $lvl=(int)($n['tingkat']??0);
        $sem=strtolower((string)($n['semester']??''));
        $semno=str_contains($sem,'genap')?'2':'1';
        $mk=norm_mapel($n['nama_mapel']??'');
        $score=$n['nilai_rapor']??$n['nilai_akhir']??'';
        if($lvl>=1&&$lvl<=6&&$mk){$map[$lvl][$semno][$mk]=$score; if(!empty($n['tahun_ajaran']))$years[$lvl]=$n['tahun_ajaran'];}
    }
    $activeYear=$get(['tahun_ajaran_aktif'],'');
    if(!$activeYear && !empty($kelas_terpilih['tahun_ajaran']))$activeYear=$kelas_terpilih['tahun_ajaran'];
    if(!$activeYear)$activeYear='2026/2027';

    /* HALAMAN 1 */
    ?><div class="bi-sheet p1">
    <?php
    overlay(244,59,52,$get(['nis']));
    overlay(373,59,57,$get(['nisn']));
    overlay(233,105,61,$get(['nama_siswa']));
    overlay(233,121.5,61,first_name($get(['nama_siswa'])));
    overlay(233,155,61,$get(['nik']));
    overlay(233,171.5,61,$get(['no_registrasi_akta_lahir','no_akta']));
    overlay(233,188.5,61,($get(['jenis_kelamin'])==='P'?'Perempuan':($get(['jenis_kelamin'])==='L'?'Laki-laki':'')));
    overlay(233,205.5,61,tgl_id($get(['tanggal_lahir'])));
    overlay(233,222.5,61,$get(['tempat_lahir']));
    overlay(233,239.5,61,$get(['agama']));
    overlay(233,256.5,61,$get(['kewarganegaraan']));
    overlay(233,273.5,61,$get(['anak_ke']));
    overlay(233,308,61,$get(['jml_saudara_kandung']));
    overlay(233,395,55,$get(['berat_badan','berat']));
    overlay(233,411.5,55,$get(['tinggi_badan','tinggi']));
    overlay(233,428.5,61,$get(['golongan_darah','goldar']));
    overlay(290,445,61,$get(['penyakit_pernah_diderita','penyakit']));
    overlay(290,462,120,$get(['alamat']));
    overlay(290,479,100,$get(['no_wa_aktif','hp','telepon']));
    overlay(290,496,100,$get(['jenis_tinggal']));
    overlay(290,512.5,70,$get(['jarak_rumah_ke_sekolah','jarak_rumah_km']));
    overlay(179,596,125,$get(['nama_ayah']));
    overlay(179,613,125,$get(['ayah_nik']));
    overlay(179,630,125,$get(['ayah_pendidikan']));
    overlay(179,647,125,$get(['ayah_pekerjaan']));
    overlay(179,698,125,$get(['nama_ibu']));
    overlay(179,715,125,$get(['ibu_nik']));
    overlay(455,596,125,$get(['ibu_pendidikan']));
    overlay(455,613,125,$get(['ibu_pekerjaan']));
    overlay(455,665,125,$get(['nama_wali']));
    overlay(455,682,125,$get(['wali_nik']));
    overlay(455,699,125,$get(['wali_pendidikan']));
    overlay(455,716,125,$get(['wali_pekerjaan']));
    if($photo) echo '<img class="photo" src="'.h($photo).'" style="left:394.5pt;top:86pt;width:101.5pt;height:151pt" onerror="this.style.display=\'none\'">';
    ?>
    </div>

    <!-- HALAMAN 2 -->
    <div class="bi-sheet p2">
    <?php
    overlay(318,81,61,$get(['asal_siswa','asal_sekolah','sekolah_asal']));
    overlay(318,98,61,$get(['nama_paud']));
    overlay(318,115,61,$get(['alamat_asal','alamat_paud']));
    overlay(318,132,61,$get(['tanggal_nomor_ijazah','nomor_ijazah','no_ijazah']));
    overlay(290,171.5,61,$get(['nama_sekolah_asal','asal_sekolah','sekolah_asal']));
    overlay(290,188.5,61,$get(['dari_tingkat']));
    overlay(290,205.5,61,tgl_id($get(['diterima_tanggal'])));
    overlay(290,222.5,68,$get(['di_tingkat']));
    overlay(233,414,61,$get(['jenis_bea_siswa','beasiswa']));
    overlay(233,485,40,$get(['tahun_tamat']));
    overlay(233,501.5,55,$get(['nomor_ijazah','no_ijazah']));
    overlay(270,518,100,$get(['melanjutkan_ke_sekolah']));
    overlay(233,554,55,$get(['pindah_dari_tingkat']));
    overlay(233,571,100,$get(['pindah_ke_sekolah']));
    overlay(233,587.5,55,$get(['pindah_ke_tingkat']));
    overlay(233,604,70,tgl_id($get(['tanggal_pindah'])));
    overlay(233,638,70,tgl_id($get(['tanggal_keluar'])));
    overlay(233,655,100,$get(['alasan_keluar']));
    overlay(233,695,110,$get(['catatan_penting','catatan_wali_kelas','catatan_wali','catatan']));

    /* Tabel keadaan jasmani. Kolom tahun mengikuti tahun ajaran nilai bila tersedia. */
    $yearCenters=[280.5,328.5,377.5,425.5,473.5,521.5];
    $tableYears=[];
    for($lvl=1;$lvl<=6;$lvl++){
        $tableYears[$lvl]='20..';
        if(!empty($years[$lvl])) $tableYears[$lvl]=substr((string)$years[$lvl],0,4);
    }
    if(empty($years[1])) $tableYears[1]=substr((string)$activeYear,0,4);
    for($i=1;$i<=6;$i++) overlay_center($yearCenters[$i-1],272,38,$tableYears[$i]);
    $rowY=[301.5,317.5,333.5,349.5,365.5];
    for($i=1;$i<=6;$i++){
        $x=$yearCenters[$i-1];
        $suffix=$i;
        $bb=$get(['berat_badan_'.$suffix],$i===1?$get(['berat_badan']):'');
        $tb=$get(['tinggi_badan_'.$suffix],$i===1?$get(['tinggi_badan']):'');
        $lk=$get(['lingkar_kepala_'.$suffix],$i===1?$get(['lingkar_kepala']):'');
        $py=$get(['penyakit_'.$suffix],$i===1?$get(['penyakit_pernah_diderita']):'-');
        $kj=$get(['kelainan_jasmani_'.$suffix],$i===1?$get(['kelainan_jasmani']):'-');
        overlay_center($x,$rowY[0],38,$bb);
        overlay_center($x,$rowY[1],38,$tb);
        overlay_center($x,$rowY[2],38,$lk);
        overlay_center($x,$rowY[3],38,$py===' ' ? '-' : ($py!==''?$py:'-'));
        overlay_center($x,$rowY[4],38,$kj===' ' ? '-' : ($kj!==''?$kj:'-'));
    }
    if($photo) echo '<img class="photo" src="'.h($photo).'" style="left:383.5pt;top:401pt;width:102pt;height:152pt" onerror="this.style.display=\'none\'">';
    ?>
    </div>

    <!-- HALAMAN 3 -->
    <div class="bi-sheet p3">
    <?php
    $subjectRows=['ppkn','agama','bahasaindonesia','matematika','ipa','ips','senibudaya','penjaskes','bahasainggris','daerah'];
    $colCentersPx=[540.5,623.5,711.5,804.5,892.5,976,1059.5,1142.5,1225.5,1309,1392.5,1476];
    $colCenters=[]; foreach($colCentersPx as $px)$colCenters[]=$px/2;
    $classGroupCenters=[];
    $bounds=[499,665,851,1018,1184,1351,1518];
    for($i=0;$i<6;$i++)$classGroupCenters[]=(($bounds[$i]+$bounds[$i+1])/2)/2;
    for($lvl=1;$lvl<=6;$lvl++) overlay_center($classGroupCenters[$lvl-1],49,72,$years[$lvl]??'.... / ....');

    foreach($subjectRows as $ri=>$sub){
        $y=98+$ri*12;
        for($lvl=1;$lvl<=6;$lvl++){
            foreach([1,2] as $sem){
                $col=($lvl-1)*2+($sem-1);
                $val=$map[$lvl][$sem][$sub]??'';
                if($val!=='') overlay_center($colCenters[$col],$y,30,$val,'score');
            }
        }
    }
    for($lvl=1;$lvl<=6;$lvl++){
        $vals=[];
        foreach([1,2] as $sem)foreach($subjectRows as $sub){$z=$map[$lvl][$sem][$sub]??'';if($z!==''&&is_numeric($z))$vals[]=(float)$z;}
        $x=$classGroupCenters[$lvl-1];
        if($vals){overlay_center($x,239,70,number_format(array_sum($vals),2,'.',''));overlay_center($x,251,70,number_format(array_sum($vals)/count($vals),2,',','.'));}
        overlay_center($x,263,70,$get(['ranking_kelas','rangking_kelas']));
        overlay_center($x,275,70,$get(['kelakuan']));
        overlay_center($x,287,70,$get(['kerajinan']));
        overlay_center($x,299,70,$get(['kebersihan']));
    }

    /* Rekap ketidakhadiran dari absensi_siswa berdasarkan tahun ajaran pada masing-masing kolom nilai. */
    $abs=[];
    $sid=(int)$s['id_siswa'];
    $qa=mysqli_query($koneksi,"SELECT a.id_tahun_ajaran,ta.semester,a.status,COUNT(*) jml FROM absensi_siswa a LEFT JOIN tahun_ajaran ta ON ta.id_tahun_ajaran=a.id_tahun_ajaran WHERE a.id_siswa=$sid GROUP BY a.id_tahun_ajaran,ta.semester,a.status");
    if($qa) while($ar=mysqli_fetch_assoc($qa)) $abs[(int)$ar['id_tahun_ajaran']][strtolower((string)$ar['semester'])][strtolower((string)$ar['status'])]=(int)$ar['jml'];
    $taToCol=[];
    foreach($all as $n){$ta=(int)($n['id_tahun_ajaran']??0);$lvl=(int)($n['tingkat']??0);$sem=strtolower((string)($n['semester']??''));$sn=str_contains($sem,'genap')?2:1;if($lvl>=1&&$lvl<=6&&$ta)$taToCol[$lvl][$sn]=$ta;}
    foreach($taToCol as $lvl=>$sems){foreach($sems as $sn=>$ta){$col=($lvl-1)*2+($sn-1);$x=$colCenters[$col];$sakit=$abs[$ta]['gasal']['sakit']??0; if($sn===2)$sakit=$abs[$ta]['genap']['sakit']??0; $izin=$abs[$ta][strtolower($sn===2?'genap':'gasal')]['izin']??0; $alpa=$abs[$ta][strtolower($sn===2?'genap':'gasal')]['alpa']??0; overlay_center($x,323,30,$sakit);overlay_center($x,335,30,$izin);overlay_center($x,347,30,$alpa);}}

    overlay(539,399,85,'Cigombong, '.date('d-m-Y'));
    ?>
    </div>
<?php endforeach; ?>
</div>
<?php endif; ?>
</div></main>
</body></html>
