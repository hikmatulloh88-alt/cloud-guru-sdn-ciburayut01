<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator');
require_once "../../config/database.php";

$menu_aktif = 'buku_induk_masal';
$page_title = 'Cetak Buku Induk Masal - SDN Ciburayut 01';

function h($v){ return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function v($row,$keys,$default=''){
    foreach((array)$keys as $k){
        if(isset($row[$k]) && trim((string)$row[$k])!=='') return $row[$k];
    }
    return $default;
}
function tgl_id($d){
    if(!$d || $d==='0000-00-00') return '';
    $t=strtotime((string)$d);
    return $t ? date('d-m-Y',$t) : (string)$d;
}
function first_name($name){
    $name=trim(preg_replace('/\s+/',' ',(string)$name));
    return $name!=='' ? explode(' ',$name)[0] : '';
}
function norm_mapel($s){
    $s=strtolower(trim((string)$s));
    $s=str_replace(['pendidikan agama islam','pendidikan agama','pai'],'agama',$s);
    $s=str_replace(['pendidikan pancasila dan kewarganegaraan','pendidikan pancasila','ppkn'],'ppkn',$s);
    $s=str_replace(['ilmu pengetahuan alam','ipa'],'ipa',$s);
    $s=str_replace(['ilmu pengetahuan sosial','ips'],'ips',$s);
    $s=str_replace(['pendidikan jasmani olahraga dan kesehatan','pendidikan jasmani','pjok','penjaskes'],'penjaskes',$s);
    $s=str_replace(['bahasa sunda','bahasa jawa','bahasa daerah','b. daerah'],'daerah',$s);
    $s=str_replace('bahasa indonesia','bahasaindonesia',$s);
    $s=str_replace('bahasa inggris','bahasainggris',$s);
    $s=str_replace('seni budaya','senibudaya',$s);
    $s=str_replace('matematika','matematika',$s);
    return preg_replace('/[^a-z0-9]+/','',$s);
}

/* Kepala Sekolah: diambil dari data Guru dengan jabatan mengandung "Kepala Sekolah". */
$kepsek_nama='Solihat, S.Pd, MM'; $kepsek_nip='196910161992122002';
$qks=mysqli_query($koneksi,"SELECT nama,nip FROM guru WHERE jabatan LIKE '%Kepala Sekolah%' AND status='Aktif' ORDER BY id_guru DESC LIMIT 1");
if($qks && ($rks=mysqli_fetch_assoc($qks))){
    if(!empty($rks['nama'])) $kepsek_nama=$rks['nama'];
    if(!empty($rks['nip'])) $kepsek_nip=$rks['nip'];
}

$id_kelas=(int)($_GET['id_kelas']??0);
$kelas=[];
$qk=mysqli_query($koneksi,"SELECT k.id_kelas,k.nama_kelas,k.tingkat,k.id_wali_kelas,k.id_tahun_ajaran,g.nama AS nama_wali_kelas,ta.tahun_ajaran,ta.semester FROM kelas k LEFT JOIN guru g ON g.id_guru=k.id_wali_kelas LEFT JOIN tahun_ajaran ta ON ta.id_tahun_ajaran=k.id_tahun_ajaran WHERE k.status='Aktif' ORDER BY k.tingkat,k.nama_kelas");
if($qk) while($r=mysqli_fetch_assoc($qk)) $kelas[]=$r;

$kelas_terpilih=null;
if($id_kelas){
    $st=mysqli_prepare($koneksi,"SELECT k.id_kelas,k.nama_kelas,k.tingkat,k.id_wali_kelas,k.id_tahun_ajaran,g.nama AS nama_wali_kelas,ta.tahun_ajaran,ta.semester FROM kelas k LEFT JOIN guru g ON g.id_guru=k.id_wali_kelas LEFT JOIN tahun_ajaran ta ON ta.id_tahun_ajaran=k.id_tahun_ajaran WHERE k.id_kelas=? LIMIT 1");
    if($st){
        mysqli_stmt_bind_param($st,'i',$id_kelas); mysqli_stmt_execute($st);
        $rr=mysqli_stmt_get_result($st); $kelas_terpilih=$rr?mysqli_fetch_assoc($rr):null;
    }
}

$siswa=[];
if($id_kelas){
    $sql="SELECT s.*,k.nama_kelas,k.tingkat,k.id_wali_kelas,g.nama AS nama_wali_kelas,ta.tahun_ajaran AS tahun_ajaran_aktif,ta.semester AS semester_aktif
          FROM siswa s
          LEFT JOIN kelas k ON k.id_kelas=s.id_kelas
          LEFT JOIN guru g ON g.id_guru=k.id_wali_kelas
          LEFT JOIN tahun_ajaran ta ON ta.id_tahun_ajaran=k.id_tahun_ajaran
          WHERE s.status_siswa='Aktif' AND s.id_kelas=? ORDER BY s.nama_siswa";
    $st=mysqli_prepare($koneksi,$sql);
    if($st){ mysqli_stmt_bind_param($st,'i',$id_kelas); mysqli_stmt_execute($st); $rs=mysqli_stmt_get_result($st); while($rs && ($r=mysqli_fetch_assoc($rs))) $siswa[]=$r; }
}

/* Buku Induk menjadi sumber data khusus buku induk. Data master siswa tetap menjadi fallback untuk field Dapodik. */
$bi=[]; $bi_cols=[];
$qbi=mysqli_query($koneksi,"SHOW COLUMNS FROM buku_induk");
if($qbi) while($r=mysqli_fetch_assoc($qbi)) $bi_cols[$r['Field']]=true;
if($siswa){
    $ids=implode(',',array_map(fn($x)=>(int)$x['id_siswa'],$siswa));
    $qb=mysqli_query($koneksi,"SELECT * FROM buku_induk WHERE id_siswa IN ($ids)");
    if($qb) while($r=mysqli_fetch_assoc($qb)) $bi[(int)$r['id_siswa']]=$r;
}

/* Nilai historis: kelas 1-6 x semester 1-2. */
$nilai=[];
if($siswa){
    $ids=implode(',',array_map(fn($x)=>(int)$x['id_siswa'],$siswa));
    $qv=mysqli_query($koneksi,"SELECT n.id_siswa,n.id_tahun_ajaran,n.id_kelas,n.id_mapel,n.nilai_akhir,n.nilai_rapor,ta.tahun_ajaran,ta.semester,k.tingkat,mp.nama_mapel
        FROM nilai n
        LEFT JOIN tahun_ajaran ta ON ta.id_tahun_ajaran=n.id_tahun_ajaran
        LEFT JOIN kelas k ON k.id_kelas=n.id_kelas
        LEFT JOIN mata_pelajaran mp ON mp.id_mapel=n.id_mapel
        WHERE n.id_siswa IN ($ids)");
    if($qv) while($r=mysqli_fetch_assoc($qv)) $nilai[(int)$r['id_siswa']][]=$r;
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>
<style>
.bi-page{max-width:1500px}.head{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}.head h1{margin:0 0 5px}.head p{margin:0;color:#64748b}.card{background:#fff;border-radius:18px;padding:20px;margin-bottom:18px;box-shadow:0 8px 25px rgba(15,35,70,.07)}
.filters{display:grid;grid-template-columns:1fr auto;gap:12px;align-items:end}.fc{width:100%;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 10px;background:#fff}.lbl{font-size:13px;font-weight:700;color:#334155;display:block;margin-bottom:7px}.btn{border:0;border-radius:10px;padding:11px 16px;font-weight:700;cursor:pointer}.pri{background:#1265dc;color:#fff}.info{padding:12px 14px;background:#eef6ff;border:1px solid #d6e8fb;border-radius:10px;color:#245c9b;font-size:13px}
.print-only{display:block}
.bi-sheet{position:relative;width:612pt;min-height:792pt;margin:0 auto 20px;background:#fff;padding:34pt 40pt;box-sizing:border-box;font-family:Arial,Helvetica,sans-serif;font-size:10.5pt;line-height:1.5;color:#111;page-break-after:always;break-after:page}
.bi-sheet.p3{width:792pt;min-height:612pt}
.bi-title{text-align:center;font-weight:700;font-size:14pt;margin:0 0 4pt}
.bi-sub{text-align:center;margin:0 0 14pt}
.bi-sub span{margin:0 18pt}
.bi-row{display:flex;gap:24pt}
.bi-col-main{flex:1}
.photobox{width:110pt;height:150pt;border:1pt solid #111;flex:0 0 auto;position:relative;overflow:hidden}
.photobox img{width:100%;height:100%;object-fit:cover}
.item{margin:2pt 0}
.item>.no{display:inline-block;width:16pt}
.sub{margin:2pt 0 2pt 30pt}
.sub .b{display:inline-block;width:14pt}
h3.sec{font-size:11pt;margin:16pt 0 8pt}
.twocol{display:flex;gap:30pt;margin-top:6pt}
.twocol .col{flex:1}
.twocol b.grp{display:block;margin:8pt 0 4pt}
table.bi-jasmani{border-collapse:collapse;width:100%;margin:6pt 0}
table.bi-jasmani th,table.bi-jasmani td{border:1pt solid #111;padding:3pt 5pt;text-align:center;font-size:9.5pt}
table.bi-jasmani td.ket{text-align:left}
table.bi-prestasi{border-collapse:collapse;width:100%;font-size:9pt}
table.bi-prestasi th,table.bi-prestasi td{border:1pt solid #111;padding:2.5pt 3pt;text-align:center}
table.bi-prestasi td.left{text-align:left}
table.bi-prestasi tr.grp td{font-weight:700}
.ttd{margin-top:26pt;text-align:right}
.ttd .nm{font-weight:700;text-decoration:underline;margin-top:34pt}
@media print{
 @page biPortrait{size:letter portrait;margin:0} @page biLandscape{size:letter landscape;margin:0}
 html,body{margin:0!important;padding:0!important;background:#fff!important}.sidebar,.head,.filter-card,.no-print{display:none!important}.main-content{margin:0!important;padding:0!important}.bi-page{max-width:none!important}
 .bi-sheet{width:612pt;min-height:792pt;margin:0;page:biPortrait;page-break-after:always;break-after:page}
 .bi-sheet.p3{width:792pt;min-height:612pt;page:biLandscape}.bi-sheet:last-child{page-break-after:auto;break-after:auto}
}
</style>
<main class="main-content"><div class="bi-page">
<div class="head"><div><h1>Cetak Buku Induk Masal</h1><p>Template cetak mengikuti format Buku Induk SDN Ciburayut 01 terbaru (3 halaman per siswa).</p></div></div>
<div class="card filter-card no-print"><form method="get" id="formPilihKelas"><div class="filters"><div><label class="lbl">Pilih Kelas</label><select class="fc" name="id_kelas" onchange="document.getElementById('formPilihKelas').submit()"><option value="0">Pilih Kelas</option><?php foreach($kelas as $k): $jml=0; $qj=mysqli_query($koneksi,"SELECT COUNT(*) jml FROM siswa WHERE id_kelas=".(int)$k['id_kelas']." AND status_siswa='Aktif'"); if($qj&&($rj=mysqli_fetch_assoc($qj)))$jml=(int)$rj['jml']; ?><option value="<?=h($k['id_kelas'])?>" <?=$id_kelas===(int)$k['id_kelas']?'selected':''?>><?=h($k['nama_kelas'])?><?php if(!empty($k['nama_wali_kelas']))echo' — '.h($k['nama_wali_kelas']);?> (<?=$jml?> siswa)</option><?php endforeach;?></select></div><button class="btn pri" type="submit">🔎 Tampilkan</button></div></form></div>
<?php if(!$kelas): ?><div class="card"><div class="info">Belum ada kelas aktif pada database.</div></div>
<?php elseif(!$id_kelas): ?><div class="card"><div class="info">Pilih kelas. Setiap siswa akan dicetak tepat 3 halaman sesuai template baru.</div></div>
<?php elseif(!$siswa): ?><div class="card"><div class="info">Kelas <?=h($kelas_terpilih['nama_kelas']??'')?> belum memiliki siswa aktif.</div></div>
<?php else: ?>
<div class="card no-print"><div class="info"><strong><?=count($siswa)?> siswa</strong> — <?=h($kelas_terpilih['nama_kelas']??'')?><?php if(!empty($kelas_terpilih['nama_wali_kelas']))echo' — Wali Kelas: '.h($kelas_terpilih['nama_wali_kelas']);?><br><button type="button" class="btn pri" style="margin-top:10px" onclick="window.print()">🖨️ Cetak Semua Buku Induk</button></div></div>
<div class="print-only">
<?php foreach($siswa as $s):
    $book=$bi[(int)$s['id_siswa']]??[];
    $d=array_merge($s,$book);
    $get=function($keys,$default='')use($d){return v($d,$keys,$default);};

    $photo='';
    $photoDb=$get(['foto'],'');
    if($photoDb){
        $candidate=__DIR__.'/../../'.ltrim(str_replace('\\','/',$photoDb),'/');
        if(is_file($candidate)) $photo='../../'.ltrim(str_replace('\\','/',$photoDb),'/');
    }
    if(!$photo){
        foreach(['jpg','jpeg','png','webp'] as $e){
            $candidate=__DIR__.'/../../assets/images/siswa/'.(int)$s['id_siswa'].'.'.$e;
            if(is_file($candidate)){ $photo='../../assets/images/siswa/'.(int)$s['id_siswa'].'.'.$e; break; }
        }
    }

    /* Nilai historis */
    $all=$nilai[(int)$s['id_siswa']]??[];
    $map=[]; $years=[];
    foreach($all as $n){
        $lvl=(int)($n['tingkat']??0);
        $sem=strtolower((string)($n['semester']??''));
        $semno=str_contains($sem,'genap')?'2':'1';
        $mk=norm_mapel($n['nama_mapel']??'');
        $score=$n['nilai_rapor']??$n['nilai_akhir']??'';
        if($lvl>=1&&$lvl<=6&&$mk){$map[$lvl][$semno][$mk]=$score; if(!empty($n['tahun_ajaran']))$years[$lvl]=$n['tahun_ajaran'];}
    }
    $activeYear=$get(['tahun_ajaran_aktif'],'');
    if(!$activeYear && !empty($kelas_terpilih['tahun_ajaran']))$activeYear=$kelas_terpilih['tahun_ajaran'];
    if(!$activeYear)$activeYear='2026/2027';

    $jk=$get(['jenis_kelamin'])==='P'?'Perempuan':($get(['jenis_kelamin'])==='L'?'Laki-laki':'');
    ?>
    <!-- HALAMAN 1 -->
    <div class="bi-sheet p1">
        <p class="bi-title">BUKU INDUK SISWA</p>
        <p class="bi-sub"><span>Nomor Induk : <?=h($get(['nis']))?></span><span>NISN : <?=h($get(['nisn']))?></span></p>
        <div class="bi-row">
            <div class="bi-col-main">
                <div class="item"><span class="no">1.</span> Nama Siswa</div>
                <div class="sub"><span class="b">o</span> Lengkap : <?=h($get(['nama_siswa']))?></div>
                <div class="sub"><span class="b">o</span> Panggilan : <?=h(first_name($get(['nama_siswa'])))?></div>
                <div class="item"><span class="no">2.</span> NIK : <?=h($get(['nik']))?></div>
                <div class="item"><span class="no">3.</span> Akta Lahir : <?=h($get(['no_registrasi_akta_lahir','no_akta']))?></div>
                <div class="item"><span class="no">4.</span> Jenis Kelamin : <?=h($jk)?></div>
                <div class="item"><span class="no">5.</span> Kelahiran</div>
                <div class="sub"><span class="b">o</span> Tanggal lahir : <?=h(tgl_id($get(['tanggal_lahir'])))?></div>
                <div class="sub"><span class="b">o</span> Tempat lahir : <?=h($get(['tempat_lahir']))?></div>
                <div class="item"><span class="no">6.</span> Agama : <?=h($get(['agama']))?></div>
                <div class="item"><span class="no">7.</span> Kewarganegaraan : <?=h($get(['kewarganegaraan']))?></div>
                <div class="item"><span class="no">8.</span> Anak Ke : <?=h($get(['anak_ke']))?></div>
                <div class="item"><span class="no">9.</span> Jumlah Saudara</div>
                <div class="sub"><span class="b">o</span> Kandung : <?=h($get(['jml_saudara_kandung']))?></div>
                <div class="sub"><span class="b">o</span> Tiri : -</div>
                <div class="sub"><span class="b">o</span> Angkat : -</div>
                <div class="item"><span class="no">10.</span> Bahasa sehari-hari di keluarga : <?=h($get(['bahasa_keluarga']))?></div>
                <div class="item"><span class="no">11.</span> Keadaan Jasmani</div>
                <div class="sub"><span class="b">o</span> Berat badan : <?=h($get(['berat_badan','berat']))?></div>
                <div class="sub"><span class="b">o</span> Tinggi badan : <?=h($get(['tinggi_badan','tinggi']))?></div>
                <div class="sub"><span class="b">o</span> Golongan darah : <?=h($get(['golongan_darah','goldar']))?></div>
                <div class="sub"><span class="b">o</span> Penyakit yang pernah diderita : <?=h($get(['penyakit_pernah_diderita','penyakit']))?></div>
                <div class="item"><span class="no">12.</span> Alamat : <?=h($get(['alamat']))?></div>
                <div class="item"><span class="no">13.</span> HP / WhatsApp Aktif : <?=h($get(['no_wa_aktif','hp','telepon']))?></div>
                <div class="item"><span class="no">14.</span> Jenis Tinggal : <?=h($get(['jenis_tinggal']))?></div>
                <div class="item"><span class="no">15.</span> Jarak tempat tinggal ke sekolah : <?=h($get(['jarak_rumah_ke_sekolah','jarak_rumah_km']))?> km</div>
            </div>
            <div class="photobox"><?php if($photo) echo '<img src="'.h($photo).'" onerror="this.style.display=\'none\'">'; ?></div>
        </div>

        <h3 class="sec">B. KETERANGAN ORANG TUA/WALI SISWA</h3>
        <div class="twocol">
            <div class="col">
                <b class="grp">Identitas Ayah</b>
                <div class="item"><span class="no">1.</span> Nama Ayah : <?=h($get(['nama_ayah']))?></div>
                <div class="item"><span class="no">2.</span> NIK Ayah : <?=h($get(['ayah_nik']))?></div>
                <div class="item"><span class="no">3.</span> Pendidikan Ayah : <?=h($get(['ayah_pendidikan']))?></div>
                <div class="item"><span class="no">4.</span> Pekerjaan Ayah : <?=h($get(['ayah_pekerjaan']))?></div>
                <b class="grp">Identitas Ibu</b>
                <div class="item"><span class="no">5.</span> Nama Ibu : <?=h($get(['nama_ibu']))?></div>
                <div class="item"><span class="no">6.</span> NIK Ibu : <?=h($get(['ibu_nik']))?></div>
            </div>
            <div class="col">
                <div class="item" style="margin-top:22pt"><span class="no">7.</span> Pendidikan Ibu : <?=h($get(['ibu_pendidikan']))?></div>
                <div class="item"><span class="no">8.</span> Pekerjaan Ibu : <?=h($get(['ibu_pekerjaan']))?></div>
                <b class="grp">Identitas Wali</b>
                <div class="item"><span class="no">9.</span> Nama Wali : <?=h($get(['nama_wali']))?></div>
                <div class="item"><span class="no">10.</span> NIK Wali : <?=h($get(['wali_nik']))?></div>
                <div class="item"><span class="no">11.</span> Pendidikan Wali : <?=h($get(['wali_pendidikan']))?></div>
                <div class="item"><span class="no">12.</span> Pekerjaan Wali : <?=h($get(['wali_pekerjaan']))?></div>
            </div>
        </div>
    </div>

    <!-- HALAMAN 2 -->
    <div class="bi-sheet p2">
        <h3 class="sec" style="margin-top:0">C. PERKEMBANGAN SISWA</h3>
        <div class="bi-row">
            <div class="bi-col-main">
                <div class="item"><span class="no">1.</span> Pendidikan Sebelumnya</div>
                <div class="sub"><span class="b">o</span> Masuk menjadi Siswa baru Tingkat I</div>
                <div class="sub" style="margin-left:52pt">▪ Asal Siswa : <?=h($get(['asal_siswa','asal_sekolah','sekolah_asal']))?></div>
                <div class="sub" style="margin-left:52pt">▪ Nama PAUD : <?=h($get(['nama_paud']))?></div>
                <div class="sub" style="margin-left:52pt">▪ Alamat : <?=h($get(['alamat_asal','alamat_paud']))?></div>
                <div class="sub" style="margin-left:52pt">▪ Tanggal dan Nomor Ijazah : <?=h($get(['tanggal_nomor_ijazah','nomor_ijazah','no_ijazah']))?></div>
                <div class="sub"><span class="b">o</span> Pindahan dari sekolah lain</div>
                <div class="sub" style="margin-left:52pt">▪ Nama sekolah asal : <?=h($get(['nama_sekolah_asal','asal_sekolah','sekolah_asal']))?></div>
                <div class="sub" style="margin-left:52pt">▪ Dari tingkat : <?=h($get(['dari_tingkat']))?></div>
                <div class="sub" style="margin-left:52pt">▪ Diterima tanggal : <?=h(tgl_id($get(['diterima_tanggal'])))?></div>
                <div class="sub" style="margin-left:52pt">▪ Di tingkat : <?=h($get(['di_tingkat']))?></div>
                <div class="item"><span class="no">2.</span> Prestasi Belajar : (di halaman berikut)</div>
                <div class="item"><span class="no">3.</span> Keadaan Jasmani</div>
                <?php
                $yrs=[]; for($lvl=1;$lvl<=6;$lvl++){ $yrs[$lvl]=!empty($years[$lvl])?substr((string)$years[$lvl],0,4):'20..'; }
                if(empty($years[1])) $yrs[1]=substr((string)$activeYear,0,4);
                ?>
                <table class="bi-jasmani">
                    <tr><th rowspan="2">No</th><th rowspan="2">Keterangan</th><th colspan="6">Tahun</th></tr>
                    <tr><?php for($i=1;$i<=6;$i++) echo '<th>'.h($yrs[$i]).'</th>'; ?></tr>
                    <?php
                    $rows=[
                        ['Berat badan','berat_badan',' kg'],
                        ['Tinggi badan','tinggi_badan',' cm'],
                        ['Lingkar Kepala','lingkar_kepala',' cm'],
                        ['Penyakit','penyakit',''],
                        ['Kelainan jasmani','kelainan_jasmani',''],
                    ];
                    foreach($rows as $ri=>$row): [$label,$field,$suf]=$row; ?>
                    <tr><td><?=$ri+1?></td><td class="ket"><?=h($label)?></td>
                    <?php for($i=1;$i<=6;$i++):
                        $val=$i===1 ? $get([$field.'_1',$field]) : $get([$field.'_'.$i]);
                        $val=trim((string)$val);
                        echo '<td>'.($val!==''?h($val).($field!=='penyakit'&&$field!=='kelainan_jasmani'?h($suf):''):'-').'</td>';
                    endfor; ?>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </div>
            <div class="photobox"><?php if($photo) echo '<img src="'.h($photo).'" onerror="this.style.display=\'none\'">'; ?></div>
        </div>

        <h3 class="sec">D. BEA SISWA</h3>
        <div class="item">• Jenis Bea Siswa : <?=h($get(['jenis_bea_siswa','beasiswa'],'-'))?></div>

        <h3 class="sec">E. MENINGGALKAN SEKOLAH</h3>
        <div class="item"><span class="no">1.</span> Tamat Belajar</div>
        <div class="sub"><span class="b">o</span> Tahun tamat : <?=h($get(['tahun_tamat'],'-'))?></div>
        <div class="sub"><span class="b">o</span> No. Ijazah : <?=h($get(['nomor_ijazah','no_ijazah'],'-'))?></div>
        <div class="sub"><span class="b">o</span> Melanjutkan ke sekolah : <?=h($get(['melanjutkan_ke_sekolah'],'-'))?><?php $mdi=$get(['melanjutkan_di']); if($mdi) echo ' di '.h($mdi); ?></div>
        <div class="item"><span class="no">2.</span> Pindah Sekolah</div>
        <div class="sub"><span class="b">o</span> Dari tingkat : <?=h($get(['pindah_dari_tingkat'],'-'))?></div>
        <div class="sub"><span class="b">o</span> Ke sekolah : <?=h($get(['pindah_ke_sekolah'],'-'))?></div>
        <div class="sub"><span class="b">o</span> Ke tingkat : <?=h($get(['pindah_ke_tingkat'],'-'))?></div>
        <div class="sub"><span class="b">o</span> Tanggal : <?=h(tgl_id($get(['tanggal_pindah'])) ?: '-')?></div>
        <div class="item"><span class="no">3.</span> Keluar Sekolah</div>
        <div class="sub"><span class="b">o</span> Tanggal : <?=h(tgl_id($get(['tanggal_keluar'])) ?: '-')?></div>
        <div class="sub"><span class="b">o</span> Alasan : <?=h($get(['alasan_keluar'],'-'))?></div>
        <div class="item" style="margin-top:10pt">• Catatan yang penting : <?=h($get(['catatan_penting','catatan_wali_kelas','catatan_wali','catatan'],'-'))?></div>
    </div>

    <!-- HALAMAN 3 -->
    <?php
    $subjectRows=[
        ['ppkn','PPKN'],['agama','Pendidikan Agama'],['bahasaindonesia','Bahasa Indonesia'],
        ['matematika','Matematika'],['ipa','Ilmu Pengetahuan Alam'],['ips','Ilmu Pengetahuan Sosial'],
        ['senibudaya','Seni Budaya'],['penjaskes','Penjaskes'],['bahasainggris','Bahasa Inggris'],['daerah','B. Daerah'],
    ];
    $abs=[];
    $sid=(int)$s['id_siswa'];
    $qa=mysqli_query($koneksi,"SELECT a.id_tahun_ajaran,ta.semester,a.status,COUNT(*) jml FROM absensi_siswa a LEFT JOIN tahun_ajaran ta ON ta.id_tahun_ajaran=a.id_tahun_ajaran WHERE a.id_siswa=$sid GROUP BY a.id_tahun_ajaran,ta.semester,a.status");
    if($qa) while($ar=mysqli_fetch_assoc($qa)) $abs[(int)$ar['id_tahun_ajaran']][strtolower((string)$ar['semester'])][strtolower((string)$ar['status'])]=(int)$ar['jml'];
    $taToCol=[];
    foreach($all as $n){$ta=(int)($n['id_tahun_ajaran']??0);$lvl=(int)($n['tingkat']??0);$sem=strtolower((string)($n['semester']??''));$sn=str_contains($sem,'genap')?2:1;if($lvl>=1&&$lvl<=6&&$ta)$taToCol[$lvl][$sn]=$ta;}
    function abshit($taToCol,$abs,$lvl,$sn){
        $ta=$taToCol[$lvl][$sn]??0; if(!$ta) return [0,0,0];
        $key=$sn===2?'genap':'gasal';
        return [$abs[$ta][$key]['sakit']??0,$abs[$ta][$key]['izin']??0,$abs[$ta][$key]['alpa']??0];
    }
    ?>
    <div class="bi-sheet p3">
        <p class="bi-title">PRESTASI BELAJAR</p>
        <table class="bi-prestasi">
            <tr><td class="left"><b>TAHUN AJARAN</b></td><?php for($lvl=1;$lvl<=6;$lvl++): ?><td colspan="2"><?=h($years[$lvl] ?? ($lvl===1?$activeYear:'..../....'))?></td><?php endfor; ?></tr>
            <tr><td class="left"><b>MATA PELAJARAN</b></td><td colspan="12">Nilai</td></tr>
            <tr><td></td><?php for($lvl=1;$lvl<=6;$lvl++): ?><td colspan="2"><b>Kelas <?=$lvl?></b></td><?php endfor; ?></tr>
            <tr><td></td><?php for($lvl=1;$lvl<=6;$lvl++): ?><td>S.1</td><td>S.2</td><?php endfor; ?></tr>
            <?php foreach($subjectRows as $ri=>$row): [$key,$label]=$row; ?>
            <tr><td class="left"><?=$ri+1?>. <?=h($label)?></td>
            <?php for($lvl=1;$lvl<=6;$lvl++): foreach([1,2] as $sem):
                $val=$map[$lvl][$sem][$key]??'';
                echo '<td>'.($val!==''?h($val):'').'</td>';
            endforeach; endfor; ?>
            </tr>
            <?php endforeach; ?>
            <tr><td class="left">11.</td><?php for($c=0;$c<12;$c++) echo '<td></td>'; ?></tr>
            <tr><td class="left">12.</td><?php for($c=0;$c<12;$c++) echo '<td></td>'; ?></tr>
            <tr class="grp"><td class="left">JUMLAH NILAI</td>
            <?php for($lvl=1;$lvl<=6;$lvl++): foreach([1,2] as $sem):
                $vals=[]; foreach($subjectRows as $row){$z=$map[$lvl][$sem][$row[0]]??''; if($z!==''&&is_numeric($z))$vals[]=(float)$z;}
                echo '<td>'.($vals?number_format(array_sum($vals),2,',','.'):'').'</td>';
            endforeach; endfor; ?>
            </tr>
            <tr class="grp"><td class="left">Nilai rata-rata</td>
            <?php for($lvl=1;$lvl<=6;$lvl++): foreach([1,2] as $sem):
                $vals=[]; foreach($subjectRows as $row){$z=$map[$lvl][$sem][$row[0]]??''; if($z!==''&&is_numeric($z))$vals[]=(float)$z;}
                echo '<td>'.($vals?number_format(array_sum($vals)/count($vals),2,',','.'):'').'</td>';
            endforeach; endfor; ?>
            </tr>
            <tr class="grp"><td class="left">RANGKING KELAS</td><?php for($lvl=1;$lvl<=6;$lvl++): $rk=$lvl===1||true?$get(['ranking_kelas','rangking_kelas']):''; ?><td colspan="2"><?=h($rk)?></td><?php endfor; ?></tr>
            <tr class="grp"><td class="left">LAIN-LAIN :</td><?php for($c=0;$c<12;$c++) echo '<td></td>'; ?></tr>
            <tr><td class="left">1. Kelakuan</td><?php for($lvl=1;$lvl<=6;$lvl++): ?><td colspan="2"><?=h($get(['kelakuan']))?></td><?php endfor; ?></tr>
            <tr><td class="left">2. Kerajinan</td><?php for($lvl=1;$lvl<=6;$lvl++): ?><td colspan="2"><?=h($get(['kerajinan']))?></td><?php endfor; ?></tr>
            <tr><td class="left">3. Kebersihan</td><?php for($lvl=1;$lvl<=6;$lvl++): ?><td colspan="2"><?=h($get(['kebersihan']))?></td><?php endfor; ?></tr>
            <tr class="grp"><td class="left">TIDAK HADIR :</td><?php for($c=0;$c<12;$c++) echo '<td></td>'; ?></tr>
            <tr><td class="left">- Sakit</td><?php for($lvl=1;$lvl<=6;$lvl++): foreach([1,2] as $sem){ [$sk,,]=abshit($taToCol,$abs,$lvl,$sem); echo '<td>'.($sk?:'').'</td>'; } endfor; ?></tr>
            <tr><td class="left">- Izin</td><?php for($lvl=1;$lvl<=6;$lvl++): foreach([1,2] as $sem){ [,$iz,]=abshit($taToCol,$abs,$lvl,$sem); echo '<td>'.($iz?:'').'</td>'; } endfor; ?></tr>
            <tr><td class="left">- Hal lain</td><?php for($lvl=1;$lvl<=6;$lvl++): foreach([1,2] as $sem){ [,,$al]=abshit($taToCol,$abs,$lvl,$sem); echo '<td>'.($al?:'').'</td>'; } endfor; ?></tr>
            <tr class="grp"><td class="left">NAIK / TIDAK NAIK TINGKAT</td><?php for($lvl=1;$lvl<=6;$lvl++): ?><td colspan="2"><?=h($get(['status_naik_tingkat']))?></td><?php endfor; ?></tr>
        </table>
        <div class="ttd">
            Cigombong, <?=date('d-m-Y')?><br>
            Kepala Sekolah<br>
            <span class="nm"><?=h($kepsek_nama)?></span><br>
            NIP. <?=h($kepsek_nip)?>
        </div>
    </div>
<?php endforeach; ?>
</div>
<?php endif; ?>
</div></main>
</body></html>
