<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator');
require_once "../../config/database.php";

$menu_aktif = 'buku';
$page_title = 'Buku Induk Siswa - SDN Ciburayut 01';

function h($v){ return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function val($row,$keys,$default=''){
    foreach((array)$keys as $k){
        if(isset($row[$k]) && trim((string)$row[$k])!=='') return $row[$k];
    }
    return $default;
}
function cleanv($v){
    $v=trim((string)($v ?? ''));
    return $v==='' ? null : $v;
}

/* Kolom Buku Induk yang benar-benar tersedia. */
$bi_cols=[];
$q=mysqli_query($koneksi,"SHOW COLUMNS FROM buku_induk");
if($q) while($r=mysqli_fetch_assoc($q)) $bi_cols[$r['Field']]=true;

$editable = [
    'tinggi_badan','berat_badan','lingkar_kepala','jarak_rumah_ke_sekolah',
    'golongan_darah','penyakit_pernah_diderita','kelainan_jasmani',
    'asal_sekolah','nomor_peserta_ujian','nomor_ijazah','tanggal_ijazah',
    'prestasi','catatan_wali_kelas','catatan_kepala_sekolah',
    'asal_siswa','nama_paud','alamat_asal','tanggal_nomor_ijazah','nama_sekolah_asal','dari_tingkat','diterima_tanggal','di_tingkat',
    'jenis_bea_siswa','tahun_tamat','melanjutkan_ke_sekolah','melanjutkan_di','pindah_dari_tingkat','pindah_ke_sekolah','pindah_ke_tingkat','tanggal_pindah','tanggal_keluar','alasan_keluar','catatan_penting',
    'ranking_kelas','rangking_kelas','kelakuan','kerajinan','kebersihan','status_naik_tingkat','kewarganegaraan',
    'berat_badan_1','berat_badan_2','berat_badan_3','berat_badan_4','berat_badan_5','berat_badan_6','tinggi_badan_1','tinggi_badan_2','tinggi_badan_3','tinggi_badan_4','tinggi_badan_5','tinggi_badan_6',
    'lingkar_kepala_1','lingkar_kepala_2','lingkar_kepala_3','lingkar_kepala_4','lingkar_kepala_5','lingkar_kepala_6','penyakit_1','penyakit_2','penyakit_3','penyakit_4','penyakit_5','penyakit_6','kelainan_jasmani_1','kelainan_jasmani_2','kelainan_jasmani_3','kelainan_jasmani_4','kelainan_jasmani_5','kelainan_jasmani_6'
];
$aliases = [
    'jarak_rumah_ke_sekolah'=>['jarak_rumah_ke_sekolah','jarak_rumah_km'],
    'nomor_peserta_ujian'=>['nomor_peserta_ujian','no_peserta_ujian'],
    'nomor_ijazah'=>['nomor_ijazah','no_ijazah']
];
$actual=[];
foreach($editable as $f){
    foreach(($aliases[$f] ?? [$f]) as $a){
        if(isset($bi_cols[$a])){ $actual[$f]=$a; break; }
    }
}

$id=(int)($_GET['id'] ?? $_POST['id_siswa'] ?? 0);
$msg=''; $msgtype='';

if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['aksi']??'')==='simpan'){
    if($id<=0){
        $msg='Siswa belum dipilih.'; $msgtype='error';
    }else{
        $cek=mysqli_prepare($koneksi,"SELECT id_siswa FROM siswa WHERE id_siswa=? LIMIT 1");
        if($cek){
            mysqli_stmt_bind_param($cek,'i',$id); mysqli_stmt_execute($cek);
            $rs=mysqli_stmt_get_result($cek);
            if(!$rs || !mysqli_num_rows($rs)){
                $msg='Data siswa tidak ditemukan.'; $msgtype='error';
            }else{
                $data=[]; $fields=[];
                foreach($actual as $logical=>$dbfield){
                    $fields[]=$dbfield; $data[] = cleanv($_POST[$logical] ?? '');
                }
                if(!$fields){
                    $msg='Tidak ada kolom Buku Induk yang tersedia pada database.'; $msgtype='error';
                }else{
                    $c=mysqli_prepare($koneksi,"SELECT id_buku_induk FROM buku_induk WHERE id_siswa=? LIMIT 1");
                    $ada=false;
                    if($c){mysqli_stmt_bind_param($c,'i',$id); mysqli_stmt_execute($c); $rr=mysqli_stmt_get_result($c); $ada=$rr && mysqli_num_rows($rr)>0;}
                    if($ada){
                        $set=implode(', ',array_map(fn($f)=>"`$f` = ?", $fields));
                        $types=str_repeat('s',count($fields)).'i';
                        $args=$data; $args[]=$id;
                        $st=mysqli_prepare($koneksi,"UPDATE buku_induk SET $set WHERE id_siswa=?");
                        if($st && mysqli_stmt_bind_param($st,$types,...$args) && mysqli_stmt_execute($st)){
                            header("Location: index.php?id=$id&ok=1"); exit;
                        }
                        $msg='Gagal menyimpan Buku Induk: '.mysqli_error($koneksi); $msgtype='error';
                    }else{
                        $cols='`id_siswa`'.($fields?', `'.implode('`, `',$fields).'`':'');
                        $marks=implode(',',array_fill(0,count($fields)+1,'?'));
                        $types='i'.str_repeat('s',count($fields));
                        $args=array_merge([$id],$data);
                        $st=mysqli_prepare($koneksi,"INSERT INTO buku_induk ($cols) VALUES ($marks)");
                        if($st && mysqli_stmt_bind_param($st,$types,...$args) && mysqli_stmt_execute($st)){
                            header("Location: index.php?id=$id&ok=1"); exit;
                        }
                        $msg='Gagal membuat Buku Induk: '.mysqli_error($koneksi); $msgtype='error';
                    }
                }
            }
        }
    }
}
if(isset($_GET['ok'])){$msg='Buku Induk berhasil disimpan.';$msgtype='success';}

/* Daftar siswa = satu-satunya sumber pemilihan siswa. */
$students=[];
$sql="SELECT s.*, k.nama_kelas, g.nama AS nama_wali_kelas
      FROM siswa s
      LEFT JOIN kelas k ON k.id_kelas=s.id_kelas
      LEFT JOIN guru g ON g.id_guru=k.id_wali_kelas
      WHERE s.status_siswa='Aktif'
      ORDER BY s.nama_siswa";
$q=mysqli_query($koneksi,$sql);
if($q) while($r=mysqli_fetch_assoc($q)) $students[]=$r;

$student=null; $master=[]; $book=[];
if($id>0){
    $st=mysqli_prepare($koneksi,"SELECT s.*, k.nama_kelas, k.tingkat, g.nama AS nama_wali_kelas
        FROM siswa s LEFT JOIN kelas k ON k.id_kelas=s.id_kelas
        LEFT JOIN guru g ON g.id_guru=k.id_wali_kelas
        WHERE s.id_siswa=? LIMIT 1");
    if($st){mysqli_stmt_bind_param($st,'i',$id);mysqli_stmt_execute($st);$r=mysqli_stmt_get_result($st);$student=$r?mysqli_fetch_assoc($r):null;}
    if($student){
        $master=$student;
        $b=mysqli_prepare($koneksi,"SELECT * FROM buku_induk WHERE id_siswa=? LIMIT 1");
        if($b){mysqli_stmt_bind_param($b,'i',$id);mysqli_stmt_execute($b);$r=mysqli_stmt_get_result($b);$book=$r?(mysqli_fetch_assoc($r)?:[]):[];}
    }
}

$total=count($students);
$filled=0;
if($total){
    $q=mysqli_query($koneksi,"SELECT COUNT(*) total FROM buku_induk b INNER JOIN siswa s ON s.id_siswa=b.id_siswa WHERE s.status_siswa='Aktif'");
    if($q) $filled=(int)(mysqli_fetch_assoc($q)['total']??0);
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>
<style>
.bi-wrap{max-width:1500px}.bi-head{display:flex;justify-content:space-between;gap:16px;align-items:center;margin-bottom:20px}
.bi-head h1{margin:0 0 5px}.bi-head p{margin:0;color:#64748b}
.bi-actions{display:flex;gap:8px;flex-wrap:wrap}.bi-btn{display:inline-flex;align-items:center;gap:7px;padding:10px 13px;border-radius:10px;text-decoration:none;font-weight:700;font-size:13px;border:1px solid #dbe4ef;background:#fff;color:#334155}
.bi-btn.primary{background:#1769d2;color:#fff;border-color:#1769d2}.bi-btn.green{background:#ecfdf5;color:#047857;border-color:#bbf7d0}
.bi-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:18px}.stat{background:#fff;border-radius:15px;padding:17px;box-shadow:0 7px 24px rgba(15,35,70,.07)}.stat b{font-size:26px}.stat span{display:block;color:#64748b;font-size:12px;margin-top:3px}
.bi-grid{display:grid;grid-template-columns:330px minmax(0,1fr);gap:18px}.panel{background:#fff;border-radius:17px;padding:18px;box-shadow:0 7px 24px rgba(15,35,70,.07)}
.search{width:100%;height:40px;border:1px solid #dbe4ef;border-radius:9px;padding:0 11px;margin-bottom:10px}.list{max-height:720px;overflow:auto}.student{display:block;text-decoration:none;color:#334155;padding:11px 12px;border-radius:10px;margin-bottom:6px;background:#f8fafc}.student:hover,.student.active{background:#eef5ff;color:#1769d2}.student strong{display:block}.student small{display:block;color:#64748b;margin-top:3px}
.ident{display:grid;grid-template-columns:110px 1fr;gap:7px 14px;background:#f8fafc;border:1px solid #e8eef6;border-radius:13px;padding:14px;margin-bottom:18px}.ident .label{font-size:12px;color:#64748b;font-weight:700}.ident .value{font-size:13px;font-weight:600;color:#17233c}
.notice{padding:12px 14px;border-radius:10px;margin-bottom:16px;font-size:13px}.success{background:#ecfdf3;color:#166534;border:1px solid #bbf7d0}.error{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
.section{font-weight:800;color:#1769d2;border-bottom:1px solid #e7edf5;padding:11px 0 7px;margin-top:6px}.section:first-child{margin-top:0}
.fields{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:13px;margin-top:12px}.field{display:flex;flex-direction:column;gap:6px}.field.full{grid-column:1/-1}.field label{font-size:12px;font-weight:700;color:#334155}.readonly{background:#f8fafc!important;color:#475569}.control{width:100%;min-height:40px;border:1px solid #dbe4ef;border-radius:9px;padding:8px 10px;font:inherit}.control:focus{outline:none;border-color:#2388f5;box-shadow:0 0 0 3px rgba(35,136,245,.1)}textarea.control{min-height:82px;resize:vertical}
.readonly-note{font-size:11px;color:#64748b;margin-top:8px}.actions{display:flex;gap:9px;margin-top:18px}
@media(max-width:1050px){.bi-grid{grid-template-columns:1fr}.list{max-height:320px}.fields{grid-template-columns:1fr 1fr}}@media(max-width:650px){.bi-head{display:block}.bi-actions{margin-top:12px}.bi-stats{grid-template-columns:1fr}.fields{grid-template-columns:1fr}.field.full{grid-column:auto}.ident{grid-template-columns:1fr}}
</style>

<main class="main-content"><div class="bi-wrap">
<div class="bi-head">
 <div><h1>📘 Buku Induk Siswa</h1><p>Format FIX terintegrasi dengan MASTER DATA SISWA dan struktur Dapodik.</p></div>
 <div class="bi-actions">
  <a class="bi-btn" href="cetak_masal.php">🖨️ Cetak Buku Induk Massal</a>
  <?php if($student): ?><a class="bi-btn green" target="_blank" href="cetak_masal.php?id_kelas=<?= (int)($student['id_kelas']??0) ?>">🖨️ Cetak Kelas</a><?php endif; ?>
 </div>
</div>

<?php if($msg): ?><div class="notice <?= $msgtype==='success'?'success':'error' ?>"><?= h($msg) ?></div><?php endif; ?>

<div class="bi-stats">
 <div class="stat"><b><?= $total ?></b><span>Siswa Aktif</span></div>
 <div class="stat"><b><?= $filled ?></b><span>Buku Induk Tersedia</span></div>
 <div class="stat"><b><?= max(0,$total-$filled) ?></b><span>Belum Memiliki Record Buku Induk</span></div>
</div>

<div class="bi-grid">
<div class="panel">
 <h2 style="margin:0 0 12px;font-size:17px">👨‍🎓 Pilih Siswa</h2>
 <input id="cari" class="search" placeholder="Cari nama, NIS, atau NISN...">
 <div class="list" id="listSiswa">
 <?php foreach($students as $s): ?>
  <a class="student <?= $id===(int)$s['id_siswa']?'active':'' ?>" data-key="<?= h(strtolower($s['nama_siswa'].' '.$s['nis'].' '.$s['nisn'])) ?>" href="index.php?id=<?= (int)$s['id_siswa'] ?>">
   <strong><?= h($s['nama_siswa']) ?></strong>
   <small><?= h($s['nis']?:'-') ?> · <?= h($s['nisn']?:'-') ?> · Kelas <?= h($s['nama_kelas']?:'-') ?></small>
  </a>
 <?php endforeach; ?>
 <?php if(!$students): ?><div style="padding:25px;text-align:center;color:#94a3b8">Belum ada siswa aktif.</div><?php endif; ?>
 </div>
</div>

<div class="panel">
<?php if(!$student): ?>
 <div style="padding:70px 20px;text-align:center;color:#94a3b8">Pilih siswa untuk membuka Buku Induk.</div>
<?php else: ?>

<h2 style="margin:0 0 12px;font-size:18px">Identitas Peserta Didik</h2>
<div class="ident">
 <div class="label">Nama Lengkap</div><div class="value"><?= h($student['nama_siswa']) ?></div>
 <div class="label">NIPD / NIS</div><div class="value"><?= h(val($student,['nis'],'-')) ?></div>
 <div class="label">NISN</div><div class="value"><?= h(val($student,['nisn'],'-')) ?></div>
 <div class="label">NIK</div><div class="value"><?= h(val($student,['nik'],'-')) ?></div>
 <div class="label">No. KK</div><div class="value"><?= h(val($student,['no_kk'],'-')) ?></div>
 <div class="label">Akta Lahir</div><div class="value"><?= h(val($student,['no_registrasi_akta_lahir','no_akta'],'-')) ?></div>
 <div class="label">Rombel Saat Ini</div><div class="value"><?= h(val($student,['rombel_dapodik','nama_kelas'],'-')) ?></div>
 <div class="label">Wali Kelas</div><div class="value"><?= h(val($student,['nama_wali_kelas'],'Belum ditentukan')) ?></div>
</div>

<form method="post">
<input type="hidden" name="aksi" value="simpan"><input type="hidden" name="id_siswa" value="<?= $id ?>">

<div class="section">A. KETERANGAN PESERTA DIDIK — DARI MASTER DATA SISWA</div>
<div class="fields">
<?php
$readonly_fields=[
 'nama_siswa'=>['Nama Lengkap',['nama_siswa']],
 'jenis_kelamin'=>['Jenis Kelamin (JK)',['jenis_kelamin']],
 'tempat_lahir'=>['Tempat Lahir',['tempat_lahir']],
 'tanggal_lahir'=>['Tanggal Lahir',['tanggal_lahir']],
 'agama'=>['Agama',['agama']],
 'kebutuhan_khusus'=>['Kebutuhan Khusus',['kebutuhan_khusus']],
 'anak_ke'=>['Anak ke-berapa',['anak_ke']],
 'jml_saudara_kandung'=>['Jumlah Saudara Kandung',['jml_saudara_kandung']],
 'jenis_tinggal'=>['Jenis Tinggal',['jenis_tinggal']],
 'alamat'=>['Alamat',['alamat']],
 'rt'=>['RT',['rt']], 'rw'=>['RW',['rw']],
 'kelurahan'=>['Desa/Kelurahan',['kelurahan']],
 'kecamatan'=>['Kecamatan',['kecamatan']], 'kode_pos'=>['Kode Pos',['kode_pos']],
 'telepon'=>['Telepon',['telepon']], 'hp'=>['HP / WhatsApp Aktif',['no_wa_aktif','hp']],
 'email'=>['Email',['email']],
];
foreach($readonly_fields as $k=>$cfg):
?>
<div class="field <?= in_array($k,['alamat'])?'full':'' ?>">
<label><?= h($cfg[0]) ?></label><input class="control readonly" readonly value="<?= h(val($master,$cfg[1],'-')) ?>">
</div>
<?php endforeach; ?>
</div>
<div class="readonly-note">🔒 Data identitas utama ditarik dari MASTER DATA SISWA. Perubahan dilakukan melalui menu Data Siswa/Dapodik agar tidak terjadi data ganda.</div>

<div class="section">B. KETERANGAN AYAH</div>
<div class="fields">
<?php foreach([
 ['Nama Ayah',['nama_ayah']],['NIK Ayah',['ayah_nik']],['Pekerjaan Ayah',['ayah_pekerjaan']],['Pendidikan Ayah',['ayah_pendidikan']],['Penghasilan Ayah',['ayah_penghasilan']],['Tahun Lahir Ayah',['ayah_tahun_lahir']]
] as $cfg): ?><div class="field"><label><?= h($cfg[0]) ?></label><input class="control readonly" readonly value="<?= h(val($master,$cfg[1],'-')) ?>"></div><?php endforeach; ?>
</div>

<div class="section">C. KETERANGAN IBU</div>
<div class="fields">
<?php foreach([
 ['Nama Ibu',['nama_ibu']],['NIK Ibu',['ibu_nik']],['Pekerjaan Ibu',['ibu_pekerjaan']],['Pendidikan Ibu',['ibu_pendidikan']],['Penghasilan Ibu',['ibu_penghasilan']],['Tahun Lahir Ibu',['ibu_tahun_lahir']]
] as $cfg): ?><div class="field"><label><?= h($cfg[0]) ?></label><input class="control readonly" readonly value="<?= h(val($master,$cfg[1],'-')) ?>"></div><?php endforeach; ?>
</div>

<div class="section">D. KETERANGAN WALI</div>
<div class="fields">
<?php foreach([
 ['Nama Wali',['nama_wali']],['NIK Wali',['wali_nik']],['Pekerjaan / Jabatan Wali',['wali_pekerjaan']],['Pendidikan Wali',['wali_pendidikan']],['Penghasilan Wali',['wali_penghasilan']],['Tahun Lahir Wali',['wali_tahun_lahir']]
] as $cfg): ?><div class="field"><label><?= h($cfg[0]) ?></label><input class="control readonly" readonly value="<?= h(val($master,$cfg[1],'-')) ?>"></div><?php endforeach; ?>
</div>

<div class="section">E. DATA PENDAFTARAN / RIWAYAT MASUK</div>
<div class="fields">
<?php foreach([
 ['Sekolah Asal','asal_sekolah',['sekolah_asal','asal_sekolah']],
 ['Nomor Peserta Ujian','nomor_peserta_ujian',['nomor_peserta_ujian','no_peserta_ujian','no_peserta_ujian']],
 ['No. Seri Ijazah','nomor_ijazah',['nomor_ijazah','no_ijazah']],
] as $cfg):
 $logical=$cfg[1]; $source=$cfg[2]; $v=val($master,$source,'');
?>
<div class="field"><label><?= h($cfg[0]) ?></label>
<?php if(isset($actual[$logical])): ?><input class="control" name="<?= h($logical) ?>" value="<?= h(val($book,[$actual[$logical]],$v)) ?>"><?php else: ?><input class="control readonly" readonly value="<?= h($v?:'-') ?>"><?php endif; ?>
</div>
<?php endforeach; ?>
</div>

<div class="section">F. DATA TAMBAHAN DAPODIK</div>
<div class="fields">
<?php foreach([
 ['Alat Transportasi',['alat_transportasi']],['Jarak Rumah ke Sekolah (KM)',['jarak_rumah_km']],['Penerima KIP',['penerima_kip']],['Nomor KIP',['nomor_kip']],['Nomor KKS',['nomor_kks']],['Kebutuhan Khusus',['kebutuhan_khusus']],['Sekolah Asal',['sekolah_asal','asal_sekolah']],['No. Registrasi Akta Lahir',['no_registrasi_akta_lahir','no_akta']],['Bank',['bank']],['Nomor Rekening Bank',['nomor_rekening_bank']],['Rekening Atas Nama',['rekening_atas_nama']],['Layak PIP',['layak_pip']],['Alasan Layak PIP',['alasan_layak_pip']],['Lintang',['lintang']],['Bujur',['bujur']]
] as $cfg): ?><div class="field"><label><?= h($cfg[0]) ?></label><input class="control readonly" readonly value="<?= h(val($master,$cfg[1],'-')) ?>"></div><?php endforeach; ?>
</div>

<div class="section">G. DATA FISIK & KESEHATAN</div>
<div class="fields">
<?php
$editFields=[
 'tinggi_badan'=>['Tinggi Badan (cm)','text',''],
 'berat_badan'=>['Berat Badan (kg)','text',''],
 'lingkar_kepala'=>['Lingkar Kepala (cm)','text',''],
 'jarak_rumah_ke_sekolah'=>['Jarak Rumah ke Sekolah','text',''],
 'golongan_darah'=>['Golongan Darah','text',''],
 'penyakit_pernah_diderita'=>['Penyakit yang Pernah Diderita','textarea',''],
 'kelainan_jasmani'=>['Kelainan Jasmani','textarea','']
];
foreach($editFields as $logical=>$cfg):
 if(!isset($actual[$logical])) continue;
 $dbf=$actual[$logical]; $v=val($book,[$dbf], val($master,$aliases[$logical]??[$logical],''));
?>
<div class="field <?= $cfg[1]==='textarea'?'full':'' ?>"><label><?= h($cfg[0]) ?></label>
<?php if($cfg[1]==='textarea'): ?><textarea class="control" name="<?= h($logical) ?>"><?= h($v) ?></textarea>
<?php else: ?><input class="control" name="<?= h($logical) ?>" value="<?= h($v) ?>"><?php endif; ?></div>
<?php endforeach; ?>
</div>

<div class="section">H. PERKEMBANGAN & CATATAN</div>
<div class="fields">
<?php foreach([
 'prestasi'=>['Prestasi'], 'catatan_wali_kelas'=>['Catatan Wali Kelas'], 'catatan_kepala_sekolah'=>['Catatan Kepala Sekolah']
] as $logical=>$cfg):
 if(!isset($actual[$logical])) continue; $v=val($book,[$actual[$logical]],'');
?>
<div class="field full"><label><?= h($cfg[0]) ?></label><textarea class="control" name="<?= h($logical) ?>"><?= h($v) ?></textarea></div>
<?php endforeach; ?>
</div>


<div class="section">I. DATA SESUAI TEMPLATE BUKU INDUK BARU</div>
<div class="fields">
<?php foreach([
 ['Kewarganegaraan','kewarganegaraan'],['Asal Siswa','asal_siswa'],['Nama PAUD','nama_paud'],['Alamat Pendidikan Sebelumnya','alamat_asal'],['Tanggal & Nomor Ijazah','tanggal_nomor_ijazah'],
 ['Nama Sekolah Asal','nama_sekolah_asal'],['Dari Tingkat','dari_tingkat'],['Diterima Tanggal','diterima_tanggal'],['Di Tingkat','di_tingkat'],['Jenis Bea Siswa','jenis_bea_siswa'],['Tahun Tamat','tahun_tamat'],['Melanjutkan ke Sekolah','melanjutkan_ke_sekolah'],['Melanjutkan di','melanjutkan_di'],
 ['Pindah dari Tingkat','pindah_dari_tingkat'],['Pindah ke Sekolah','pindah_ke_sekolah'],['Pindah ke Tingkat','pindah_ke_tingkat'],['Tanggal Pindah','tanggal_pindah'],['Tanggal Keluar','tanggal_keluar'],['Alasan Keluar','alasan_keluar'],['Catatan Penting','catatan_penting'],
 ['Ranking Kelas','ranking_kelas'],['Kelakuan','kelakuan'],['Kerajinan','kerajinan'],['Kebersihan','kebersihan'],['Naik/Tidak Naik Tingkat','status_naik_tingkat']
] as $cfg): $logical=$cfg[1]; if(!isset($actual[$logical])) continue; ?>
<div class="field <?= in_array($logical,['alamat_asal','catatan_penting'])?'full':'' ?>"><label><?=h($cfg[0])?></label><input class="control" name="<?=h($logical)?>" value="<?=h(val($book,[$actual[$logical]],''))?>"></div>
<?php endforeach; ?>
</div>
<div class="section">J. RIWAYAT KEADAAN JASMANI PER TAHUN</div>
<div class="fields">
<?php for($i=1;$i<=6;$i++): foreach([['Berat badan','berat_badan_'.$i],['Tinggi badan','tinggi_badan_'.$i],['Lingkar kepala','lingkar_kepala_'.$i],['Penyakit','penyakit_'.$i],['Kelainan jasmani','kelainan_jasmani_'.$i]] as $cfg): $logical=$cfg[1]; if(!isset($actual[$logical])) continue; ?>
<div class="field"><label><?=$cfg[0]?> Tahun <?=$i?></label><input class="control" name="<?=h($logical)?>" value="<?=h(val($book,[$actual[$logical]],''))?>"></div>
<?php endforeach; endfor; ?>
</div>
<div class="actions"><button class="bi-btn primary" type="submit">💾 Simpan Buku Induk</button><a class="bi-btn" href="index.php">Batal</a></div>
</form>

<?php endif; ?>
</div></div></div></main>
<script>
const c=document.getElementById('cari');
if(c)c.addEventListener('input',()=>{const k=c.value.toLowerCase().trim();document.querySelectorAll('.student').forEach(x=>x.style.display=(x.dataset.key||'').includes(k)?'block':'none')});
</script>
</body></html>
