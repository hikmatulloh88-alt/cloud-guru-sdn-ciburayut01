<?php
require_once __DIR__ . '/_init.php';

$bulan = $_GET['bulan'] ?? date('Y-m');
if (!preg_match('/^\d{4}-\d{2}$/', $bulan)) { $bulan = date('Y-m'); }

$rekap = [];
$st = mysqli_prepare(
    $koneksi,
    "SELECT tanggal, status, keterangan FROM absensi_siswa
     WHERE id_siswa = ? AND DATE_FORMAT(tanggal, '%Y-%m') = ?
     ORDER BY tanggal ASC"
);
mysqli_stmt_bind_param($st, 'is', $id_siswa_login, $bulan);
mysqli_stmt_execute($st);
$res = mysqli_stmt_get_result($st);
if ($res) { while ($r = mysqli_fetch_assoc($res)) { $rekap[] = $r; } }

$total = ['Hadir' => 0, 'Sakit' => 0, 'Izin' => 0, 'Alpa' => 0];
foreach ($rekap as $r) {
    if (isset($total[$r['status']])) { $total[$r['status']]++; }
}

portal_layout_start('Rekap Absensi', 'absensi');
?>
<h1>🗓️ Rekap Absensi Saya</h1>
<p class="portal-sub">Riwayat kehadiran pribadi. Pilih bulan untuk melihat periode lain.</p>

<form method="get" class="portal-filter">
    <label>Bulan</label>
    <input type="month" name="bulan" value="<?=ph($bulan)?>" onchange="this.form.submit()">
</form>

<div class="portal-stats">
    <div class="stat-card stat-hadir"><div class="stat-num"><?=$total['Hadir']?></div><div class="stat-label">Hadir</div></div>
    <div class="stat-card stat-sakit"><div class="stat-num"><?=$total['Sakit']?></div><div class="stat-label">Sakit</div></div>
    <div class="stat-card stat-izin"><div class="stat-num"><?=$total['Izin']?></div><div class="stat-label">Izin</div></div>
    <div class="stat-card stat-alpa"><div class="stat-num"><?=$total['Alpa']?></div><div class="stat-label">Alpa</div></div>
</div>

<div class="portal-card">
    <?php if (!$rekap): ?>
        <p class="portal-empty">Belum ada data absensi pada bulan ini.</p>
    <?php else: ?>
    <div class="portal-table-wrap">
    <table class="portal-table">
        <thead><tr><th>Tanggal</th><th>Status</th><th>Keterangan</th></tr></thead>
        <tbody>
        <?php foreach ($rekap as $r): ?>
            <tr>
                <td><?=date('d-m-Y', strtotime($r['tanggal']))?></td>
                <td><span class="badge badge-<?=strtolower($r['status'])?>"><?=ph($r['status'])?></span></td>
                <td><?=ph($r['keterangan'] ?: '-')?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php endif; ?>
</div>
<?php portal_layout_end(); ?>
