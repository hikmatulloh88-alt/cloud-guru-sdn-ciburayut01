<?php
require_once __DIR__ . '/../../config/auth.php';
wajib_login();
wajib_role('Siswa');
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/surat_izin.php';
surat_izin_bootstrap($koneksi);

function ph($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$id_siswa_login = (int)($_SESSION['id_siswa'] ?? 0);

if ($id_siswa_login <= 0) {
    http_response_code(403);
    die('Akun ini belum terhubung ke data siswa manapun. Hubungi Admin sekolah untuk menghubungkan akun.');
}

$siswa_login = null;
$st = mysqli_prepare(
    $koneksi,
    "SELECT s.*, k.nama_kelas, k.tingkat
     FROM siswa s
     LEFT JOIN kelas k ON k.id_kelas = s.id_kelas
     WHERE s.id_siswa = ?
     LIMIT 1"
);
mysqli_stmt_bind_param($st, 'i', $id_siswa_login);
mysqli_stmt_execute($st);
$res = mysqli_stmt_get_result($st);
$siswa_login = $res ? mysqli_fetch_assoc($res) : null;

if (!$siswa_login) {
    http_response_code(403);
    die('Data siswa untuk akun ini tidak ditemukan. Hubungi Admin sekolah.');
}

function portal_layout_start($title, $menu_aktif) {
    global $siswa_login;
    ?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?=htmlspecialchars($title)?> - Portal Siswa</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="portal-shell">

    <button type="button" id="portalMenuToggle" class="portal-menu-toggle" aria-label="Buka menu">☰</button>

    <aside class="portal-sidebar" id="portalSidebar">
        <div class="portal-brand">
            <div class="portal-brand-icon">🎓</div>
            <div>
                <div class="portal-brand-title">Portal Siswa</div>
                <div class="portal-brand-sub">SDN Ciburayut 01</div>
            </div>
        </div>
        <nav class="portal-nav">
            <a href="profil.php" class="<?= $menu_aktif==='profil' ? 'active' : '' ?>">👤 Profil Saya</a>
            <a href="kelas.php" class="<?= $menu_aktif==='kelas' ? 'active' : '' ?>">🏫 Data Kelas</a>
            <a href="absensi.php" class="<?= $menu_aktif==='absensi' ? 'active' : '' ?>">🗓️ Kehadiran</a>
            <a href="surat_izin.php" class="<?= $menu_aktif==='surat_izin' ? 'active' : '' ?>">📩 Surat Izin/Sakit</a>
        </nav>
        <div class="portal-user">
            <div class="portal-user-name"><?=htmlspecialchars($siswa_login['nama_siswa'])?></div>
            <div class="portal-user-kelas">Kelas <?=htmlspecialchars($siswa_login['nama_kelas'] ?: '-')?> &bull; NIS <?=htmlspecialchars($siswa_login['nis'] ?: '-')?></div>
            <a href="../../logout.php" class="portal-logout">🚪 Keluar</a>
        </div>
    </aside>

    <main class="portal-main">
    <?php
}

function portal_layout_end() {
    ?>
    </main>
</div>
<script>
(function(){
    var toggle = document.getElementById('portalMenuToggle');
    var sidebar = document.getElementById('portalSidebar');
    if (!toggle || !sidebar) return;
    toggle.addEventListener('click', function(){ sidebar.classList.toggle('open'); });
})();
</script>
</body>
</html>
    <?php
}
