<?php
require_once __DIR__ . '/../../config/auth.php';
wajib_login();
wajib_role('Siswa');
header('Location: absensi.php');
exit;
