<?php
require_once __DIR__ . '/_init.php';

/* Pastikan kolom kontak WhatsApp aktif tersedia pada database lama. */
$qc = mysqli_query($koneksi, "SHOW COLUMNS FROM siswa LIKE 'no_wa_aktif'");
if (!$qc || mysqli_num_rows($qc) === 0) {
    mysqli_query($koneksi, "ALTER TABLE siswa ADD COLUMN no_wa_aktif VARCHAR(25) NULL AFTER hp");
}

$alert = '';
$alert_type = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'simpan_profil') {
    $wa = trim((string)($_POST['no_wa_aktif'] ?? ''));
    // Simpan hanya angka, + dan spasi/dash diperbolehkan saat input.
    $wa_clean = preg_replace('/[^0-9+]/', '', $wa);

    if ($wa_clean !== '' && !preg_match('/^(?:\+62|62|0)[0-9]{8,15}$/', $wa_clean)) {
        $alert = 'Nomor WhatsApp belum valid. Gunakan contoh 081234567890 atau +6281234567890.';
        $alert_type = 'danger';
    } else {
        $up = mysqli_prepare($koneksi, "UPDATE siswa SET no_wa_aktif=? WHERE id_siswa=?");
        mysqli_stmt_bind_param($up, 'si', $wa_clean, $id_siswa_login);
        if (mysqli_stmt_execute($up)) {
            $alert = 'Nomor WhatsApp aktif berhasil disimpan. Nomor ini akan menjadi kontak utama untuk notifikasi sekolah.';
        } else {
            $alert = 'Nomor WhatsApp gagal disimpan. Silakan coba lagi.';
            $alert_type = 'danger';
        }
    }
}

/* Ambil ulang data terbaru. */
$st2 = mysqli_prepare($koneksi, "SELECT s.*, k.nama_kelas, k.tingkat FROM siswa s LEFT JOIN kelas k ON k.id_kelas=s.id_kelas WHERE s.id_siswa=? LIMIT 1");
mysqli_stmt_bind_param($st2, 'i', $id_siswa_login);
mysqli_stmt_execute($st2);
$r2 = mysqli_stmt_get_result($st2);
$siswa_login = $r2 ? mysqli_fetch_assoc($r2) : $siswa_login;

portal_layout_start('Profil Saya', 'profil');
?>
<style>
.profil-hero{display:flex;align-items:center;gap:18px;margin-bottom:20px}
.profil-avatar{width:82px;height:82px;border-radius:22px;background:linear-gradient(135deg,#2563eb,#0f1c3f);display:flex;align-items:center;justify-content:center;color:#fff;font-size:34px;font-weight:800;overflow:hidden;flex:none}
.profil-avatar img{width:100%;height:100%;object-fit:cover}
.profil-name{font-size:22px;font-weight:800;color:#0f1c3f;margin:0 0 4px}
.profil-meta{font-size:13px;color:#64748b}
.profil-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.profil-item{background:#f8fafc;border:1px solid #e6edf5;border-radius:12px;padding:13px 15px}
.profil-label{font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:#64748b;font-weight:700;margin-bottom:4px}
.profil-value{font-size:14px;font-weight:700;color:#1e293b}
.wa-box{margin-top:20px;border:1px solid #d7f0df;background:#f4fff7;border-radius:16px;padding:20px}
.wa-title{font-size:17px;font-weight:800;color:#17663b;margin-bottom:5px}
.wa-desc{font-size:13px;color:#557064;line-height:1.55;margin:0 0 16px}
.wa-input{width:100%;height:46px;border:1px solid #cfe2d5;border-radius:11px;padding:0 13px;font:inherit;background:#fff}
.wa-input:focus{outline:none;border-color:#22a55a;box-shadow:0 0 0 3px rgba(34,165,90,.1)}
.wa-note{font-size:12px;color:#64748b;margin-top:8px}
@media(max-width:700px){.profil-grid{grid-template-columns:1fr}.profil-hero{align-items:flex-start}.profil-avatar{width:70px;height:70px;font-size:28px}.profil-name{font-size:19px}}
</style>

<div class="profil-hero">
    <div class="profil-avatar">
        <?php
        $foto = trim((string)($siswa_login['foto_siswa'] ?? ''));
        if ($foto !== ''):
            $foto_url = '/' . ltrim('absensi_sd/' . $foto, '/');
        ?>
            <img src="<?=ph($foto_url)?>" alt="Foto siswa">
        <?php else: ?>
            👨‍🎓
        <?php endif; ?>
    </div>
    <div>
        <h1 class="profil-name">Profil Saya</h1>
        <div class="profil-meta"><?=ph($siswa_login['nama_siswa'])?> · Kelas <?=ph($siswa_login['nama_kelas'] ?: '-')?></div>
    </div>
</div>

<?php if ($alert): ?>
<div class="portal-alert portal-alert-<?=ph($alert_type)?>"><?=ph($alert)?></div>
<?php endif; ?>

<div class="portal-card">
    <h2>👤 Data Siswa</h2>
    <div class="profil-grid">
        <div class="profil-item"><div class="profil-label">Nama Lengkap</div><div class="profil-value"><?=ph($siswa_login['nama_siswa'])?></div></div>
        <div class="profil-item"><div class="profil-label">NIS</div><div class="profil-value"><?=ph($siswa_login['nis'] ?: '-')?></div></div>
        <div class="profil-item"><div class="profil-label">NISN</div><div class="profil-value"><?=ph($siswa_login['nisn'] ?: '-')?></div></div>
        <div class="profil-item"><div class="profil-label">Kelas / Rombel</div><div class="profil-value"><?=ph($siswa_login['nama_kelas'] ?: '-')?></div></div>
        <div class="profil-item"><div class="profil-label">Jenis Kelamin</div><div class="profil-value"><?=ph($siswa_login['jenis_kelamin'] ?: '-')?></div></div>
        <div class="profil-item"><div class="profil-label">Alamat</div><div class="profil-value"><?=ph($siswa_login['alamat'] ?: '-')?></div></div>
    </div>

    <div class="wa-box">
        <div class="wa-title">📱 Nomor WhatsApp Aktif</div>
        <p class="wa-desc">Masukkan satu nomor WhatsApp orang tua/wali yang aktif. Nomor ini menjadi <b>kontak utama</b> untuk informasi sekolah dan nantinya digunakan otomatis saat ada notifikasi kehadiran, termasuk status Alfa.</p>
        <form method="post" autocomplete="off">
            <input type="hidden" name="aksi" value="simpan_profil">
            <input class="wa-input" type="tel" name="no_wa_aktif" value="<?=ph($siswa_login['no_wa_aktif'] ?? '')?>" placeholder="Contoh: 081234567890" inputmode="tel" maxlength="18">
            <div class="wa-note">Format yang diterima: 08xxxxxxxxxx atau +628xxxxxxxxxx.</div>
            <button class="portal-btn" type="submit">💾 Simpan Nomor WhatsApp</button>
        </form>
    </div>
</div>

<?php portal_layout_end(); ?>
