<?php
require_once __DIR__ . '/_init.php';

$id_kelas_siswa = (int)($siswa_login['id_kelas'] ?? 0);
$info_kelas = null;
$daftar_teman = [];

if ($id_kelas_siswa > 0) {
    $q = mysqli_prepare(
        $koneksi,
        "SELECT k.nama_kelas, k.tingkat, k.id_tahun_ajaran,
                g.nama AS nama_wali, g.nip AS nip_wali,
                ta.tahun_ajaran, ta.semester
         FROM kelas k
         LEFT JOIN guru g ON g.id_guru = k.id_wali_kelas
         LEFT JOIN tahun_ajaran ta ON ta.id_tahun_ajaran = k.id_tahun_ajaran
         WHERE k.id_kelas = ?
         LIMIT 1"
    );
    mysqli_stmt_bind_param($q, 'i', $id_kelas_siswa);
    mysqli_stmt_execute($q);
    $res = mysqli_stmt_get_result($q);
    $info_kelas = $res ? mysqli_fetch_assoc($res) : null;

    $qt = mysqli_prepare(
        $koneksi,
        "SELECT nama_siswa, jenis_kelamin, nis, nisn
         FROM siswa
         WHERE id_kelas = ? AND status_siswa = 'Aktif'
         ORDER BY nama_siswa ASC"
    );
    mysqli_stmt_bind_param($qt, 'i', $id_kelas_siswa);
    mysqli_stmt_execute($qt);
    $rest = mysqli_stmt_get_result($qt);
    if ($rest) { while ($r = mysqli_fetch_assoc($rest)) { $daftar_teman[] = $r; } }
}

portal_layout_start('Data Kelas', 'kelas');
?>
<h1>🏫 Data Kelas</h1>
<p class="portal-sub">Informasi kelas dan teman sekelasmu saat ini.</p>

<?php if (!$info_kelas): ?>
    <div class="portal-card">
        <p class="portal-empty">Kamu belum terdaftar di kelas manapun. Hubungi wali kelas atau Admin sekolah.</p>
    </div>
<?php else: ?>
    <div class="portal-card">
        <h2>Informasi Kelas</h2>
        <div class="portal-table-wrap">
        <table class="portal-table">
            <tr><th style="width:180px">Kelas</th><td><?=ph($info_kelas['nama_kelas'] ?: '-')?></td></tr>
            <tr><th>Tingkat</th><td><?=ph($info_kelas['tingkat'] ?: '-')?></td></tr>
            <tr><th>Wali Kelas</th><td><?=ph($info_kelas['nama_wali'] ?: 'Belum ditentukan')?><?= $info_kelas['nip_wali'] ? ' (NIP: '.ph($info_kelas['nip_wali']).')' : '' ?></td></tr>
            <tr><th>Tahun Ajaran</th><td><?=ph(($info_kelas['tahun_ajaran'] ?? '') ? ($info_kelas['tahun_ajaran'] . ' - ' . ($info_kelas['semester'] ?? '')) : '-')?></td></tr>
        </table>
        </div>
    </div>

    <div class="portal-card">
        <h2>Teman Sekelas (<?=count($daftar_teman)?>)</h2>
        <?php if (!$daftar_teman): ?>
            <p class="portal-empty">Belum ada data teman sekelas.</p>
        <?php else: ?>
        <div class="portal-table-wrap">
        <table class="portal-table">
            <thead><tr><th>No</th><th>Nama</th><th>JK</th><th>NIS</th><th>NISN</th></tr></thead>
            <tbody>
            <?php foreach ($daftar_teman as $i => $t): ?>
                <tr>
                    <td><?=$i+1?></td>
                    <td><?=ph($t['nama_siswa'])?><?= ($t['nama_siswa'] === $siswa_login['nama_siswa']) ? ' <span class="mini">(kamu)</span>' : '' ?></td>
                    <td><?=ph($t['jenis_kelamin'])?></td>
                    <td><?=ph($t['nis'] ?: '-')?></td>
                    <td><?=ph($t['nisn'] ?: '-')?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php portal_layout_end(); ?>
