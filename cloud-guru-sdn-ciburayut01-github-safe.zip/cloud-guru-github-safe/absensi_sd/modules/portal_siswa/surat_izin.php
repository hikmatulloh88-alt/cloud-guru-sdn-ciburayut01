<?php
require_once __DIR__ . '/_init.php';

$alert = '';
$alert_type = 'success';

function simpan_file_surat($file_input, $id_siswa_login) {
    if (empty($_FILES[$file_input]) || $_FILES[$file_input]['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'error' => null, 'path' => null];
    }
    $ext = strtolower(pathinfo($_FILES[$file_input]['name'], PATHINFO_EXTENSION));
    $diizinkan = ['jpg', 'jpeg', 'png', 'pdf'];
    if (!in_array($ext, $diizinkan, true)) {
        return ['ok' => false, 'error' => 'Format file harus JPG, JPEG, PNG, atau PDF.', 'path' => null];
    }
    if ((int)$_FILES[$file_input]['size'] > 5 * 1024 * 1024) {
        return ['ok' => false, 'error' => 'Ukuran file maksimal 5 MB.', 'path' => null];
    }
    $folder = __DIR__ . '/../../uploads/surat_izin/';
    if (!is_dir($folder)) { @mkdir($folder, 0755, true); }
    $nama_file = 'surat_' . $id_siswa_login . '_' . date('YmdHis') . '_' . mt_rand(100, 999) . '.' . $ext;
    if (@move_uploaded_file($_FILES[$file_input]['tmp_name'], $folder . $nama_file)) {
        return ['ok' => true, 'error' => null, 'path' => 'uploads/surat_izin/' . $nama_file];
    }
    return ['ok' => false, 'error' => 'Gagal menyimpan file ke server.', 'path' => null];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'ajukan') {
    $tanggal = trim($_POST['tanggal_izin'] ?? '');
    $jenis = ($_POST['jenis'] ?? '') === 'Izin' ? 'Izin' : 'Sakit';
    $keterangan = trim($_POST['keterangan'] ?? '');

    if ($tanggal === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal)) {
        $alert = 'Tanggal wajib diisi dengan benar.';
        $alert_type = 'danger';
    } else {
        $file_relatif = null;
        if (!empty($_FILES['file_surat']) && $_FILES['file_surat']['error'] === UPLOAD_ERR_OK) {
            $hasil = simpan_file_surat('file_surat', $id_siswa_login);
            if (!$hasil['ok']) {
                $alert = $hasil['error'] ?: 'Gagal menyimpan file surat.';
                $alert_type = 'danger';
            } else {
                $file_relatif = $hasil['path'];
            }
        }
        if ($alert === '') {
            $stmt = mysqli_prepare($koneksi, "INSERT INTO surat_izin (id_siswa, tanggal_izin, jenis, keterangan, file_surat) VALUES (?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, 'issss', $id_siswa_login, $tanggal, $jenis, $keterangan, $file_relatif);
            if (mysqli_stmt_execute($stmt)) {
                $alert = 'Pengajuan ' . ($jenis === 'Izin' ? 'surat izin' : 'surat sakit') . ' berhasil dikirim. Menunggu persetujuan sekolah.';
                $alert_type = 'success';
            } else {
                $alert = 'Gagal menyimpan pengajuan.';
                $alert_type = 'danger';
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'upload_bukti') {
    $id_surat = (int)($_POST['id_surat'] ?? 0);
    $cek = mysqli_prepare($koneksi, "SELECT id_surat, file_surat FROM surat_izin WHERE id_surat = ? AND id_siswa = ? LIMIT 1");
    mysqli_stmt_bind_param($cek, 'ii', $id_surat, $id_siswa_login);
    mysqli_stmt_execute($cek);
    $res_cek = mysqli_stmt_get_result($cek);
    $milik = $res_cek ? mysqli_fetch_assoc($res_cek) : null;

    if (!$milik) {
        $alert = 'Pengajuan tidak ditemukan.';
        $alert_type = 'danger';
    } else {
        $hasil = simpan_file_surat('file_bukti', $id_siswa_login);
        if (!$hasil['ok']) {
            $alert = $hasil['error'] ?: 'Pilih file terlebih dahulu (JPG, JPEG, PNG, atau PDF).';
            $alert_type = 'danger';
        } else {
            $up = mysqli_prepare($koneksi, "UPDATE surat_izin SET file_surat = ? WHERE id_surat = ? AND id_siswa = ?");
            mysqli_stmt_bind_param($up, 'sii', $hasil['path'], $id_surat, $id_siswa_login);
            if (mysqli_stmt_execute($up)) {
                $alert = 'Bukti surat berhasil diunggah.';
                $alert_type = 'success';
            } else {
                $alert = 'Gagal menyimpan bukti surat.';
                $alert_type = 'danger';
            }
        }
    }
}

$riwayat = [];
$q = mysqli_prepare($koneksi, "SELECT * FROM surat_izin WHERE id_siswa = ? ORDER BY id_surat DESC");
mysqli_stmt_bind_param($q, 'i', $id_siswa_login);
mysqli_stmt_execute($q);
$res = mysqli_stmt_get_result($q);
if ($res) { while ($r = mysqli_fetch_assoc($res)) { $riwayat[] = $r; } }

portal_layout_start('Surat Izin/Sakit', 'surat_izin');
?>
<style>
.surat-type-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-bottom:18px}
.surat-type-option{position:relative}
.surat-type-option input{position:absolute;opacity:0;pointer-events:none}
.surat-type-label{display:block;padding:15px 16px;border:2px solid #e2e8f0;border-radius:14px;background:#fff;cursor:pointer;transition:.2s}
.surat-type-label strong{display:block;font-size:14px;color:#0f2747;margin-bottom:4px}.surat-type-label small{color:#64748b;font-size:12px}
.surat-type-option input:checked + label{border-color:#1976ed;background:#eff6ff;box-shadow:0 4px 14px rgba(25,118,237,.10)}
.surat-type-option.sakit input:checked + label{border-color:#ef4444;background:#fff1f2}
.upload-box{border:1px dashed #cbd5e1;border-radius:14px;padding:14px;background:#f8fafc}
.upload-actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.camera-btn{border:0;border-radius:10px;padding:10px 13px;background:#0f2747;color:#fff;font-weight:700;cursor:pointer}.file-input{max-width:100%}.upload-note{font-size:11px;color:#64748b;margin-top:7px}
.camera-modal{display:none;position:fixed;inset:0;background:rgba(15,23,42,.72);z-index:9999;align-items:center;justify-content:center;padding:18px}.camera-modal.open{display:flex}.camera-panel{width:min(520px,100%);background:#fff;border-radius:20px;padding:16px;box-shadow:0 20px 60px rgba(0,0,0,.3)}.camera-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}.camera-head h3{margin:0;color:#0f2747}.camera-close{border:0;background:#eef2f7;border-radius:10px;width:38px;height:38px;font-size:20px;cursor:pointer}.camera-video{width:100%;aspect-ratio:4/3;object-fit:cover;background:#0f172a;border-radius:14px}.camera-preview{width:100%;aspect-ratio:4/3;object-fit:contain;background:#f1f5f9;border-radius:14px;display:none}.camera-actions{display:flex;gap:8px;justify-content:flex-end;margin-top:12px;flex-wrap:wrap}.camera-action{border:0;border-radius:10px;padding:10px 14px;font-weight:700;cursor:pointer}.camera-capture{background:#1976ed;color:#fff}.camera-use{background:#16804a;color:#fff;display:none}.camera-retake{background:#eef2f7;color:#334155;display:none}
@media(max-width:650px){.surat-type-grid{grid-template-columns:1fr}.camera-panel{padding:12px}}
</style>

<h1>📩 Surat Izin / Sakit</h1>
<p class="portal-sub">Pilih jenis pengajuan, lampirkan surat bila ada, atau ambil foto surat langsung dengan kamera.</p>

<?php if ($alert): ?><div class="portal-alert portal-alert-<?=ph($alert_type)?>"><?=ph($alert)?></div><?php endif; ?>

<div class="portal-card">
    <h2>Ajukan Surat Baru</h2>
    <form method="post" enctype="multipart/form-data" class="portal-form" id="formSurat">
        <input type="hidden" name="aksi" value="ajukan">
        <div class="portal-field">
            <label>Tanggal</label>
            <input type="date" name="tanggal_izin" required>
        </div>
        <div class="portal-field portal-field-full">
            <label>Jenis Pengajuan</label>
            <div class="surat-type-grid">
                <div class="surat-type-option">
                    <input id="jenisIzin" type="radio" name="jenis" value="Izin" checked>
                    <label class="surat-type-label" for="jenisIzin"><strong>🟢 Surat Izin</strong><small>Untuk keperluan tidak masuk sekolah selain sakit.</small></label>
                </div>
                <div class="surat-type-option sakit">
                    <input id="jenisSakit" type="radio" name="jenis" value="Sakit">
                    <label class="surat-type-label" for="jenisSakit"><strong>🔴 Surat Sakit</strong><small>Untuk pengajuan karena kondisi kesehatan.</small></label>
                </div>
            </div>
        </div>
        <div class="portal-field portal-field-full">
            <label>Keterangan</label>
            <textarea name="keterangan" rows="3" placeholder="Contoh: ada keperluan keluarga / demam sejak semalam"></textarea>
        </div>
        <div class="portal-field portal-field-full">
            <label>📎 Lampiran Surat</label>
            <div class="upload-box">
                <div class="upload-actions">
                    <input class="file-input" id="fileSurat" type="file" name="file_surat" accept=".jpg,.jpeg,.png,.pdf,image/jpeg,image/png,application/pdf">
                    <button type="button" class="camera-btn" id="openCamera">📸 Ambil Foto dengan Kamera</button>
                </div>
                <div class="upload-note">JPG, PNG, atau PDF • Maks. 5 MB • Lampiran opsional dan dapat disusulkan.</div>
                <div id="cameraFileName" class="upload-note" style="display:none"></div>
            </div>
        </div>
        <div class="portal-field-full"><button type="submit" class="portal-btn">📤 Kirim Pengajuan</button></div>
    </form>
</div>

<div class="portal-card">
    <h2>Riwayat Pengajuan</h2>
    <?php if (!$riwayat): ?>
        <p class="portal-empty">Belum ada pengajuan surat.</p>
    <?php else: ?>
    <div class="portal-table-wrap"><table class="portal-table">
        <thead><tr><th>Tanggal</th><th>Jenis</th><th>Keterangan</th><th>File</th><th>Status</th></tr></thead>
        <tbody>
        <?php foreach ($riwayat as $r): ?>
            <tr>
                <td><?=date('d-m-Y', strtotime($r['tanggal_izin']))?></td>
                <td><?=ph($r['jenis'])?></td>
                <td><?=ph($r['keterangan'] ?: '-')?></td>
                <td>
                    <?php if ($r['file_surat']): ?>
                        <a href="../../<?=ph($r['file_surat'])?>" target="_blank" rel="noopener">Lihat</a>
                    <?php else: ?>
                        <form method="post" enctype="multipart/form-data" style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
                            <input type="hidden" name="aksi" value="upload_bukti"><input type="hidden" name="id_surat" value="<?=(int)$r['id_surat']?>">
                            <input type="file" name="file_bukti" accept=".jpg,.jpeg,.png,.pdf" style="max-width:150px;font-size:11px">
                            <button type="submit" class="portal-btn" style="padding:6px 10px;font-size:12px;margin:0">Upload</button>
                        </form>
                    <?php endif; ?>
                </td>
                <td><span class="badge badge-<?=strtolower($r['status'])?>"><?=ph($r['status'])?></span></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
    <?php endif; ?>
</div>

<div class="camera-modal" id="cameraModal" aria-hidden="true">
  <div class="camera-panel">
    <div class="camera-head"><h3>📸 Ambil Foto Surat</h3><button type="button" class="camera-close" id="closeCamera">×</button></div>
    <video class="camera-video" id="cameraVideo" autoplay playsinline></video>
    <canvas id="cameraCanvas" style="display:none"></canvas>
    <img class="camera-preview" id="cameraPreview" alt="Pratinjau foto surat">
    <div class="camera-actions">
      <button type="button" class="camera-action camera-retake" id="retakeCamera">↻ Ambil Ulang</button>
      <button type="button" class="camera-action camera-capture" id="captureCamera">📸 Ambil Foto</button>
      <button type="button" class="camera-action camera-use" id="useCamera">✓ Gunakan Foto</button>
    </div>
  </div>
</div>

<script>
(function(){
  const modal=document.getElementById('cameraModal'), video=document.getElementById('cameraVideo'), canvas=document.getElementById('cameraCanvas'), preview=document.getElementById('cameraPreview');
  const fileInput=document.getElementById('fileSurat'), note=document.getElementById('cameraFileName');
  const open=document.getElementById('openCamera'), close=document.getElementById('closeCamera'), capture=document.getElementById('captureCamera'), use=document.getElementById('useCamera'), retake=document.getElementById('retakeCamera');
  let stream=null, photoBlob=null;
  function stop(){if(stream){stream.getTracks().forEach(t=>t.stop());stream=null;} video.srcObject=null;}
  function resetPreview(){video.style.display='block';preview.style.display='none';capture.style.display='inline-block';use.style.display='none';retake.style.display='none';photoBlob=null;}
  async function start(){
    modal.classList.add('open'); modal.setAttribute('aria-hidden','false'); resetPreview();
    if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){alert('Kamera tidak tersedia di perangkat ini. Silakan gunakan tombol Pilih File.'); modal.classList.remove('open'); return;}
    try { stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false}); video.srcObject=stream; }
    catch(e){ alert('Kamera tidak dapat dibuka. Pastikan izin kamera diberikan pada browser.'); modal.classList.remove('open'); stop(); }
  }
  open.addEventListener('click',start);
  close.addEventListener('click',()=>{modal.classList.remove('open');modal.setAttribute('aria-hidden','true');stop();});
  modal.addEventListener('click',e=>{if(e.target===modal){modal.classList.remove('open');modal.setAttribute('aria-hidden','true');stop();}});
  capture.addEventListener('click',()=>{
    if(!video.videoWidth){alert('Tunggu kamera siap sebentar.');return;}
    canvas.width=video.videoWidth;canvas.height=video.videoHeight;canvas.getContext('2d').drawImage(video,0,0,canvas.width,canvas.height);
    canvas.toBlob(blob=>{photoBlob=blob;preview.src=URL.createObjectURL(blob);video.style.display='none';preview.style.display='block';capture.style.display='none';use.style.display='inline-block';retake.style.display='inline-block';},'image/jpeg',.88);
  });
  retake.addEventListener('click',resetPreview);
  use.addEventListener('click',()=>{
    if(!photoBlob)return;
    try{
      const dt=new DataTransfer();dt.items.add(new File([photoBlob],'foto_surat_'+Date.now()+'.jpg',{type:'image/jpeg'}));fileInput.files=dt.files;
      note.textContent='✓ Foto surat siap dikirim: '+fileInput.files[0].name;note.style.display='block';
      modal.classList.remove('open');modal.setAttribute('aria-hidden','true');stop();
    }catch(e){alert('Foto berhasil diambil, tetapi browser tidak mendukung pengisian file otomatis. Silakan gunakan Pilih File.');}
  });
  window.addEventListener('beforeunload',stop);
})();
</script>
<?php portal_layout_end(); ?>
