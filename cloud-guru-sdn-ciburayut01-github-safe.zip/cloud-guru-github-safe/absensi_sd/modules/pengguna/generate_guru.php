<?php
session_start();
require_once __DIR__ . '/../../config/auth.php';
wajib_login();
wajib_role('Admin');
require_once __DIR__ . '/../../config/database.php';

$menu_aktif = 'pengguna';

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function cbr_clean_name_for_username($nama) {
    $s = trim((string)$nama);
    if (function_exists('iconv')) {
        $x = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
        if ($x !== false) $s = $x;
    }
    $s = str_replace(['.', ',', ';', ':', '/', '\\', '(', ')', '[', ']', '{', '}', "'", '"', '-'], ' ', $s);
    $tokens = preg_split('/\\s+/', strtolower($s), -1, PREG_SPLIT_NO_EMPTY);
    $titles = [
        'dr','drs','dra','prof','h','hj','kh','ust','ustadz','ustaz',
        's','pd','sd','i','ag','kom','sos','si','se','sp','ip','m','mpd','msi','mkom','mm','mag','ma',
        'ama','amapd','sag','spd','spdsd','spdi','spd','skep','sh','mh','st','mt','skm','aip','aipda','ir'
    ];
    $clean=[];
    foreach ($tokens as $t) {
        if (in_array($t, $titles, true)) continue;
        // common compound degree tokens that can remain after punctuation removal
        if (preg_match('/^(s|m|a|d|dr|prof)(pd|sd|ag|si|kom|sos|se|ip|h|i|mh|mt)$/', $t)) continue;
        $clean[]=$t;
    }
    $s = implode('', $clean);
    $s = preg_replace('/[^a-z0-9]/', '', $s);
    return $s !== '' ? $s : 'pengguna';
}

function cbr_unique_username($koneksi, $base, $domain, $exclude_id=0, &$batch=[]) {
    $n=0;
    while (true) {
        $local = $base . ($n ? (string)($n+1) : '');
        $username = $local . $domain;
        if (isset($batch[$username])) { $n++; continue; }
        $sql = $exclude_id > 0 ? "SELECT id_user FROM users WHERE username=? AND id_user<>? LIMIT 1" : "SELECT id_user FROM users WHERE username=? LIMIT 1";
        $st=mysqli_prepare($koneksi,$sql);
        if ($exclude_id > 0) { mysqli_stmt_bind_param($st,'si',$username,$exclude_id); }
        else { mysqli_stmt_bind_param($st,'s',$username); }
        mysqli_stmt_execute($st); $r=mysqli_stmt_get_result($st);
        $exists = $r && mysqli_num_rows($r)>0;
        mysqli_stmt_close($st);
        if (!$exists) { $batch[$username]=true; return $username; }
        $n++;
    }
}


function ambil_guru_belum_akun($koneksi) {
    $daftar = [];
    $q = mysqli_query(
        $koneksi,
        "SELECT id_guru, nip, nama, jabatan
         FROM guru
         WHERE status = 'Aktif'
           AND id_guru NOT IN (SELECT id_guru FROM users WHERE id_guru IS NOT NULL)
         ORDER BY nama ASC"
    );
    if ($q) { while ($r = mysqli_fetch_assoc($q)) { $daftar[] = $r; } }
    return $daftar;
}

/* Buat saran username unik dari nama guru, hindari tabrakan dengan akun yang sudah ada
   maupun dengan saran lain di batch yang sama. */
function saran_username_guru($koneksi, $nama, array &$dipakai_batch) {
    $base = cbr_clean_name_for_username($nama);
    $domain = '@cbr.id';

    $username = $base . $domain;
    $n = 1;
    while (true) {
        if (in_array($username, $dipakai_batch, true)) {
            $n++; $username = $base . ($n + 1) . $domain; continue;
        }
        $cek = mysqli_prepare($koneksi, "SELECT id_user FROM users WHERE username = ? LIMIT 1");
        mysqli_stmt_bind_param($cek, 's', $username);
        mysqli_stmt_execute($cek);
        $res = mysqli_stmt_get_result($cek);
        if (!$res || mysqli_num_rows($res) === 0) { break; }
        $n++; $username = $base . ($n + 1) . $domain;
    }

    $dipakai_batch[] = $username;
    return $username;
}

$daftar_guru = ambil_guru_belum_akun($koneksi);

$alert = '';
$alert_type = 'success';
$hasil = [];
$lewat = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'generate_guru') {
    $pilih = $_POST['pilih'] ?? [];
    $usernames_input = $_POST['username'] ?? [];
    $password = (string)($_POST['password'] ?? 'guru123456');
    if ($password === '') $password = 'guru123456';
    $konfirmasi = (string)($_POST['konfirmasi'] ?? $password);

    if ($password === '') {
        $alert = 'Password wajib diisi.'; $alert_type = 'danger';
    } elseif (strlen($password) < 6) {
        $alert = 'Password minimal 6 karakter.'; $alert_type = 'danger';
    } elseif ($password !== $konfirmasi) {
        $alert = 'Konfirmasi password tidak sama dengan password.'; $alert_type = 'danger';
    } elseif (!is_array($pilih) || !$pilih) {
        $alert = 'Tidak ada guru yang dipilih.'; $alert_type = 'danger';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        foreach ($daftar_guru as $g) {
            if (empty($pilih[$g['id_guru']])) { continue; }

            $username = trim((string)($usernames_input[$g['id_guru']] ?? ''));
            if ($username === '') {
                $lewat[] = h($g['nama']) . ' — username tidak boleh kosong.';
                continue;
            }

            $cek = mysqli_prepare($koneksi, "SELECT id_user FROM users WHERE username = ? LIMIT 1");
            mysqli_stmt_bind_param($cek, 's', $username);
            mysqli_stmt_execute($cek);
            $res_cek = mysqli_stmt_get_result($cek);
            if ($res_cek && mysqli_num_rows($res_cek) > 0) {
                $lewat[] = h($g['nama']) . " — username \"$username\" sudah dipakai akun lain.";
                continue;
            }

            $ins = mysqli_prepare(
                $koneksi,
                "INSERT INTO users (username, password, nama, role, status, id_guru) VALUES (?, ?, ?, 'Guru', 'Aktif', ?)"
            );
            mysqli_stmt_bind_param($ins, 'sssi', $username, $hash, $g['nama'], $g['id_guru']);

            if (mysqli_stmt_execute($ins)) {
                $hasil[] = [
                    'nama' => $g['nama'],
                    'jabatan' => $g['jabatan'] ?: '-',
                    'username' => $username,
                    'password' => $password,
                ];
            } else {
                $lewat[] = h($g['nama']) . ' — gagal disimpan ke database.';
            }
        }

        if ($hasil) {
            $alert = count($hasil) . ' akun guru berhasil dibuat.' . ($lewat ? ' ' . count($lewat) . ' dilewati.' : '');
            $alert_type = 'success';
        } elseif ($lewat) {
            $alert = 'Tidak ada akun yang dibuat. Semua baris dilewati.';
            $alert_type = 'danger';
        }

        $daftar_guru = ambil_guru_belum_akun($koneksi);
    }
}

$dipakai_batch = [];
$saran = [];
foreach ($daftar_guru as $g) {
    $saran[$g['id_guru']] = saran_username_guru($koneksi, $g['nama'], $dipakai_batch);
}

include __DIR__ . '/../../includes/header.php';
include __DIR__ . '/../../includes/sidebar.php';
?>
<style>
.gen-page .wrap{width:100%;max-width:1100px;margin:0 auto}
.gen-page h1{margin:0;color:#17233c;font-size:26px}
.gen-page .sub{color:#64748b;margin:6px 0 20px;line-height:1.5}
.gen-page .back-link{display:inline-block;margin-bottom:16px;color:#1265dc;text-decoration:none;font-weight:600}
.card{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:22px;margin-bottom:20px}
.alert{padding:13px 15px;border-radius:11px;margin-bottom:18px;font-size:14px;line-height:1.5}
.alert.success{background:#ecfdf3;color:#18794e;border:1px solid #ccefdc}
.alert.danger{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
.note{padding:12px 14px;background:#eef6ff;border:1px solid #d8e8fb;color:#245c9b;border-radius:10px;font-size:13px;margin-bottom:16px}
.toolbar{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:14px}
.count{font-size:14px;color:#64748b}
.btn{border:0;border-radius:10px;padding:11px 16px;font-weight:600;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:6px}
.btn-primary{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff}
.btn-muted{background:#eef3f9;color:#334155}
.table-wrap{width:100%;overflow-x:auto}
.table{width:100%;min-width:680px;border-collapse:collapse;font-size:13px}
.table th,.table td{border:1px solid #dfe6ee;padding:10px 11px;text-align:left}
.table th{background:#f7f9fc;color:#526078;text-transform:uppercase;font-size:11px}
.table input[type=text]{width:100%;box-sizing:border-box;height:36px;border:1px solid #dbe4ef;border-radius:8px;padding:0 10px;font-size:13px}
.empty{text-align:center;color:#94a3b8;padding:40px 15px}
.lewat-list{margin:0;padding-left:18px;color:#92400e;font-size:13px;line-height:1.7}
.lewat-box{background:#fffaeb;border:1px solid #fde8b8;border-radius:10px;padding:12px 16px;margin-bottom:18px}
.pw-row{display:flex;gap:14px;flex-wrap:wrap;margin:16px 0}
.pw-row .field{flex:1;min-width:220px}
.pw-row label{display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:7px}
.pw-row input{width:100%;box-sizing:border-box;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 12px}
@media print{
 .sidebar,.no-print{display:none!important}
 .main-content{margin:0!important;padding:0!important}
}
</style>

<main class="main-content"><div class="gen-page"><div class="wrap">

    <a class="back-link no-print" href="index.php">&larr; Kembali ke Pengguna Aplikasi</a>

    <h1>🧑‍🏫 Generate Akun Guru</h1>
    <p class="sub">Membuat akun login untuk guru/karyawan aktif. Username otomatis dari nama tanpa gelar dengan domain <strong>@cbr.id</strong>. Password default: <strong>guru123456</strong>.</p>

    <?php if ($alert): ?>
        <div class="alert <?= h($alert_type) ?> no-print"><?= h($alert) ?></div>
    <?php endif; ?>

    <?php if ($lewat): ?>
        <div class="lewat-box no-print">
            <strong>Dilewati:</strong>
            <ul class="lewat-list">
                <?php foreach ($lewat as $pesan): ?><li><?= $pesan /* sudah di-escape saat dirakit */ ?></li><?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if ($hasil): ?>
        <div class="card">
            <div class="toolbar">
                <h3 style="margin:0">✅ Akun Baru Dibuat (<?= count($hasil) ?>)</h3>
                <button class="btn btn-primary no-print" onclick="window.print()">🖨️ Cetak Daftar</button>
            </div>
            <p class="sub" style="margin-top:0">Bagikan username &amp; password berikut ke masing-masing guru. Sarankan mengganti password setelah login pertama lewat menu "Ganti Password Saya".</p>
            <div class="table-wrap">
                <table class="table">
                    <thead><tr><th>#</th><th>Nama Guru</th><th>Jabatan</th><th>Username</th><th>Password</th></tr></thead>
                    <tbody>
                        <?php foreach ($hasil as $i => $r): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><?= h($r['nama']) ?></td>
                            <td><?= h($r['jabatan']) ?></td>
                            <td><strong><?= h($r['username']) ?></strong></td>
                            <td><?= h($r['password']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

    <div class="card no-print">
        <div class="note">
            ℹ️ Hanya guru/karyawan berstatus <strong>Aktif</strong> yang <strong>belum punya akun</strong> yang tampil di daftar ini.
            Username otomatis disarankan dari nama, silakan ubah kalau kurang cocok — sistem akan menolak kalau ternyata sudah dipakai.
        </div>

        <?php if (!$daftar_guru): ?>
            <div class="empty">🎉 Semua guru/karyawan aktif sudah memiliki akun.</div>
        <?php else: ?>
            <form method="post" id="formGenerateGuru">
                <input type="hidden" name="aksi" value="generate_guru">
                <div class="toolbar">
                    <label style="display:flex;align-items:center;gap:8px;font-weight:700;color:#334155;cursor:pointer">
                        <input type="checkbox" id="pilihSemuaGuru" checked style="width:17px;height:17px">
                        Pilih Semua
                    </label>
                    <div class="count"><?= count($daftar_guru) ?> guru/karyawan belum punya akun</div>
                </div>
                <div class="table-wrap">
                    <table class="table">
                        <thead><tr><th style="width:36px"></th><th>NIP</th><th>Nama</th><th>Jabatan</th><th>Username (bisa diubah)</th></tr></thead>
                        <tbody>
                            <?php foreach ($daftar_guru as $g): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="chk-guru" name="pilih[<?= (int)$g['id_guru'] ?>]"
                                           value="1" checked style="width:17px;height:17px">
                                </td>
                                <td><?= h($g['nip'] ?: '-') ?></td>
                                <td><?= h($g['nama']) ?></td>
                                <td><?= h($g['jabatan'] ?: '-') ?></td>
                                <td>
                                    <input type="text" name="username[<?= (int)$g['id_guru'] ?>]"
                                           value="<?= h($saran[$g['id_guru']]) ?>">
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="pw-row">
                    <div class="field">
                        <label>Password untuk semua akun terpilih</label>
                        <input type="text" name="password" value="guru123456" minlength="6" required>
                    </div>
                    <div class="field">
                        <label>Konfirmasi Password</label>
                        <input type="text" name="konfirmasi" value="guru123456" minlength="6" required>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">✨ Generate Akun Terpilih</button>
            </form>
        <?php endif; ?>
    </div>

</div></div></main>

<script>
(function(){
    var pilihSemua = document.getElementById('pilihSemuaGuru');
    if (!pilihSemua) return;
    pilihSemua.addEventListener('change', function(){
        document.querySelectorAll('.chk-guru').forEach(function(c){ c.checked = pilihSemua.checked; });
    });
})();
</script>
