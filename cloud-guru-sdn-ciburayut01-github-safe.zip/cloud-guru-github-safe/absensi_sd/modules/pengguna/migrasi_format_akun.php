<?php
session_start();
require_once __DIR__ . '/../../config/auth.php';
wajib_login(); wajib_role('Admin');
require_once __DIR__ . '/../../config/database.php';
function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}

function cbr_clean_name_for_username($nama) {
    $s = trim((string)$nama);
    if (function_exists('iconv')) {
        $x = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
        if ($x !== false) $s = $x;
    }
    $s = str_replace(['.', ',', ';', ':', '/', '\\', '(', ')', '[', ']', '{', '}', "'", '"', '-'], ' ', $s);
    $tokens = preg_split('/\\s+/', strtolower($s), -1, PREG_SPLIT_NO_EMPTY);
    $titles = [
        'dr','drs','dra','prof','h','hj','kh','ust','ustadz','ustaz',
        's','pd','sd','i','ag','kom','sos','si','se','sp','ip','m','mpd','msi','mkom','mm','mag','ma',
        'ama','amapd','sag','spd','spdsd','spdi','spd','skep','sh','mh','st','mt','skm','aip','aipda','ir'
    ];
    $clean=[];
    foreach ($tokens as $t) {
        if (in_array($t, $titles, true)) continue;
        // common compound degree tokens that can remain after punctuation removal
        if (preg_match('/^(s|m|a|d|dr|prof)(pd|sd|ag|si|kom|sos|se|ip|h|i|mh|mt)$/', $t)) continue;
        $clean[]=$t;
    }
    $s = implode('', $clean);
    $s = preg_replace('/[^a-z0-9]/', '', $s);
    return $s !== '' ? $s : 'pengguna';
}

function cbr_unique_username($koneksi, $base, $domain, $exclude_id=0, &$batch=[]) {
    $n=0;
    while (true) {
        $local = $base . ($n ? (string)($n+1) : '');
        $username = $local . $domain;
        if (isset($batch[$username])) { $n++; continue; }
        $sql = $exclude_id > 0 ? "SELECT id_user FROM users WHERE username=? AND id_user<>? LIMIT 1" : "SELECT id_user FROM users WHERE username=? LIMIT 1";
        $st=mysqli_prepare($koneksi,$sql);
        if ($exclude_id > 0) { mysqli_stmt_bind_param($st,'si',$username,$exclude_id); }
        else { mysqli_stmt_bind_param($st,'s',$username); }
        mysqli_stmt_execute($st); $r=mysqli_stmt_get_result($st);
        $exists = $r && mysqli_num_rows($r)>0;
        mysqli_stmt_close($st);
        if (!$exists) { $batch[$username]=true; return $username; }
        $n++;
    }
}

$pesan=''; $error=''; $preview=[]; $batch=[];
// Preview all linked teacher/student accounts. Only username/password are changed.
$q=mysqli_query($koneksi,"SELECT u.id_user,u.username,u.nama,u.role,u.id_guru,u.id_siswa,g.nama AS nama_guru,s.nama_siswa FROM users u LEFT JOIN guru g ON g.id_guru=u.id_guru LEFT JOIN siswa s ON s.id_siswa=u.id_siswa WHERE u.role IN ('Guru','Siswa') ORDER BY u.role,u.nama");
if($q){while($r=mysqli_fetch_assoc($q)){
  $nama = $r['role']==='Guru' ? ($r['nama_guru'] ?: $r['nama']) : ($r['nama_siswa'] ?: $r['nama']);
  $domain = $r['role']==='Guru' ? '@cbr.id' : '@cbr.siswa.id';
  $pw = $r['role']==='Guru' ? 'guru123456' : 'siswa123456';
  $base=cbr_clean_name_for_username($nama);
  $new=cbr_unique_username($koneksi,$base,$domain,(int)$r['id_user'],$batch);
  $preview[]=['id'=>(int)$r['id_user'],'role'=>$r['role'],'old'=>$r['username'],'new'=>$new,'pw'=>$pw,'nama'=>$nama];
}}
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['aksi']??'')==='terapkan'){
  $ok=0;$skip=0;$batch=[];
  foreach($preview as $p){
    $id=$p['id'];
    $nama=$p['nama']; $domain=$p['role']==='Guru'?'@cbr.id':'@cbr.siswa.id'; $pw=$p['role']==='Guru'?'guru123456':'siswa123456';
    $new=cbr_unique_username($koneksi,cbr_clean_name_for_username($nama),$domain,$id,$batch);
    $hash=password_hash($pw,PASSWORD_DEFAULT);
    $st=mysqli_prepare($koneksi,"UPDATE users SET username=?, password=? WHERE id_user=? LIMIT 1");
    mysqli_stmt_bind_param($st,'ssi',$new,$hash,$id);
    if(mysqli_stmt_execute($st)) $ok++; else $skip++;
    mysqli_stmt_close($st);
  }
  $pesan="$ok akun Guru/Siswa berhasil disesuaikan.".($skip?" $skip gagal.":'');
  // refresh preview after applying
  $preview=[]; $batch=[];
  $q=mysqli_query($koneksi,"SELECT u.id_user,u.username,u.nama,u.role,u.id_guru,u.id_siswa,g.nama AS nama_guru,s.nama_siswa FROM users u LEFT JOIN guru g ON g.id_guru=u.id_guru LEFT JOIN siswa s ON s.id_siswa=u.id_siswa WHERE u.role IN ('Guru','Siswa') ORDER BY u.role,u.nama");
  if($q){while($r=mysqli_fetch_assoc($q)){$nama=$r['role']==='Guru'?($r['nama_guru']?:$r['nama']):($r['nama_siswa']?:$r['nama']);$domain=$r['role']==='Guru'?'@cbr.id':'@cbr.siswa.id';$pw=$r['role']==='Guru'?'guru123456':'siswa123456';$preview[]=['id'=>(int)$r['id_user'],'role'=>$r['role'],'old'=>$r['username'],'new'=>$r['username'],'pw'=>$pw,'nama'=>$nama];}}
}
include __DIR__.'/../../includes/header.php'; include __DIR__.'/../../includes/sidebar.php';
?>
<style>
.wrap{max-width:1180px;margin:0 auto}.card{background:#fff;border-radius:18px;padding:22px;box-shadow:0 8px 25px rgba(15,35,70,.07);margin-bottom:18px}.head{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap}.head h1{margin:0;color:#17233c}.sub{color:#64748b;line-height:1.5}.note{background:#eef6ff;border:1px solid #d8e8fb;padding:13px;border-radius:10px;color:#245c9b}.btn{border:0;border-radius:9px;padding:10px 14px;font-weight:700;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:6px}.primary{background:#1265dc;color:#fff}.muted{background:#e9eef5;color:#334155}.table-wrap{overflow:auto}.table{width:100%;border-collapse:collapse;font-size:13px}.table th,.table td{border:1px solid #e1e7ef;padding:9px;text-align:left;white-space:nowrap}.table th{background:#f7f9fc;color:#526078;font-size:11px;text-transform:uppercase}.tag{padding:4px 8px;border-radius:999px;background:#eef4ff;color:#245c9b;font-weight:700;font-size:11px}.ok{padding:12px;background:#ecfdf5;color:#166534;border-radius:10px;margin-bottom:14px}
</style>
<main class="main-content"><div class="wrap">
<a class="btn muted" href="index.php">← Kembali ke Pengguna Aplikasi</a>
<div class="head"><div><h1>⚙️ Format Akun</h1><p class="sub">Menyesuaikan username Guru/Siswa tanpa mengubah data master. Gelar akademik tidak dimasukkan ke username.</p></div></div>
<?php if($pesan):?><div class="ok">✅ <?=h($pesan)?></div><?php endif;?>
<div class="card"><div class="note"><strong>Guru:</strong> nama tanpa gelar + <strong>@cbr.id</strong> &nbsp; | &nbsp; <strong>Siswa:</strong> nama tanpa gelar + <strong>@cbr.siswa.id</strong>. Password default masing-masing: <strong>guru123456</strong> dan <strong>siswa123456</strong>. Data siswa/guru tidak dihapus.</div></div>
<div class="card"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><h2 style="margin:0">Preview <?=count($preview)?> akun</h2><form method="post" onsubmit="return confirm('Terapkan format akun dan reset password semua akun Guru/Siswa?')"><input type="hidden" name="aksi" value="terapkan"><button class="btn primary" type="submit">🚀 Terapkan Perubahan</button></form></div><div class="table-wrap" style="margin-top:14px"><table class="table"><thead><tr><th>#</th><th>Role</th><th>Nama</th><th>Akun Lama</th><th>Akun Baru</th><th>Password</th></tr></thead><tbody>
<?php foreach($preview as $i=>$p):?><tr><td><?=$i+1?></td><td><span class="tag"><?=h($p['role'])?></span></td><td><?=h($p['nama'])?></td><td><?=h($p['old'])?></td><td><strong><?=h($p['new'])?></strong></td><td><?=h($p['pw'])?></td></tr><?php endforeach;?>
<?php if(!$preview):?><tr><td colspan="6" style="text-align:center;padding:30px;color:#94a3b8">Belum ada akun Guru/Siswa.</td></tr><?php endif;?></tbody></table></div></div>
</div></main></body></html>
