<?php
session_start();
require_once __DIR__ . '/../../config/auth.php';
wajib_login();
wajib_role('Admin');
require_once __DIR__ . '/../../config/database.php';

$menu_aktif = 'pengguna';
$page_title = 'Pengguna Aplikasi - SDN Ciburayut 01';

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$pesan = '';
$error = '';
$edit = null;

/* Pastikan kolom akun siswa tersedia pada instalasi lama. */
$cols = [];
$qcols = mysqli_query($koneksi, "SHOW COLUMNS FROM users");
if ($qcols) while ($c = mysqli_fetch_assoc($qcols)) $cols[$c['Field']] = true;
if (!isset($cols['id_siswa'])) {
    @mysqli_query($koneksi, "ALTER TABLE users ADD COLUMN id_siswa INT UNSIGNED NULL AFTER id_guru");
    $cols['id_siswa'] = true;
}
if (isset($cols['role'])) {
    $qr = mysqli_query($koneksi, "SHOW COLUMNS FROM users LIKE 'role'");
    $rc = $qr ? mysqli_fetch_assoc($qr) : null;
    if ($rc && stripos((string)$rc['Type'], "'Siswa'") === false) {
        @mysqli_query($koneksi, "ALTER TABLE users MODIFY COLUMN role ENUM('Admin','Operator','Guru','Siswa') NOT NULL DEFAULT 'Guru'");
    }
}

/* Tambah/edit akun. */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';

    if ($aksi === 'simpan') {
        $id = (int)($_POST['id_user'] ?? 0);
        $username = trim((string)($_POST['username'] ?? ''));
        $nama = trim((string)($_POST['nama'] ?? ''));
        $role = trim((string)($_POST['role'] ?? 'Guru'));
        $status = trim((string)($_POST['status'] ?? 'Aktif'));
        $password = (string)($_POST['password'] ?? '');
        $id_guru = (int)($_POST['id_guru'] ?? 0);
        $id_siswa = (int)($_POST['id_siswa'] ?? 0);

        if ($username === '' || $nama === '') $error = 'Username dan nama pengguna wajib diisi.';
        elseif (!in_array($role, ['Admin','Operator','Guru','Siswa'], true)) $error = 'Role tidak valid.';
        elseif (!in_array($status, ['Aktif','Tidak Aktif'], true)) $error = 'Status tidak valid.';
        elseif ($id === 0 && strlen($password) < 6) $error = 'Password akun baru minimal 6 karakter.';
        else {
            $cek = mysqli_prepare($koneksi, "SELECT id_user FROM users WHERE username=? AND id_user<>? LIMIT 1");
            mysqli_stmt_bind_param($cek, 'si', $username, $id);
            mysqli_stmt_execute($cek);
            $rr = mysqli_stmt_get_result($cek);
            if ($rr && mysqli_num_rows($rr)>0) $error = 'Username sudah digunakan.';
            mysqli_stmt_close($cek);

            if (!$error && $role === 'Guru') $id_siswa = 0;
            if (!$error && $role === 'Siswa') $id_guru = 0;
            if (!$error && $role === 'Admin' || !$error && $role === 'Operator') {
                $id_guru = 0; $id_siswa = 0;
            }

            if (!$error && $id > 0) {
                $sets = "username=?, nama=?, role=?, status=?, id_guru=?, id_siswa=?";
                $types = 'ssssii';
                $vals = [$username,$nama,$role,$status,$id_guru,$id_siswa];
                if ($password !== '') {
                    if (strlen($password)<6) $error='Password minimal 6 karakter.';
                    else { $sets .= ", password=?"; $types.='s'; $vals[] = password_hash($password,PASSWORD_DEFAULT); }
                }
                if (!$error) {
                    $sql="UPDATE users SET $sets WHERE id_user=? LIMIT 1";
                    $types.='i'; $vals[]=$id;
                    $st=mysqli_prepare($koneksi,$sql);
                    mysqli_stmt_bind_param($st,$types,...$vals);
                    if(mysqli_stmt_execute($st)) $pesan='Pengguna berhasil diperbarui.'; else $error='Gagal memperbarui pengguna: '.mysqli_error($koneksi);
                    mysqli_stmt_close($st);
                }
            } elseif (!$error) {
                $hash=password_hash($password,PASSWORD_DEFAULT);
                $st=mysqli_prepare($koneksi,"INSERT INTO users (username,password,nama,role,status,id_guru,id_siswa) VALUES (?,?,?,?,?,?,?)");
                mysqli_stmt_bind_param($st,'ssssiii',$username,$hash,$nama,$role,$status,$id_guru,$id_siswa);
                if(mysqli_stmt_execute($st)) $pesan='Pengguna berhasil ditambahkan.'; else $error='Gagal menambah pengguna: '.mysqli_error($koneksi);
                mysqli_stmt_close($st);
            }
        }
    }

    if ($aksi === 'hapus') {
        $id=(int)($_POST['id_user']??0);
        if($id === (int)($_SESSION['user_id']??0)) $error='Akun yang sedang dipakai tidak boleh dihapus.';
        else {
            $st=mysqli_prepare($koneksi,"DELETE FROM users WHERE id_user=? LIMIT 1");
            mysqli_stmt_bind_param($st,'i',$id);
            if(mysqli_stmt_execute($st)) $pesan='Pengguna berhasil dihapus.'; else $error='Gagal menghapus pengguna.';
            mysqli_stmt_close($st);
        }
    }
}

if (isset($_GET['edit'])) {
    $id=(int)$_GET['edit'];
    $st=mysqli_prepare($koneksi,"SELECT * FROM users WHERE id_user=? LIMIT 1");
    mysqli_stmt_bind_param($st,'i',$id); mysqli_stmt_execute($st);
    $res=mysqli_stmt_get_result($st); $edit=$res?mysqli_fetch_assoc($res):null;
    mysqli_stmt_close($st);
}

$guru=[]; $q=mysqli_query($koneksi,"SELECT id_guru,nip,nama FROM guru WHERE status='Aktif' ORDER BY nama");
if($q) while($r=mysqli_fetch_assoc($q)) $guru[]=$r;
$siswa=[]; $q=mysqli_query($koneksi,"SELECT id_siswa,nis,nama_siswa FROM siswa WHERE status_siswa='Aktif' ORDER BY nama_siswa");
if($q) while($r=mysqli_fetch_assoc($q)) $siswa[]=$r;

$users=[]; $q=mysqli_query($koneksi,"SELECT u.*,g.nama AS nama_guru,s.nama_siswa FROM users u LEFT JOIN guru g ON g.id_guru=u.id_guru LEFT JOIN siswa s ON s.id_siswa=u.id_siswa ORDER BY u.nama ASC");
if($q) while($r=mysqli_fetch_assoc($q)) $users[]=$r;

$total=count($users);
$guru_count=0;$siswa_count=0;
foreach($users as $u){ if($u['role']==='Guru')$guru_count++; if($u['role']==='Siswa')$siswa_count++; }

include __DIR__ . '/../../includes/header.php';
include __DIR__ . '/../../includes/sidebar.php';
?>
<style>
.pengguna-wrap{max-width:1180px;margin:0 auto}.head{display:flex;justify-content:space-between;gap:15px;align-items:flex-start;flex-wrap:wrap;margin-bottom:20px}.head h1{margin:0;color:#17233c;font-size:28px}.sub{color:#64748b;margin:6px 0 0}.grid{display:grid;grid-template-columns:380px 1fr;gap:18px}.card{background:#fff;border-radius:18px;padding:21px;box-shadow:0 8px 25px rgba(15,35,70,.07)}.card h2{margin:0 0 16px;color:#17233c;font-size:19px}.field{margin-bottom:13px}.field label{display:block;font-size:13px;font-weight:700;color:#334155;margin-bottom:6px}.field input,.field select{width:100%;height:40px;box-sizing:border-box;border:1px solid #dbe4ef;border-radius:9px;padding:0 11px}.row2{display:grid;grid-template-columns:1fr 1fr;gap:10px}.btn{border:0;border-radius:9px;padding:10px 14px;font-weight:700;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:6px}.primary{background:#1265dc;color:#fff}.muted{background:#e9eef5;color:#334155}.danger{background:#fee2e2;color:#b91c1c}.alert{padding:12px 14px;border-radius:10px;margin-bottom:16px}.ok{background:#ecfdf5;color:#166534}.err{background:#fff1f2;color:#be123c}.table-wrap{overflow:auto}.table{width:100%;border-collapse:collapse;font-size:13px}.table th,.table td{border:1px solid #e1e7ef;padding:9px;text-align:left;white-space:nowrap}.table th{background:#f7f9fc;color:#526078;font-size:11px;text-transform:uppercase}.actions{display:flex;gap:5px}.stats{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px}.stat{padding:7px 10px;border-radius:999px;background:#eef4ff;color:#245c9b;font-size:12px;font-weight:700}.quick{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px}.quick a{background:#eef4ff;color:#1265dc}.help{font-size:12px;color:#64748b;line-height:1.5;margin-top:8px}
@media(max-width:950px){.grid{grid-template-columns:1fr}}@media(max-width:520px){.row2{grid-template-columns:1fr}}
</style>
<main class="main-content"><div class="pengguna-wrap">
<div class="head"><div><h1>👥 Pengguna Aplikasi</h1><p class="sub">Kelola akun Admin, Operator, Guru, dan Siswa.</p></div><a class="btn muted" href="ganti_password.php">🔐 Ganti Password Saya</a></div>
<?php if($pesan):?><div class="alert ok">✅ <?=h($pesan)?></div><?php endif;?>
<?php if($error):?><div class="alert err">⚠️ <?=h($error)?></div><?php endif;?>

<div class="quick">
<a class="btn" href="generate_guru.php">🧑‍🏫 Generate Akun Guru</a>
<a class="btn" href="generate_siswa.php">🎓 Generate Akun Siswa</a>
<a class="btn" href="migrasi_format_akun.php">⚙️ Format Akun</a>
</div>

<div class="stats"><span class="stat">Total akun: <?=$total?></span><span class="stat">Akun Guru: <?=$guru_count?></span><span class="stat">Akun Siswa: <?=$siswa_count?></span></div>

<div class="grid">
<div class="card">
<h2><?=$edit?'✏️ Edit Pengguna':'➕ Tambah Pengguna'?></h2>
<form method="post">
<input type="hidden" name="aksi" value="simpan">
<input type="hidden" name="id_user" value="<?=$edit?(int)$edit['id_user']:0?>">
<div class="field"><label>Username</label><input name="username" required value="<?=h($edit['username']??'')?>"></div>
<div class="field"><label>Nama Pengguna</label><input name="nama" required value="<?=h($edit['nama']??'')?>"></div>
<div class="row2">
<div class="field"><label>Role</label><select name="role" id="role"><option value="Admin" <?=($edit['role']??'Guru')==='Admin'?'selected':''?>>Admin</option><option value="Operator" <?=($edit['role']??'Guru')==='Operator'?'selected':''?>>Operator</option><option value="Guru" <?=($edit['role']??'Guru')==='Guru'?'selected':''?>>Guru</option><option value="Siswa" <?=($edit['role']??'Guru')==='Siswa'?'selected':''?>>Siswa</option></select></div>
<div class="field"><label>Status</label><select name="status"><option value="Aktif" <?=($edit['status']??'Aktif')==='Aktif'?'selected':''?>>Aktif</option><option value="Tidak Aktif" <?=($edit['status']??'Aktif')==='Tidak Aktif'?'selected':''?>>Tidak Aktif</option></select></div>
</div>
<div class="field" id="guruBox"><label>Hubungkan ke Guru/Karyawan</label><select name="id_guru"><option value="0">-- Tidak dihubungkan --</option><?php foreach($guru as $g):?><option value="<?=$g['id_guru']?>" <?=((int)($edit['id_guru']??0)===(int)$g['id_guru'])?'selected':''?>><?=h($g['nama'])?><?= $g['nip']?' — '.h($g['nip']):''?></option><?php endforeach;?></select></div>
<div class="field" id="siswaBox"><label>Hubungkan ke Siswa</label><select name="id_siswa"><option value="0">-- Tidak dihubungkan --</option><?php foreach($siswa as $s):?><option value="<?=$s['id_siswa']?>" <?=((int)($edit['id_siswa']??0)===(int)$s['id_siswa'])?'selected':''?>><?=h($s['nama_siswa'])?><?= $s['nis']?' — NIS '.h($s['nis']):''?></option><?php endforeach;?></select></div>
<div class="field"><label>Password <?= $edit?'(kosongkan jika tidak diubah)':'' ?></label><input type="password" name="password" <?= $edit?'':'required minlength="6"' ?> minlength="6"></div>
<div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn primary" type="submit">💾 Simpan Pengguna</button><?php if($edit):?><a class="btn muted" href="index.php">Batal</a><?php endif;?></div>
</form>
<div class="help">Akun siswa harus terhubung ke data siswa agar Portal Siswa bisa membaca kelas dan absensinya.</div>
</div>

<div class="card"><h2>📋 Daftar Pengguna</h2>
<div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>Username</th><th>Nama</th><th>Role</th><th>Status</th><th>Terhubung</th><th>Aksi</th></tr></thead><tbody>
<?php foreach($users as $i=>$u):?>
<tr><td><?=$i+1?></td><td><strong><?=h($u['username'])?></strong></td><td><?=h($u['nama'])?></td><td><?=h($u['role'])?></td><td><?=h($u['status'])?></td><td><?=h($u['nama_guru']?:($u['nama_siswa']?:'-'))?></td>
<td><div class="actions"><a class="btn muted" href="?edit=<?=$u['id_user']?>">Edit</a><?php if((int)$u['id_user']!==(int)$_SESSION['user_id']):?><form method="post" onsubmit="return confirm('Hapus pengguna ini?')"><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id_user" value="<?=$u['id_user']?>"><button class="btn danger" type="submit">Hapus</button></form><?php endif;?></div></td></tr>
<?php endforeach;?>
<?php if(!$users):?><tr><td colspan="7" style="text-align:center;padding:30px;color:#94a3b8">Belum ada pengguna.</td></tr><?php endif;?>
</tbody></table></div></div>
</div>
</div></main>
<script>
(function(){
 const role=document.getElementById('role'), gb=document.getElementById('guruBox'), sb=document.getElementById('siswaBox');
 function sync(){const r=role.value;gb.style.display=(r==='Guru')?'block':'none';sb.style.display=(r==='Siswa')?'block':'none';}
 sync(); role.addEventListener('change',sync);
})();
</script>
</body></html>
