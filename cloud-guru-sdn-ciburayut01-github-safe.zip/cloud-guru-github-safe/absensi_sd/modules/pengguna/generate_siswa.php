<?php
session_start();
require_once __DIR__ . '/../../config/auth.php';
wajib_login();
wajib_role('Admin');
require_once __DIR__ . '/../../config/database.php';

$menu_aktif = 'pengguna';

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function cbr_clean_name_for_username($nama) {
    $s = trim((string)$nama);
    if (function_exists('iconv')) {
        $x = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
        if ($x !== false) $s = $x;
    }
    $s = str_replace(['.', ',', ';', ':', '/', '\\', '(', ')', '[', ']', '{', '}', "'", '"', '-'], ' ', $s);
    $tokens = preg_split('/\\s+/', strtolower($s), -1, PREG_SPLIT_NO_EMPTY);
    $titles = [
        'dr','drs','dra','prof','h','hj','kh','ust','ustadz','ustaz',
        's','pd','sd','i','ag','kom','sos','si','se','sp','ip','m','mpd','msi','mkom','mm','mag','ma',
        'ama','amapd','sag','spd','spdsd','spdi','spd','skep','sh','mh','st','mt','skm','aip','aipda','ir'
    ];
    $clean=[];
    foreach ($tokens as $t) {
        if (in_array($t, $titles, true)) continue;
        // common compound degree tokens that can remain after punctuation removal
        if (preg_match('/^(s|m|a|d|dr|prof)(pd|sd|ag|si|kom|sos|se|ip|h|i|mh|mt)$/', $t)) continue;
        $clean[]=$t;
    }
    $s = implode('', $clean);
    $s = preg_replace('/[^a-z0-9]/', '', $s);
    return $s !== '' ? $s : 'pengguna';
}

function cbr_unique_username($koneksi, $base, $domain, $exclude_id=0, &$batch=[]) {
    $n=0;
    while (true) {
        $local = $base . ($n ? (string)($n+1) : '');
        $username = $local . $domain;
        if (isset($batch[$username])) { $n++; continue; }
        $sql = $exclude_id > 0 ? "SELECT id_user FROM users WHERE username=? AND id_user<>? LIMIT 1" : "SELECT id_user FROM users WHERE username=? LIMIT 1";
        $st=mysqli_prepare($koneksi,$sql);
        if ($exclude_id > 0) { mysqli_stmt_bind_param($st,'si',$username,$exclude_id); }
        else { mysqli_stmt_bind_param($st,'s',$username); }
        mysqli_stmt_execute($st); $r=mysqli_stmt_get_result($st);
        $exists = $r && mysqli_num_rows($r)>0;
        mysqli_stmt_close($st);
        if (!$exists) { $batch[$username]=true; return $username; }
        $n++;
    }
}


/* Pastikan struktur tabel users mendukung akun siswa (role Siswa + kolom id_siswa). */
$kolom_users = [];
$qc = mysqli_query($koneksi, "SHOW COLUMNS FROM users");
if ($qc) { while ($c = mysqli_fetch_assoc($qc)) { $kolom_users[$c['Field']] = $c; } }

if (!isset($kolom_users['id_siswa'])) {
    mysqli_query($koneksi, "ALTER TABLE users ADD COLUMN id_siswa INT UNSIGNED NULL UNIQUE AFTER id_guru");
}
if (isset($kolom_users['role']) && stripos((string)$kolom_users['role']['Type'], "'siswa'") === false) {
    mysqli_query($koneksi, "ALTER TABLE users MODIFY COLUMN role ENUM('Admin','Operator','Guru','Siswa') NOT NULL DEFAULT 'Guru'");
}

function ambil_siswa_belum_akun($koneksi) {
    $daftar = [];
    $q = mysqli_query(
        $koneksi,
        "SELECT s.id_siswa, s.nis, s.nisn, s.nama_siswa, k.nama_kelas
         FROM siswa s
         LEFT JOIN kelas k ON k.id_kelas = s.id_kelas
         WHERE s.status_siswa = 'Aktif'
           AND s.id_siswa NOT IN (SELECT id_siswa FROM users WHERE id_siswa IS NOT NULL)
         ORDER BY k.tingkat ASC, k.nama_kelas ASC, s.nama_siswa ASC"
    );
    if ($q) { while ($r = mysqli_fetch_assoc($q)) { $daftar[] = $r; } }
    return $daftar;
}

$daftar_siswa = ambil_siswa_belum_akun($koneksi);

$alert = '';
$alert_type = 'success';
$hasil = [];
$lewat = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'generate_siswa') {
    $ids_dipilih = $_POST['id_siswa'] ?? [];
    if (!is_array($ids_dipilih)) { $ids_dipilih = []; }
    $ids_dipilih = array_map('strval', $ids_dipilih);

    foreach ($daftar_siswa as $s) {
        if (!in_array((string)$s['id_siswa'], $ids_dipilih, true)) { continue; }

        $nis = trim((string)$s['nis']);
        $nisn = trim((string)$s['nisn']);
        $base_user = cbr_clean_name_for_username($s['nama_siswa']);
        $username = cbr_unique_username($koneksi, $base_user, '@cbr.siswa.id');
        $password_default = 'siswa123456';

        if ($nis === '' || $nisn === '') {
            $lewat[] = h($s['nama_siswa']) . ' — NIS atau NISN belum diisi di Data Siswa.';
            continue;
        }

        $hash = password_hash($password_default, PASSWORD_DEFAULT);
        $ins = mysqli_prepare(
            $koneksi,
            "INSERT INTO users (username, password, nama, role, status, id_siswa) VALUES (?, ?, ?, 'Siswa', 'Aktif', ?)"
        );
        mysqli_stmt_bind_param($ins, 'sssi', $username, $hash, $s['nama_siswa'], $s['id_siswa']);

        if (mysqli_stmt_execute($ins)) {
            $hasil[] = [
                'nama' => $s['nama_siswa'],
                'kelas' => $s['nama_kelas'] ?: '-',
                'username' => $username,
                'password' => $password_default,
            ];
        } else {
            $lewat[] = h($s['nama_siswa']) . ' — gagal disimpan ke database.';
        }
    }

    if ($hasil) {
        $alert = count($hasil) . ' akun siswa berhasil dibuat.' . ($lewat ? ' ' . count($lewat) . ' siswa dilewati.' : '');
        $alert_type = 'success';
    } elseif ($lewat) {
        $alert = 'Tidak ada akun yang dibuat. Semua siswa yang dipilih dilewati.';
        $alert_type = 'danger';
    } else {
        $alert = 'Tidak ada siswa yang dipilih.';
        $alert_type = 'danger';
    }

    $daftar_siswa = ambil_siswa_belum_akun($koneksi);
}

include __DIR__ . '/../../includes/header.php';
include __DIR__ . '/../../includes/sidebar.php';
?>
<style>
.gen-page .wrap{width:100%;max-width:1100px;margin:0 auto}
.gen-page h1{margin:0;color:#17233c;font-size:26px}
.gen-page .sub{color:#64748b;margin:6px 0 20px;line-height:1.5}
.gen-page .back-link{display:inline-block;margin-bottom:16px;color:#1265dc;text-decoration:none;font-weight:600}
.card{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:22px;margin-bottom:20px}
.alert{padding:13px 15px;border-radius:11px;margin-bottom:18px;font-size:14px;line-height:1.5}
.alert.success{background:#ecfdf3;color:#18794e;border:1px solid #ccefdc}
.alert.danger{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
.note{padding:12px 14px;background:#eef6ff;border:1px solid #d8e8fb;color:#245c9b;border-radius:10px;font-size:13px;margin-bottom:16px}
.toolbar{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:14px}
.count{font-size:14px;color:#64748b}
.btn{border:0;border-radius:10px;padding:11px 16px;font-weight:600;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:6px}
.btn-primary{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff}
.btn-muted{background:#eef3f9;color:#334155}
.table-wrap{width:100%;overflow-x:auto}
.table{width:100%;min-width:640px;border-collapse:collapse;font-size:13px}
.table th,.table td{border:1px solid #dfe6ee;padding:10px 11px;text-align:left}
.table th{background:#f7f9fc;color:#526078;text-transform:uppercase;font-size:11px}
.empty{text-align:center;color:#94a3b8;padding:40px 15px}
.lewat-list{margin:0;padding-left:18px;color:#92400e;font-size:13px;line-height:1.7}
.lewat-box{background:#fffaeb;border:1px solid #fde8b8;border-radius:10px;padding:12px 16px;margin-bottom:18px}
@media print{
 .sidebar,.no-print{display:none!important}
 .main-content{margin:0!important;padding:0!important}
}
</style>

<main class="main-content"><div class="gen-page"><div class="wrap">

    <a class="back-link no-print" href="index.php">&larr; Kembali ke Pengguna Aplikasi</a>

    <h1>🎓 Generate Akun Siswa</h1>
    <p class="sub">Membuat akun login otomatis untuk siswa aktif yang belum punya akun. Username memakai nama tanpa gelar + @cbr.siswa.id, password default siswa123456.</p>

    <?php if ($alert): ?>
        <div class="alert <?= h($alert_type) ?> no-print"><?= h($alert) ?></div>
    <?php endif; ?>

    <?php if ($lewat): ?>
        <div class="lewat-box no-print">
            <strong>Dilewati:</strong>
            <ul class="lewat-list">
                <?php foreach ($lewat as $pesan): ?><li><?= $pesan /* sudah di-escape saat dirakit */ ?></li><?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if ($hasil): ?>
        <div class="card">
            <div class="toolbar">
                <h3 style="margin:0">✅ Akun Baru Dibuat (<?= count($hasil) ?>)</h3>
                <button class="btn btn-primary no-print" onclick="window.print()">🖨️ Cetak Daftar</button>
            </div>
            <p class="sub" style="margin-top:0">Bagikan username &amp; password berikut ke masing-masing siswa. Sarankan siswa mengganti password setelah login pertama.</p>
            <div class="table-wrap">
                <table class="table">
                    <thead><tr><th>#</th><th>Nama Siswa</th><th>Kelas</th><th>Username</th><th>Password</th></tr></thead>
                    <tbody>
                        <?php foreach ($hasil as $i => $r): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><?= h($r['nama']) ?></td>
                            <td><?= h($r['kelas']) ?></td>
                            <td><strong><?= h($r['username']) ?></strong></td>
                            <td><?= h($r['password']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

    <div class="card no-print">
        <div class="note">
            ℹ️ Hanya siswa berstatus <strong>Aktif</strong> yang <strong>NIS dan NISN-nya sudah lengkap</strong> di menu Data Siswa yang bisa dibuatkan akun.
            Siswa yang sudah punya akun tidak akan tampil lagi di daftar ini.
        </div>

        <?php if (!$daftar_siswa): ?>
            <div class="empty">🎉 Semua siswa aktif sudah memiliki akun, atau belum ada siswa aktif dengan NIS/NISN lengkap.</div>
        <?php else: ?>
            <form method="post" id="formGenerateSiswa">
                <input type="hidden" name="aksi" value="generate_siswa">
                <div class="toolbar">
                    <label style="display:flex;align-items:center;gap:8px;font-weight:700;color:#334155;cursor:pointer">
                        <input type="checkbox" id="pilihSemuaSiswa" checked style="width:17px;height:17px">
                        Pilih Semua
                    </label>
                    <div class="count"><?= count($daftar_siswa) ?> siswa belum punya akun</div>
                </div>
                <div class="table-wrap">
                    <table class="table">
                        <thead><tr><th style="width:36px"></th><th>Nama Siswa</th><th>Kelas</th><th>NIS (username)</th><th>NISN (password)</th></tr></thead>
                        <tbody>
                            <?php foreach ($daftar_siswa as $s): ?>
                            <?php $lengkap = trim((string)$s['nis']) !== '' && trim((string)$s['nisn']) !== ''; ?>
                            <tr style="<?= $lengkap ? '' : 'opacity:.55' ?>">
                                <td>
                                    <input type="checkbox" class="chk-siswa" name="id_siswa[]"
                                           value="<?= (int)$s['id_siswa'] ?>"
                                           <?= $lengkap ? 'checked' : 'disabled' ?>
                                           style="width:17px;height:17px">
                                </td>
                                <td><?= h($s['nama_siswa']) ?></td>
                                <td><?= h($s['nama_kelas'] ?: '-') ?></td>
                                <td><?= $s['nis'] !== '' ? h($s['nis']) : '<span style="color:#be123c">kosong</span>' ?></td>
                                <td><?= $s['nisn'] !== '' ? h($s['nisn']) : '<span style="color:#be123c">kosong</span>' ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div style="margin-top:16px">
                    <button type="submit" class="btn btn-primary">✨ Generate Akun Terpilih</button>
                </div>
            </form>
        <?php endif; ?>
    </div>

</div></div></main>

<script>
(function(){
    var pilihSemua = document.getElementById('pilihSemuaSiswa');
    if (!pilihSemua) return;
    pilihSemua.addEventListener('change', function(){
        document.querySelectorAll('.chk-siswa:not(:disabled)').forEach(function(c){ c.checked = pilihSemua.checked; });
    });
})();
</script>
