<?php
session_start();
require_once __DIR__ . '/config/database.php';

if (!empty($_SESSION['login_user']) && !empty($_SESSION['user_id'])) {
    if (strtolower((string)($_SESSION['role'] ?? '')) === 'siswa') {
        header('Location: modules/portal_siswa/');
    } else {
        header('Location: index.php');
    }
    exit;
}

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function find_col($columns, $names){
    foreach($names as $n) if(isset($columns[$n])) return $n;
    return null;
}

$columns = [];
$res = mysqli_query($koneksi, "SHOW COLUMNS FROM users");
if ($res) while ($c = mysqli_fetch_assoc($res)) $columns[$c['Field']] = $c;

$user_col   = find_col($columns, ['username','user','email']);
$pass_col   = find_col($columns, ['password','pass']);
$status_col = find_col($columns, ['status','aktif','is_active']);
$role_col   = find_col($columns, ['role','level']);
$name_col   = find_col($columns, ['nama','nama_user','name']);
$guru_col   = find_col($columns, ['id_guru']);
$siswa_col  = find_col($columns, ['id_siswa']);
$id_col     = find_col($columns, ['id_user','id']);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    if (!$user_col || !$pass_col || !$id_col) {
        $error = 'Struktur tabel users belum sesuai untuk login.';
    } elseif ($username === '' || $password === '') {
        $error = 'Username dan password wajib diisi.';
    } else {
        $stmt = mysqli_prepare($koneksi, "SELECT * FROM users WHERE `$user_col` = ? LIMIT 1");
        if (!$stmt) {
            $error = 'Login gagal: '.mysqli_error($koneksi);
        } else {
            mysqli_stmt_bind_param($stmt, 's', $username);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $user = $result ? mysqli_fetch_assoc($result) : null;
            mysqli_stmt_close($stmt);

            if (!$user) {
                $error = 'Username atau password salah.';
            } else {
                $status_ok = true;
                if ($status_col) {
                    $status = strtolower(trim((string)($user[$status_col] ?? '')));
                    $status_ok = in_array($status, ['', 'aktif', 'active', '1', 'ya'], true);
                }

                if (!$status_ok) {
                    $error = 'Akun sedang tidak aktif.';
                } else {
                    $password_db = (string)($user[$pass_col] ?? '');
                    $password_ok = password_verify($password, $password_db);

                    // Kompatibel dengan akun lama plain-text; setelah login langsung di-hash.
                    if (!$password_ok && $password_db !== '' && hash_equals($password_db, $password)) {
                        $password_ok = true;
                        $new_hash = password_hash($password, PASSWORD_DEFAULT);
                        $up = mysqli_prepare($koneksi, "UPDATE users SET `$pass_col` = ? WHERE `$id_col` = ? LIMIT 1");
                        if ($up) {
                            $uid = (int)($user[$id_col] ?? 0);
                            mysqli_stmt_bind_param($up, 'si', $new_hash, $uid);
                            mysqli_stmt_execute($up);
                            mysqli_stmt_close($up);
                        }
                    }

                    if (!$password_ok) {
                        $error = 'Username atau password salah.';
                    } else {
                        $role_value = strtolower(trim((string)($user[$role_col] ?? '')));
                        $role_map = [
                            'admin' => 'Admin',
                            'administrator' => 'Admin',
                            'operator' => 'Operator',
                            'guru' => 'Guru',
                            'siswa' => 'Siswa',
                            'student' => 'Siswa',
                            'murid' => 'Siswa',
                        ];

                        if (!isset($role_map[$role_value])) {
                            $error = 'Role akun tidak dikenali. Hubungi Admin untuk memperbaiki role akun.';
                        } else {
                            session_regenerate_id(true);
                            $_SESSION['login_user'] = true;
                            $_SESSION['user_id'] = (int)($user[$id_col] ?? 0);
                            $_SESSION['username'] = $user[$user_col] ?? $username;
                            $_SESSION['nama_user'] = $name_col ? ($user[$name_col] ?? $username) : $username;
                            $_SESSION['role'] = $role_map[$role_value];
                            $_SESSION['id_guru'] = $guru_col ? ($user[$guru_col] ?? null) : null;
                            $_SESSION['id_siswa'] = $siswa_col ? ($user[$siswa_col] ?? null) : null;

                            if ($_SESSION['role'] === 'Siswa') {
                                header('Location: modules/portal_siswa/');
                            } else {
                                header('Location: index.php');
                            }
                            exit;
                        }
                    }
                }
            }
        }
    }
}

$nama_sekolah = 'SDN CIBURAYUT 01';
$logo = '';
$rp = mysqli_query($koneksi, "SELECT * FROM sekolah LIMIT 1");
if ($rp && ($s = mysqli_fetch_assoc($rp))) {
    $nama_sekolah = $s['nama_sekolah'] ?? $nama_sekolah;
    foreach (['logo','logo_sekolah','path_logo'] as $lc) {
        if (isset($s[$lc]) && trim((string)$s[$lc]) !== '') { $logo = trim($s[$lc]); break; }
    }
}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login — <?=h($nama_sekolah)?></title>
<style>
*{box-sizing:border-box}
html,body{margin:0;min-height:100%;font-family:Inter,Segoe UI,Arial,sans-serif}
body{
    min-height:100vh;display:flex;align-items:center;justify-content:center;
    padding:28px;color:#e9fbff;
    background:#020711 url('assets/images/login-cyber-blueprint.jpg') center/cover fixed no-repeat;
    position:relative;overflow-x:hidden;
}
body:before{
    content:"";position:fixed;inset:0;
    background:linear-gradient(135deg,rgba(0,4,11,.88),rgba(0,22,39,.68) 48%,rgba(0,4,11,.90));
    z-index:0;pointer-events:none;
}
.login-shell{
    position:relative;z-index:1;width:min(940px,100%);
    display:grid;grid-template-columns:1fr 1fr;
    border:1px solid rgba(122,239,255,.35);border-radius:26px;overflow:hidden;
    background:rgba(2,12,24,.30);
    box-shadow:0 30px 90px rgba(0,0,0,.58),0 0 55px rgba(0,212,255,.08);
    backdrop-filter:blur(12px);
}
.brand{
    padding:48px 44px;display:flex;flex-direction:column;justify-content:center;
    color:#fff;background:linear-gradient(155deg,rgba(2,18,34,.91),rgba(3,43,66,.72));
    border-right:1px solid rgba(0,234,255,.20);
}
.brand-badge{
    width:78px;height:78px;border-radius:21px;background:rgba(255,255,255,.95);
    display:flex;align-items:center;justify-content:center;overflow:hidden;
    margin-bottom:20px;border:1px solid rgba(0,234,255,.48);
    box-shadow:0 10px 28px rgba(0,0,0,.25);
}
.brand-badge img{width:100%;height:100%;object-fit:contain}
.brand-badge span{font-size:30px}
.brand h1{margin:0 0 9px;font-size:30px;line-height:1.15;letter-spacing:-.4px}
.brand p{margin:0;color:rgba(224,250,255,.76);line-height:1.6;font-size:14px}
.panel{
    padding:44px;background:rgba(242,250,253,.95);color:#10213f;
}
.panel h2{margin:0 0 7px;font-size:25px;line-height:1.2;color:#10213f}
.panel .sub{margin:0 0 25px;color:#667b91;font-size:13px;line-height:1.55}
.field{margin-bottom:16px}
.field label{display:block;margin-bottom:7px;font-size:12px;font-weight:800;color:#29405d}
.field input{
    width:100%;height:48px;padding:0 14px;border:1px solid #c9dbe7;border-radius:11px;
    outline:none;font-size:15px;background:#fff;color:#132944;
    transition:border-color .2s,box-shadow .2s,transform .2s;
}
.field input:focus{
    border-color:#12aee5;box-shadow:0 0 0 4px rgba(18,174,229,.12);
}
.password-wrap{position:relative;width:100%}.password-wrap input{padding-right:48px}.toggle-password{position:absolute;right:10px;top:50%;transform:translateY(-50%);border:0;background:transparent;cursor:pointer;padding:6px;font-size:18px;line-height:1;color:#475569}.toggle-password:hover{color:#0f6fc6}.toggle-password:focus{outline:2px solid #0f6fc6;outline-offset:2px;border-radius:6px}
.btn{
    width:100%;height:48px;border:0;padding:0 16px;border-radius:11px;
    background:linear-gradient(135deg,#08cfee,#087de8);color:#fff;
    font-size:14px;font-weight:800;cursor:pointer;
    box-shadow:0 8px 20px rgba(8,125,232,.22);
    transition:transform .15s,box-shadow .15s;
}
.btn:active{transform:translateY(1px)}
.error{
    background:#fff1f1;border:1px solid #efb6b6;color:#a32c2c;
    padding:10px 12px;border-radius:10px;margin-bottom:16px;font-size:12px;line-height:1.45;
}
.hint{margin-top:17px;text-align:center;color:#71869a;font-size:11px}

/* Tablet */
@media(max-width:760px){
    body{
        padding:16px;align-items:center;
        background-position:center;
    }
    .login-shell{
        width:min(470px,100%);display:flex;flex-direction:column;
        border-radius:22px;background:transparent;border:0;box-shadow:none;
        backdrop-filter:none;overflow:visible;
    }
    .brand{
        padding:22px 20px 18px;align-items:center;text-align:center;
        border:1px solid rgba(122,239,255,.30);border-bottom:0;
        border-radius:22px 22px 0 0;
        background:linear-gradient(155deg,rgba(2,18,34,.93),rgba(3,43,66,.82));
    }
    .brand-badge{width:64px;height:64px;border-radius:18px;margin-bottom:12px}
    .brand-badge span{font-size:25px}
    .brand h1{font-size:22px;margin-bottom:5px}
    .brand p{font-size:12px}
    .panel{
        padding:25px 21px 22px;
        border:1px solid rgba(205,231,241,.75);border-top:0;
        border-radius:0 0 22px 22px;
        box-shadow:0 22px 55px rgba(0,0,0,.38);
    }
    .panel h2{font-size:21px}
    .panel .sub{font-size:12px;margin-bottom:20px}
    .field{margin-bottom:14px}
    .field input,.btn{height:47px}
    .hint{margin-top:14px}
}

/* Small phones */
@media(max-width:390px){
    body{padding:10px}
    .login-shell{width:100%}
    .brand{padding:18px 16px 15px}
    .brand-badge{width:55px;height:55px;border-radius:16px;margin-bottom:9px}
    .brand h1{font-size:19px}
    .brand p{font-size:11px}
    .panel{padding:21px 17px 18px}
    .panel h2{font-size:19px}
    .panel .sub{font-size:11px;margin-bottom:17px}
    .field label{font-size:11px}
    .field input,.btn{height:45px;font-size:14px}
}

/* Very short screens */
@media(max-height:650px) and (max-width:760px){
    body{padding:8px}
    .brand{padding:13px 16px 11px}
    .brand-badge{width:48px;height:48px;margin-bottom:6px}
    .brand h1{font-size:18px}
    .panel{padding:17px}
    .panel .sub{margin-bottom:13px}
    .field{margin-bottom:10px}
    .field input,.btn{height:42px}
}
</style>
</head>
<body>
<div class="login-shell">
<section class="brand">
<div class="brand-badge"><?php if($logo): ?><img src="<?=h($logo)?>" alt="Logo Sekolah"><?php else: ?><span>🏫</span><?php endif; ?></div>
<h1><?=h($nama_sekolah)?></h1><p>Sistem Administrasi & Absensi Sekolah</p>
</section>
<section class="panel">
<h2>🔐 Login Aplikasi</h2><p class="sub">Masuk menggunakan akun pengguna yang sudah dibuat.</p>
<?php if($error): ?><div class="error"><?=h($error)?></div><?php endif; ?>
<form method="post" autocomplete="on">
<div class="field"><label>Email / Username</label><input type="text" name="username" required autofocus autocomplete="username" value="<?=h($_POST['username'] ?? '')?>"></div>
<div class="field"><label>Password</label><div class="password-wrap"><input type="password" id="password" name="password" required autocomplete="current-password"><button type="button" class="toggle-password" id="togglePassword" aria-label="Tampilkan password" title="Tampilkan password">👁</button></div></div>
<button class="btn" type="submit">Masuk ke Aplikasi</button>
</form>
<div class="hint"><?=h($nama_sekolah)?> • Sistem Administrasi Sekolah</div>
</section>
</div>
<script>document.addEventListener('DOMContentLoaded',function(){const p=document.getElementById('password'),t=document.getElementById('togglePassword');if(!p||!t)return;t.addEventListener('click',function(){const v=p.type==='text';p.type=v?'password':'text';t.textContent=v?'👁':'🙈';t.setAttribute('aria-label',v?'Tampilkan password':'Sembunyikan password');t.setAttribute('title',v?'Tampilkan password':'Sembunyikan password')})});</script></body>
</html>
