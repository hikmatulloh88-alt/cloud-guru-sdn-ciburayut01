<?php
session_start();
require_once __DIR__ . '/../config/auth.php';
wajib_login();
require_once __DIR__ . '/../config/portal.php';

$page_title = 'Profil Guru - SDN Ciburayut 01';
$menu_aktif = 'profil_guru';

$stmt = $pdo->query("SELECT * FROM teachers WHERE is_active=1 ORDER BY sort_order, name");
$teachers = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
    <div class="page-head">
        <div>
            <h1>Profil Guru</h1>
            <p>Data tenaga pendidik SDN Ciburayut 01.</p>
        </div>
    </div>
    <div class="portal-teacher-grid">
    <?php foreach ($teachers as $t): ?>
        <div class="portal-teacher-card">
            <div class="portal-avatar">
                <?php if (!empty($t['photo'])): ?>
                    <img src="<?= htmlspecialchars($t['photo']) ?>" alt="">
                <?php else: ?>
                    <span>👨‍🏫</span>
                <?php endif; ?>
            </div>
            <h3><?= htmlspecialchars($t['name']) ?></h3>
            <div><?= htmlspecialchars($t['position'] ?: 'Guru') ?></div>
            <?php if ($t['nip']): ?><small>NIP: <?= htmlspecialchars($t['nip']) ?></small><?php endif; ?>
            <?php if ($t['subject']): ?><small>Mata Pelajaran: <?= htmlspecialchars($t['subject']) ?></small><?php endif; ?>
            <?php if ($t['class_name']): ?><small>Kelas: <?= htmlspecialchars($t['class_name']) ?></small><?php endif; ?>
        </div>
    <?php endforeach; ?>
    </div>
</main>
</body></html>
