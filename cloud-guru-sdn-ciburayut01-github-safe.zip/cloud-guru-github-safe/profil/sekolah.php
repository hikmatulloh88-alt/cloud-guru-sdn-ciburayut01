<?php
session_start();
require_once __DIR__ . '/../config/auth.php';
wajib_login();
require_once __DIR__ . '/../config/portal.php';

$page_title = 'Profil Sekolah - SDN Ciburayut 01';
$menu_aktif = 'profil_sekolah';
$profile = portal_profile($pdo);

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>
<main class="main-content">
    <div class="page-head">
        <div>
            <h1>Profil Sekolah</h1>
            <p>Informasi resmi SDN Ciburayut 01.</p>
        </div>
    </div>
    <div class="form-card" style="padding:28px;">
        <h2><?= htmlspecialchars($profile['school_name'] ?? 'SDN Ciburayut 01') ?></h2>
        <p><?= nl2br(htmlspecialchars($profile['address'] ?? '')) ?></p>
        <hr>
        <h3>Visi</h3>
        <p><?= nl2br(htmlspecialchars($profile['vision'] ?? 'Belum diisi.')) ?></p>
        <h3>Misi</h3>
        <p><?= nl2br(htmlspecialchars($profile['mission'] ?? 'Belum diisi.')) ?></p>
        <h3>Sejarah</h3>
        <p><?= nl2br(htmlspecialchars($profile['history'] ?? 'Belum diisi.')) ?></p>
    </div>
</main>
</body></html>
