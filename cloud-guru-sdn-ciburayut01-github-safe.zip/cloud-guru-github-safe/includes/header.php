<?php require_once __DIR__.'/../config/config.php'; ?>

<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title><?= htmlspecialchars($page_title ?? APP_NAME) ?></title>

<link rel="stylesheet" href="/assets/css/style.css">
<link rel="stylesheet" href="/assets/css/portal.css">
<link rel="stylesheet" href="/assets/css/portal_editor.css">
<link rel="stylesheet" href="/assets/css/guru.css">

</head>

<body>

<div class="layout">

<?php require_once __DIR__ . '/sidebar.php'; ?>

<main class="main">

<header class="topbar">

    <div>
        <b><?= htmlspecialchars(APP_NAME) ?></b>
    </div>

    <div>
        👤 <?= htmlspecialchars(
            function_exists('user_name')
                ? user_name()
                : ($_SESSION['user_name'] ?? 'Pengguna')
        ) ?>
    </div>

</header>