<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../config/database.php';

function wajib_login() {
    if (empty($_SESSION['user_id'])) {
        header('Location: ../auth/login.php'); exit;
    }
}
function user_id() { return (int)($_SESSION['user_id'] ?? 0); }
function user_name() { return $_SESSION['user_name'] ?? ''; }
