<?php
$menu_aktif = $menu_aktif ?? '';
$role = $_SESSION['role'] ?? '';
?>

<aside class="sidebar">

    <div class="brand">
        ☁️ <span>Cloud Guru</span>
    </div>

    <nav>

        <a href="/dashboard/index.php"
           class="<?= $menu_aktif === 'dashboard' ? 'active' : '' ?>">
            🏠 Dashboard
        </a>

        <a href="/storage/index.php">
            📁 Penyimpanan Saya
        </a>

        <a href="/storage/index.php?folder=1">
            📚 Administrasi Guru
        </a>

        <a href="/storage/index.php?folder=2">
            📝 Perencanaan
        </a>

        <a href="/storage/index.php?folder=4">
            📊 Asesmen
        </a>

        <!-- PROFIL GURU -->
        <a href="/guru/"
           class="<?= $menu_aktif === 'guru' ? 'active' : '' ?>">
            👨‍🏫 Profil Guru
        </a>

        <?php if ($role === 'Admin'): ?>

            <!-- KHUSUS ADMIN -->
            <a href="/admin/guru/"
               class="<?= $menu_aktif === 'kelola_guru' ? 'active' : '' ?>">
                ⚙️ Kelola Profil Guru
            </a>

            <a href="/admin/tampilan/"
               class="<?= $menu_aktif === 'website_sekolah' ? 'active' : '' ?>">
                🌐 Website Sekolah
            </a>

            <!-- Akun login guru: terpisah dari data profil guru -->
            <a href="/absensi_sd/modules/pengguna/generate_guru.php"
               class="<?= $menu_aktif === 'akun_guru' ? 'active' : '' ?>">
                🔑 Akun Guru
            </a>

        <?php endif; ?>

    </nav>

    <div class="side-bottom">

        <a href="/auth/logout.php">
            🚪 Keluar
        </a>

    </div>

</aside>
