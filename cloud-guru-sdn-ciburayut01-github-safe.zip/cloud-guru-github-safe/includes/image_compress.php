<?php
/**
 * Kompres & resize gambar hasil upload supaya ukuran file tidak membebani loading halaman.
 * Aman dipakai di semua fitur upload (Builder, Media Website, Galeri Beranda).
 *
 * @param string $tmpPath   Path file sumber (biasanya $_FILES['x']['tmp_name'], atau file yang sudah dipindah).
 * @param string $mime      MIME type hasil deteksi finfo (image/jpeg, image/png, image/webp, image/gif).
 * @param string $destPath  Path tujuan penyimpanan akhir.
 * @param int    $maxWidth  Lebar maksimal (px). Gambar lebih lebar dari ini akan diperkecil proporsional.
 * @param int    $quality   Kualitas JPEG/WEBP (1-100).
 * @return bool true jika berhasil menulis file ke $destPath (baik dikompres maupun disalin apa adanya).
 */
function compress_uploaded_image(string $tmpPath, string $mime, string $destPath, int $maxWidth = 1600, int $quality = 82): bool
{
    // GIF (bisa animasi) dan tipe tak dikenal: salin apa adanya, jangan diutak-atik.
    if ($mime === 'image/gif' || !extension_loaded('gd')) {
        return copy($tmpPath, $destPath);
    }

    try {
        switch ($mime) {
            case 'image/jpeg':
                $src = @imagecreatefromjpeg($tmpPath);
                break;
            case 'image/png':
                $src = @imagecreatefrompng($tmpPath);
                break;
            case 'image/webp':
                $src = function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($tmpPath) : false;
                break;
            default:
                $src = false;
        }
        if (!$src) {
            return copy($tmpPath, $destPath);
        }

        $width = imagesx($src);
        $height = imagesy($src);

        if ($width > $maxWidth) {
            $newWidth = $maxWidth;
            $newHeight = (int) round($height * ($maxWidth / $width));
            $resized = imagecreatetruecolor($newWidth, $newHeight);
            if ($mime === 'image/png' || $mime === 'image/webp') {
                imagealphablending($resized, false);
                imagesavealpha($resized, true);
            }
            imagecopyresampled($resized, $src, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
            imagedestroy($src);
            $src = $resized;
        }

        $ok = match ($mime) {
            'image/jpeg' => imagejpeg($src, $destPath, $quality),
            'image/png'  => imagepng($src, $destPath, (int) round(9 - ($quality / 100 * 9))),
            'image/webp' => function_exists('imagewebp') ? imagewebp($src, $destPath, $quality) : copy($tmpPath, $destPath),
            default      => copy($tmpPath, $destPath),
        };
        imagedestroy($src);

        if (!$ok || !is_file($destPath) || filesize($destPath) === 0) {
            return copy($tmpPath, $destPath);
        }
        return true;
    } catch (Throwable $e) {
        return copy($tmpPath, $destPath);
    }
}
