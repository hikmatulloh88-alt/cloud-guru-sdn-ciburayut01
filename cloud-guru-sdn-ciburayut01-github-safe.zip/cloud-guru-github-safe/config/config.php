<?php
define('APP_NAME', 'Cloud Administrasi Guru');
define('BASE_URL', '/');
define('UPLOAD_ROOT', __DIR__ . '/../uploads');
define('MAX_FILE_SIZE', 25 * 1024 * 1024);
date_default_timezone_set('Asia/Jakarta');
