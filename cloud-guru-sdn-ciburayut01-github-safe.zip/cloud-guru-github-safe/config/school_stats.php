<?php
declare(strict_types=1);

/**
 * Statistik publik SDN Ciburayut 01.
 * Database website/cloud guru: $pdo (sudah tersedia dari config/database.php).
 * Database Absensi: dibaca terpisah agar statistik siswa/guru tetap live.
 */
function renderSchoolStats(PDO $pdo): string
{
    $siswa = 0;
    $guru = 0;
    $profilGuru = 0;
    $fotoGuru = 0;

    // Database Absensi SD
    $absensi = null;
    try {
        $absensi = new mysqli('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
        if ($absensi->connect_errno) {
            $absensi = null;
        } else {
            $absensi->set_charset('utf8mb4');
        }
    } catch (Throwable $e) {
        $absensi = null;
    }

    if ($absensi instanceof mysqli) {
        // Hanya gunakan status aktif bila kolom tersebut tersedia.
        try {
            $q = $absensi->query("SELECT COUNT(*) AS total FROM siswa WHERE status_siswa='Aktif'");
            if ($q && ($r = $q->fetch_assoc())) $siswa = (int)$r['total'];
        } catch (Throwable $e) {
            try {
                $q = $absensi->query("SELECT COUNT(*) AS total FROM siswa");
                if ($q && ($r = $q->fetch_assoc())) $siswa = (int)$r['total'];
            } catch (Throwable $e2) {}
        }
        try {
            $q = $absensi->query("SELECT COUNT(*) AS total FROM guru WHERE status='Aktif'");
            if ($q && ($r = $q->fetch_assoc())) $guru = (int)$r['total'];
        } catch (Throwable $e) {
            try {
                $q = $absensi->query("SELECT COUNT(*) AS total FROM guru");
                if ($q && ($r = $q->fetch_assoc())) $guru = (int)$r['total'];
            } catch (Throwable $e2) {}
        }
        $absensi->close();
    }

    // Profil Guru dan foto berasal dari MASTER DATA Guru & Karyawan aplikasi Absensi.
    try {
        $q = $absensi = new mysqli('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
        if (!$absensi->connect_errno) {
            $absensi->set_charset('utf8mb4');
            try {
                $q = $absensi->query("SELECT COUNT(*) AS total FROM guru WHERE status='Aktif'");
                if ($q && ($r = $q->fetch_assoc())) $profilGuru = (int)$r['total'];
            } catch (Throwable $e) {
                $q = $absensi->query("SELECT COUNT(*) AS total FROM guru");
                if ($q && ($r = $q->fetch_assoc())) $profilGuru = (int)$r['total'];
            }
            try {
                $q = $absensi->query("SELECT COUNT(*) AS total FROM guru WHERE status='Aktif' AND foto IS NOT NULL AND TRIM(foto)<>''");
                if ($q && ($r = $q->fetch_assoc())) $fotoGuru = (int)$r['total'];
            } catch (Throwable $e) {
                try {
                    $q = $absensi->query("SELECT COUNT(*) AS total FROM guru WHERE foto IS NOT NULL AND TRIM(foto)<>''");
                    if ($q && ($r = $q->fetch_assoc())) $fotoGuru = (int)$r['total'];
                } catch (Throwable $e2) {}
            }
            $absensi->close();
        }
    } catch (Throwable $e) {}

    $items = [
        ['icon'=>'👨‍🎓','number'=>$siswa,'label'=>'Siswa Aktif','class'=>''],
        ['icon'=>'👨‍🏫','number'=>$guru,'label'=>'Guru & Tenaga Pendidik','class'=>'teacher'],
        ['icon'=>'📋','number'=>$profilGuru,'label'=>'Profil Guru','class'=>'profile'],
        ['icon'=>'📸','number'=>$fotoGuru,'label'=>'Guru dengan Foto','class'=>'photo'],
    ];

    $html = '<section class="school-live-stats" data-school-stats="1">';
    $html .= '<div class="school-live-stats-head"><div class="eyebrow">DATA SEKOLAH TERKINI</div><h2>SDN Ciburayut 01</h2><p>Informasi statistik sekolah yang terhubung langsung dengan sistem administrasi.</p></div>';
    $html .= '<div class="school-live-stats-grid">';
    foreach ($items as $item) {
        $html .= '<div class="school-live-stat '.htmlspecialchars($item['class'], ENT_QUOTES, 'UTF-8').'">';
        $html .= '<div class="school-live-icon">'.$item['icon'].'</div>';
        $html .= '<strong>'.number_format((int)$item['number'], 0, ',', '.').'</strong>';
        $html .= '<small>'.htmlspecialchars($item['label'], ENT_QUOTES, 'UTF-8').'</small>';
        $html .= '</div>';
    }
    $html .= '</div></section>';
    return $html;
}


/** Live quick statistics used by the lower three-card section on the homepage. */
function renderSchoolQuickStats(PDO $pdo): string
{
    $siswa = 0; $kelas = 0; $layanan = '10+'; $absensi = null;
    try {
        $absensi = new mysqli('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
        if ($absensi->connect_errno) $absensi = null; else $absensi->set_charset('utf8mb4');
    } catch (Throwable $e) { $absensi = null; }
    if ($absensi instanceof mysqli) {
        try { $q=$absensi->query("SELECT COUNT(*) AS total FROM siswa WHERE status_siswa='Aktif'"); if($q && ($r=$q->fetch_assoc())) $siswa=(int)$r['total']; } catch(Throwable $e) {}
        try { $q=$absensi->query("SELECT COUNT(*) AS total FROM kelas WHERE status='Aktif'"); if($q && ($r=$q->fetch_assoc())) $kelas=(int)$r['total']; }
        catch(Throwable $e) { try {$q=$absensi->query("SELECT COUNT(*) AS total FROM kelas"); if($q && ($r=$q->fetch_assoc())) $kelas=(int)$r['total'];} catch(Throwable $e2) {} }
        $absensi->close();
    }
    try { $q=$pdo->prepare("SELECT setting_value FROM website_builder_settings WHERE setting_key='stat_services' LIMIT 1"); $q->execute(); $v=trim((string)$q->fetchColumn()); if($v!=='') $layanan=$v; } catch(Throwable $e) {}
    return '<div class="preview-stats school-quick-stats" data-school-quick-stats="1">'
      .'<div><b>'.number_format($siswa,0,',','.').'</b><small>Siswa</small></div>'
      .'<div><b>'.number_format($kelas,0,',','.').'</b><small>Kelas</small></div>'
      .'<div><b>'.htmlspecialchars($layanan,ENT_QUOTES,'UTF-8').'</b><small>Layanan</small></div>'
      .'</div>';
}
