<?php
// Helper konfigurasi portal. Memakai database.php yang sudah ada.
require_once __DIR__ . '/database.php';

function portal_profile(PDO $pdo): array {
    try {
        $stmt = $pdo->query("SELECT * FROM school_profile WHERE id=1 LIMIT 1");
        return $stmt->fetch() ?: [];
    } catch (Throwable $e) {
        return [];
    }
}

function portal_sections(PDO $pdo): array {
    try {
        $stmt = $pdo->query("SELECT * FROM dashboard_sections WHERE is_visible=1 ORDER BY sort_order, id");
        return $stmt->fetchAll();
    } catch (Throwable $e) {
        return [];
    }
}
