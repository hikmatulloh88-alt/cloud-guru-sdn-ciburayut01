<?php
declare(strict_types=1);

$host = 'localhost';
$dbname = 'NAMA_DATABASE_CLOUD_GURU';
$user = 'USER_DATABASE_CLOUD_GURU';
$pass = 'ISI_PASSWORD_DATABASE_DI_SERVER';
$charset = 'utf8mb4';

$dsn = "mysql:host={$host};dbname={$dbname};charset={$charset}";

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    http_response_code(500);
    exit('Koneksi database gagal.');
}
