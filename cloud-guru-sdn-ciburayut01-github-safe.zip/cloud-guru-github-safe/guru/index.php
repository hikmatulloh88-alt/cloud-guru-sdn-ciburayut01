<?php
session_start();
require_once __DIR__ . '/../auth/auth.php';
wajib_login();
require_once __DIR__ . '/../config/database.php';
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
$teachers=$pdo->query("SELECT * FROM teachers WHERE is_active=1 ORDER BY sort_order,id")->fetchAll();
$page_title='Profil Guru'; $menu_aktif='guru';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="guru-public">
  <div class="page-head"><div><h1>👨‍🏫 Profil Guru</h1><p>Kenali tenaga pendidik SDN Ciburayut 01.</p></div></div>
  <div class="teacher-grid">
  <?php foreach($teachers as $t): ?>
    <article class="teacher-card">
      <?php if($t['photo']):?><img class="teacher-photo" src="/uploads/guru/<?=e(basename($t['photo']))?>" alt="<?=e($t['name'])?>"><?php else:?><div class="teacher-photo placeholder">👨‍🏫</div><?php endif;?>
      <div class="teacher-body"><h2><?=e($t['name'])?></h2><div class="teacher-role"><?=e($t['position']?:'Tenaga Pendidik')?></div>
      <?php if($t['subject']):?><p>📚 <?=e($t['subject'])?></p><?php endif;?>
      <?php if($t['nip']):?><p><strong>NIP</strong> <?=e($t['nip'])?></p><?php endif;?>
      <?php if($t['nuptk']):?><p><strong>NUPTK</strong> <?=e($t['nuptk'])?></p><?php endif;?>
      <?php if($t['education']):?><p>🎓 <?=e($t['education'])?></p><?php endif;?>
      <?php if($t['bio']):?><div class="teacher-bio"><?=nl2br(e($t['bio']))?></div><?php endif;?>
      </div>
    </article>
  <?php endforeach;?>
  <?php if(!$teachers):?><div class="guru-empty"><div>👨‍🏫</div><h2>Belum ada profil guru</h2><p>Admin dapat menambahkan data guru.</p></div><?php endif;?>
  </div>
</div>
</main></body></html>
